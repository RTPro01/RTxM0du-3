#!/system/bin/sh
logcat -G 128K >/dev/null 2>&1

NAME="🅱️-GpuBoost"
VERSION="1.0.0 | GpuBoost"
ANDROIDVERSION=$(getprop ro.build.version.release)
DEVICE=$(getprop ro.product.device)
MANUFACTURER=$(getprop ro.product.manufacturer)
DATE=$(date)

echo "==============================="
echo "   $NAME"
echo "   Version : $VERSION"
echo "   Android : ${ANDROIDVERSION:-Unknown}"
echo "   Device  : ${DEVICE:-Unknown}"
echo "   Maker   : ${MANUFACTURER:-Unknown}"
echo "   Date    : $DATE"
echo "==============================="
for part in system vendor data cache metadata odm system_ext product; do
    sm fstrim "/$part" >/dev/null 2>&1
done
for dir in /data/data/*; do
    [ -d "$dir" ] && {
        rm -rf "$dir"/cache/* "$dir"/code_cache/* "$dir"/no_backup/* "$dir"/app_webview/* 2>/dev/null
    }
done

find /data/user_de/*/*/cache/* -delete >/dev/null 2>&1
find /data/user_de/*/*/code_cache/* -delete >/dev/null 2>&1
find /sdcard/Android/data/*/cache/* -delete >/dev/null 2>&1

logcat -c >/dev/null 2>&1

alias SP="setprop"
alias STS="settings"
alias CMD="cmd"
alias RSPT="resetprop"

SP debug.sf.enable_transaction_tracing 0
SP debug.tracing.battery_status 3
SP debug.skia.enable_reuse_scratch_textures 1
SP debug.renderengine.blur_algorithm true
SP debug.renderengine.capture_skia_ms 0
SP debug.renderengine.capture_filename ""
SP debug.renderengine.graphite true
SP debug.renderengine.restore_blur_step true
SP debug.renderengine.graphite_preview_optin true
SP debug.renderengine.skia_atrace_enabled false
SP debug.renderengine.skia_tracing_enabled false
SP debug.renderengine.skia_use_perfetto_track_events false
SP persist.sys.renderengine.maxLuminance ""
RSPT persist.sys.renderengine.maxLuminance

SP debug.sf.hwc_service_name drmfb
SP debug.hwc.compose_level 1
SP debug.hwc.force_gpu 1
SP debug.hwc.asyncdisp 1
SP debug.hwc.otf 1
SP debug.hwc.bq_count 3
SP debug.hwc.disabletonemapping false
SP debug.egl.force_msaa false
SP debug.hwui.disable_vsync false
SP debug.hwui.use_buffer_age 1
SP debug.sf.disable_backpressure 1

SP debug.drm.mode.auto 1
SP debug.sf.enable_gl_backpressure 0
SP debug.sf.disable_client_composition_cache 1
SP debug.sf.disable_hwc_overlays 0
SP debug.sf.disable_hwc 0
SP debug.sf.enable_hwc_vds 1
SP debug.sf.gpu_comp_tiling 1
SP debug.sf.predict_hwc_composition_strategy 0
SP debug.sf.hwc.min.duration 16666666
SP debug.sf.high_fps.hwc.min.duration 11111111
SP persist.sys.hwcomposer.force_gpu 1
SP persist.sys.sf.enable_hwc_vds 1
SP persist.sys.rendercomposer.enable true

CMD deviceidle disable
CMD power set-fixed-performance-mode-enabled true
CMD display set-user-disabled-hdr-types 1 2 3 4
SP debug.performance.profile 1 
SP debug.perf.tuning 1
SP debug.composition.type gpu
STS put global low_power 0
STS put global low_power_sticky 0
STS put global enable_gpu_debug_layers 0
SP debug.hwui.trace_gpu_resources false
STS put global settings_enable_monitor_phantom_procs false

STS put --user 0 global activity_starts_logging_enabled 0
STS put --user 0 global always_finish_activities 0

for f in $(dumpsys window | grep "^  Proto:" | sed 's/^  Proto: //' | tr ' ' '\n'; dumpsys window | grep "^  Logcat:" | sed 's/^  Logcat: //' | tr ' ' '\n'); do wm logging disable "$f"; wm logging disable-text "$f"; done
CMD window logging disable
CMD window logging disable-text
CMD window logging stop

CMD autofill reset
CMD autofill set log_level off
CMD autofill set bind-instant-service-allowed false
CMD autofill set default-augmented-service-enabled 0 
CMD autofill set max_visible_datasets 0
CMD autofill set max_partitions 0
CMD display ab-logging-disable
CMD display dmd-logging-disable
CMD display dwb-logging-disable
CMD voiceinteraction set-debug-hotword-logging false
CMD wifi set-verbose-logging disabled -l 0
simpleperf --log fatal --log-to-android-buffer 0
CMD wifi set-scan-always-available disabled
CMD wifi set-connected-score 60
CMD wifi set-ipreach-disconnect disabled
CMD content_capture set bind-instant-service-allowed false
CMD content_capture set default-service-enabled 0 false
CMD wifi set-network-selection-config disabled enabled -a 0
CMD wifi set-network-selection-config enabled disabled -a 0
CMD media.camera watch stop
CMD media_session dispatch stop
CMD location_time_zone_manager stop
CMD print set-bind-instant-service-allowed false
CMD role set-bypassing-role-qualification false
CMD audio reset-sound-dose-timeout
CMD audio set-ringer-mode SILENT
CMD time_zone_detector set_auto_detection_enabled false
CMD time_zone_detector set_auto_detection_enabled true
CMD wearable_sensing destroy-data-stream

STS put --user 0 global activity_manager_constants max_cached_processes=2147483647,background_settle_time=0,fgservice_min_shown_time=0,fgservice_min_report_time=0,fgservice_screen_on_before_time=0,fgservice_screen_on_after_time=0,gc_timeout=0,gc_min_interval=0,full_pss_min_interval=0,full_pss_lowered_interval=0,power_check_max_cpu_1=100,power_check_max_cpu_2=100,power_check_max_cpu_3=100,power_check_max_cpu_4=100,service_usage_interaction_time=0,usage_stats_interaction_interval=0,service_restart_duration=0,service_reset_run_duration=0,service_restart_duration_factor=0,service_min_restart_time_between=0,service_max_inactivity=0,service_bg_start_timeout=0,service_bg_activity_start_timeout=0,process_start_async=true,content_provider_retain_time=0,CUR_MAX_CACHED_PROCESSES=2147483647,CUR_MAX_EMPTY_PROCESSES=2147483647,CUR_TRIM_EMPTY_PROCESSES=0,CUR_TRIM_CACHED_PROCESSES=0

STS put --user 0 system activity_manager_constants max_cached_processes=2147483647,background_settle_time=0,fgservice_min_shown_time=0,fgservice_min_report_time=0,fgservice_screen_on_before_time=0,fgservice_screen_on_after_time=0,gc_timeout=0,gc_min_interval=0,full_pss_min_interval=0,full_pss_lowered_interval=0,power_check_max_cpu_1=100,power_check_max_cpu_2=100,power_check_max_cpu_3=100,power_check_max_cpu_4=100,service_usage_interaction_time=0,usage_stats_interaction_interval=0,service_restart_duration=0,service_reset_run_duration=0,service_restart_duration_factor=0,service_min_restart_time_between=0,service_max_inactivity=0,service_bg_start_timeout=0,service_bg_activity_start_timeout=0,process_start_async=true,content_provider_retain_time=0,CUR_MAX_CACHED_PROCESSES=2147483647,CUR_MAX_EMPTY_PROCESSES=2147483647,CUR_TRIM_EMPTY_PROCESSES=0,CUR_TRIM_CACHED_PROCESSES=0

pm disable --user 0 com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
pm disable --user 0 com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
pm disable --user 0 com.google.android.gms/com.google.android.gms.kids.account.receiver.ProfileOwnerReceiver

STS put --user 0 global app_standby_enabled 0
STS put --user 0 global force_background_check 0
STS put --user 0 global forced_app_standby_enabled 0
STS put --user 0 global forced_app_standby_for_small_battery_enabled 0
STS put --user 0 global force_all_apps_standby 0
STS put --user 0 global adaptive_battery_management_enabled 0

cmd notification post -S bigtext -t '🅱️-GpuBoost' '✅' "Tweak Activated"
echo "[$NAME]✅."