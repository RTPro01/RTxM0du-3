#!/system/bin/sh

alias SP="setprop"
alias STS="settings"
alias CMD="cmd"
alias RSPT="resetprop"

RSPT debug.hwui.renderer
RSPT debug.renderengine.backend
RSPT debug.renderengine.graphite
RSPT debug.renderengine.graphite_preview_optin
RSPT debug.renderengine.blur_algorithm
RSPT debug.renderengine.restore_blur_step
RSPT debug.renderengine.capture_skia_ms
RSPT debug.renderengine.capture_filename
RSPT debug.renderengine.skia_atrace_enabled
RSPT debug.renderengine.skia_tracing_enabled
RSPT debug.renderengine.skia_use_perfetto_track_events
RSPT persist.sys.renderengine.maxLuminance

RSPT debug.skia.enable_reuse_scratch_textures
RSPT debug.hwui.use_buffer_age
RSPT debug.hwui.disable_vsync
RSPT debug.hwui.trace_gpu_resources

RSPT debug.sf.enable_transaction_tracing
RSPT debug.sf.disable_backpressure
RSPT debug.sf.enable_gl_backpressure
RSPT debug.sf.disable_client_composition_cache
RSPT debug.sf.disable_hwc_overlays
RSPT debug.sf.disable_hwc
RSPT debug.sf.enable_hwc_vds
RSPT debug.sf.gpu_comp_tiling
RSPT debug.sf.predict_hwc_composition_strategy
RSPT debug.sf.hwc.min.duration
RSPT debug.sf.high_fps.hwc.min.duration

RSPT debug.hwc.compose_level
RSPT debug.hwc.force_gpu
RSPT debug.hwc.asyncdisp
RSPT debug.hwc.otf
RSPT debug.hwc.bq_count
RSPT debug.hwc.disabletonemapping
RSPT debug.sf.hwc_service_name
RSPT persist.sys.hwcomposer.force_gpu
RSPT persist.sys.sf.enable_hwc_vds
RSPT persist.sys.rendercomposer.enable

RSPT debug.drm.mode.auto
RSPT debug.egl.force_msaa
RSPT debug.composition.type

CMD deviceidle enable
CMD power set-fixed-performance-mode-enabled false

CMD display clear-user-disabled-hdr-types

RSPT debug.performance.profile
RSPT debug.perf.tuning
STS put global low_power 0
STS put global low_power_sticky 0

RSPT debug.kill_allocating_task
RSPT debug.tracing.battery_status
STS put global enable_gpu_debug_layers 0
STS put global settings_enable_monitor_phantom_procs true

CMD autofill reset
CMD autofill set log_level off
CMD autofill set bind-instant-service-allowed false
CMD autofill set default-augmented-service-enabled 0
CMD autofill set max_visible_datasets 1
CMD autofill set max_partitions 1

CMD display ab-logging-disable
CMD display dmd-logging-disable
CMD display dwb-logging-disable
CMD voiceinteraction set-debug-hotword-logging false

CMD wifi set-verbose-logging disabled -l 0
simpleperf --log fatal --log-to-android-buffer 0
CMD wifi set-scan-always-available enabled
CMD wifi set-connected-score 60
CMD wifi set-ipreach-disconnect enabled

CMD content_capture set bind-instant-service-allowed false
CMD content_capture set default-service-enabled 0 false

CMD wifi set-network-selection-config disabled enabled -a 0
CMD wifi set-network-selection-config enabled disabled -a 0

CMD media.camera watch stop
CMD media_session dispatch stop
CMD location_time_zone_manager start

CMD print set-bind-instant-service-allowed false
CMD role set-bypassing-role-qualification false

CMD audio reset-sound-dose-timeout
CMD audio set-ringer-mode SILENT

CMD time_zone_detector set_auto_detection_enabled true
CMD wearable_sensing destroy-data-stream


STS put --user 0 global activity_manager_constants max_cached_processes=256,background_settle_time=3000,fgservice_min_shown_time=2000,fgservice_min_report_time=2000,gc_timeout=5000,gc_min_interval=5000,full_pss_min_interval=300000,power_check_max_cpu_1=80,power_check_max_cpu_2=80,power_check_max_cpu_3=80,power_check_max_cpu_4=80,service_usage_interaction_time=60000,usage_stats_interaction_interval=60000,service_restart_duration=10000,service_reset_run_duration=60000,service_restart_duration_factor=1,service_min_restart_time_between=5000,service_max_inactivity=600000,service_bg_start_timeout=10000,service_bg_activity_start_timeout=10000,process_start_async=true,content_provider_retain_time=60000,CUR_MAX_CACHED_PROCESSES=256,CUR_MAX_EMPTY_PROCESSES=128,CUR_TRIM_EMPTY_PROCESSES=16,CUR_TRIM_CACHED_PROCESSES=32

STS put --user 0 system activity_manager_constants max_cached_processes=256,background_settle_time=3000,gc_timeout=5000,process_start_async=true


pm disable --user 0 com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
pm disable --user 0 com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
pm disable --user 0 com.google.android.gms/com.google.android.gms.kids.account.receiver.ProfileOwnerReceiver


STS put --user 0 global app_standby_enabled 1
STS put --user 0 global force_background_check 0
STS put --user 0 global forced_app_standby_enabled 0
STS put --user 0 global forced_app_standby_for_small_battery_enabled 1
STS put --user 0 global force_all_apps_standby 0
STS put --user 0 global adaptive_battery_management_enabled 1


for app in $(CMD package list packages --user 0 | cut -f2 -d:); do
    am set-standby-bucket --user 0 "$app" working_set
    CMD appops set "$app" RUN_IN_BACKGROUND allow
    CMD appops set "$app" RUN_ANY_IN_BACKGROUND allow
    CMD appops set "$app" WAKE_LOCK allow
    CMD appops set "$app" START_FOREGROUND allow
done

cmd notification post -S bigtext -t '🅱️-GpuBoost' '🛑' " stopped(reboot recommended)"