#!/system/bin/sh

CYAN="\033[36m"
YELLOW="\033[33m"
GREEN="\033[92m"
MAGENTA="\033[95m"
RESET="\033[0m"


echo -e "${CYAN}==================================================${RESET}"
echo -e "${CYAN}      LowTexYíH Dynamic v3.1 - GMI Service SkiaGL Edition      ${RESET}"
echo -e "${CYAN}==================================================${RESET}"
echo -e "${GREEN}Status: ACTIVE${RESET}"
echo -e "${GREEN}Developer: @yih855${RESET}"
echo -e "${GREEN}Version: 3.1${RESET}"
echo ""


echo -e "${YELLOW}NOTE:${RESET}"
echo -e "${YELLOW}Some devices may restrict or block certain system commands.${RESET}"
echo -e "${YELLOW}Due to manufacturer limits (Xiaomi, Samsung, Oppo, Vivo, Realme, Huawei, etc.),${RESET}"
echo -e "${YELLOW}this module may work fully, partially, or not at all.${RESET}"
echo -e "${YELLOW}Results depend on device model and Android version.${RESET}"
echo -e "${YELLOW}Use this module at your own risk.${RESET}"
echo ""


echo -e "${MAGENTA}Features activated by this module:${RESET}"
echo ""

echo -e "${CYAN}1) Dynamic Device Detection:${RESET}"
echo -e "${CYAN}   Detects RAM, CPU, Android version, auto-classifies device, and sets downscaleFactor.${RESET}"
echo ""

echo -e "${CYAN}2) Display & UI Optimization:${RESET}"
echo -e "${CYAN}   Disables animations, sets frame-rate preferences, disables HDR types causing stutter.${RESET}"
echo ""

echo -e "${CYAN}3) SkiaGL Renderer Tweaks:${RESET}"
echo -e "${CYAN}   Enables SkiaGL, optimizes render thread, max frame lag, frame deadline, swap with damage, HWC VDS.${RESET}"
echo ""

echo -e "${CYAN}4) Game Mode Performance:${RESET}"
echo -e "${CYAN}   Automatically applies performance mode, downscaleFactor, FPS limit to all installed games.${RESET}"
echo ""

echo -e "${CYAN}5) Memory & Touch Boost:${RESET}"
echo -e "${CYAN}   Optimizes background processes, RAM, touch responsiveness, disables device idle.${RESET}"
echo ""

echo -e "${CYAN}6) Android 11-15+ Game Flags:${RESET}"
echo -e "${CYAN}   Applies modern ADPF performance flags for better GPU/CPU utilization.${RESET}"
echo ""

echo -e "${GREEN}Module is now running and optimizing your device for smooth gameplay!${RESET}"
echo -e "${CYAN}==================================================${RESET}"