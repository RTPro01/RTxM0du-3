#!/system/bin/sh
#  Reminder:
#
#  - All paid methods are already remaked/reworked.
#  - Some tweaks may not work on all ROMs/devices.
#  - Do not fully copy/reupload
#  - Use at your own risk.
#


DOWN_SCALE=0.5


FPS_OVERRIDE=120


run() {
    "$@" >/dev/null 2>&1
}


prop() {
    setprop "$1" "$2" >/dev/null 2>&1
}


put() {
    settings put "$1" "$2" "$3" >/dev/null 2>&1
}

# Wait until Android fully boots
wait_boot() {
    until [ "$(getprop sys.boot_completed)" = "1" ]; do
        sleep 2
    done
}

# Execute boot wait
wait_boot

# Detect current refresh rate
FPS=$(settings get system peak_refresh_rate 2>/dev/null)

# Fallback refresh rate
[ -z "$FPS" ] && FPS=120

# Detect Android version
ANDROID=$(getprop ro.build.version.release | cut -d. -f1)

# Run Android idle maintenance
run cmd activity idle-maintenance

# Kill cached background apps
run am kill-all

# Reduce window animation speed
put global window_animation_scale 0.4

# Reduce transition animation speed
put global transition_animation_scale 0.5

# Reduce animator duration scale
put global animator_duration_scale 0.5

# Faster long press response
put secure long_press_timeout 150

# Faster multi press response
put secure multi_press_timeout 150

# Disable phantom process monitor
put global settings_enable_monitor_phantom_procs false

# Enable HWUI hint manager
prop debug.hwui.use_hint_manager true

# Disable dirty region debugging
prop debug.hwui.show_dirty_regions false


# Detect Vulkan support
if dumpsys SurfaceFlinger | grep -qi "vk"; then

    # Use Skiavk renderer
    prop debug.hwui.renderer skiavk

else

    # Fallback to Skiagl renderer
    prop debug.hwui.renderer skiagl

fi

# Force GPU rendering
prop debug.hwui.force_gpu_rendering true

# Prioritize frame rate
prop debug.sf.use_frame_rate_priority 1

# Enable refresh rate switching
run device_config put surface_flinger refresh_rate_switching false

# Enable frame rate override
run device_config put surface_flinger frame_rate_override 1

# Limit framebuffer acquired buffers
put secure surface_flinger_max_frame_buffer_acquired_buffers 3

# Disable device idle mode
run cmd deviceidle disable

# Apply activity manager memory tweaks
put global activity_manager_constants \
"max_cached_processes=24,\
max_phantom_processes=20,\
process_start_async=true,\
gc_min_interval=45000,\
background_settle_time=30000,\
max_previous_time=30000,\
low_swap_threshold_percent=0.15"

# Target package name
for PKG in \
"com.garena.game.codm" \
"com.activision.callofduty.shooter"
do

    run cmd package compile -m speed-profile -f "$PKG"

    run cmd appops set "$PKG" RUN_ANY_IN_BACKGROUND allow
    run cmd appops set "$PKG" RUN_IN_BACKGROUND allow

    run dumpsys deviceidle whitelist +"$PKG"

done

# Get installed packages
GAMES=$(cmd package list packages --user 0 | cut -f2 -d:)

# Loop through all packages
for app in $GAMES; do

    # Skip empty values
    [ -z "$app" ] && continue

    # Check if app supports game service
    if dumpsys game | grep -q "$app"; then

        # Android 12+
        if [ "$ANDROID" -ge 12 ]; then

            # Apply game mode optimization
            run cmd game set \
            --mode 2 \
            --downscale "$DOWN_SCALE" \
            --fps "$FPS_OVERRIDE" "$app"
        fi
    fi
done

# Android 13+ only
if [ "$ANDROID" -ge 13 ]; then

    # Disable power efficiency preference
    run cmd device_config override game \
        android.os.adpf_prefer_power_efficiency false

    # Enable ADPF GPU optimization
    run cmd device_config override game \
        android.os.adpf_hwui_gpu true
fi

# Disable background data restriction
put global background_data 0

# Disable dumpstate debugging
prop debug.dumpstate 0

cmd notification post -S bigtext -t "[Nyxoraエンジン]" "$TAG" "STATUS: Install Complete" > /dev/null 2>&1
# Delay before exit
sleep 2

# Exit script
exit 0