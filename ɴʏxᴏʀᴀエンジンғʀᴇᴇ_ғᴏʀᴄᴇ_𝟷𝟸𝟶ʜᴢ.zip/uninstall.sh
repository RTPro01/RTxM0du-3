#!/system/bin/sh
#  Reminder:
#
#  - This script removes/reset applied tweaks.
#  - Some values may remain depending on ROM behavior.
#  - Reboot is recommended after running this script.
#  - Use at your own risk.
#



run() {
    "$@" >/dev/null 2>&1
}


reset_global() {
    settings delete global "$1" >/dev/null 2>&1
}


reset_secure() {
    settings delete secure "$1" >/dev/null 2>&1
}


reset_system() {
    settings delete system "$1" >/dev/null 2>&1
}


reset_prop() {
    setprop "$1" "" >/dev/null 2>&1
}

# Reset animation scales
reset_global window_animation_scale
reset_global transition_animation_scale
reset_global animator_duration_scale

# Reset touch response tweaks
reset_secure long_press_timeout
reset_secure multi_press_timeout

# Reset phantom process tweak
reset_global settings_enable_monitor_phantom_procs

# Reset HWUI properties
reset_prop debug.hwui.use_hint_manager
reset_prop debug.hwui.show_dirty_regions
reset_prop debug.hwui.use_vulkan
reset_prop debug.hwui.renderer
reset_prop debug.hwui.force_gpu_rendering

# Reset graphics properties
reset_prop debug.sf.use_frame_rate_priority
reset_prop debug.2d.hw

# Remove SurfaceFlinger tweaks
run device_config delete surface_flinger refresh_rate_switching
run device_config delete surface_flinger frame_rate_override

# Reset framebuffer tweak
reset_secure surface_flinger_max_frame_buffer_acquired_buffers

# Re-enable device idle
run cmd deviceidle enable

# Reset activity manager tweaks
reset_global activity_manager_constants

# CODM package name
for PKG in \
"com.garena.game.codm" \
"com.activision.callofduty.shooter"
do

    # Reset app operations
    run cmd appops reset "$PKG"

    # Remove from idle whitelist
    run dumpsys deviceidle whitelist -"$PKG"

done

# Get installed packages
GAMES=$(cmd package list packages --user 0 | cut -f2 -d:)

# Loop through packages
for app in $GAMES; do

    # Skip empty values
    [ -z "$app" ] && continue

    # Reset game mode
    run cmd game reset "$app"

    # Remove game overlay config
    run cmd device_config delete game_overlay "$app"
done

# Remove ADPF overrides
run cmd device_config delete game android.os.adpf_prefer_power_efficiency
run cmd device_config delete game android.os.adpf_hwui_gpu

# Reset background data tweak
reset_global background_data

# Reset dumpstate property
reset_prop debug.dumpstate

cmd notification post -S bigtext -t "[Nyxoraエンジン]" "$TAG" "STATUS: Uninstall Complete" > /dev/null 2>&1
# Delay before exit
sleep 2

# Exit script
exit 0