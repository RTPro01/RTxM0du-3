#!/system/bin/sh

LOG="/sdcard/codm_optimizer.log"

log() {
    echo "$(date '+%H:%M:%S') $1" | tee -a "$LOG"
}

log "Starting CODM Optimizer"

package="com.garena.game.codm"




RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 1500000)
ANDROID_VER=$(getprop ro.build.version.release)

log "[INFO] RAM: $RAM_KB KB"
log "[INFO] CPU: $CPU_MAX_FREQ"
log "[INFO] Android: $ANDROID_VER"





if [ "$RAM_KB" -ge 8000000 ] && [ "$CPU_MAX_FREQ" -ge 2600000 ]; then
  downscale="0.53"
  fps="120"
  CLASS="HIGH-END"
elif [ "$RAM_KB" -ge 6000000 ]; then
  downscale="0.49"
  fps="120"
  CLASS="UPPER-MID"
elif [ "$RAM_KB" -ge 4000000 ]; then
  downscale="0.47"
  fps="90"
  CLASS="MID"
else
  downscale="0.45"
  fps="60"
  CLASS="LOW-END"
fi

log "[PROFILE] $CLASS"
log "[AUTO] Downscale: $downscale"
log "[AUTO] FPS: $fps"





log "[STEP] Applying Game Overlay..."
cmd device_config put game_overlay "$package" mode=2,downscaleFactor="$downscale",useAngle=false,fps="$fps",loadingBoost=1073741824
log "[OK] Game overlay applied"

log "[STEP] Setting Game Mode..."
if [ "$ANDROID_VER" = "12" ]; then
    cmd game set --mode 2 --downscale "$downscale" --fps "$fps" "$package"
    log "[OK] Android 12 Game Mode Applied"
elif [ "$ANDROID_VER" -gt 12 ]; then
    cmd game mode 2 "$package"
    log "[OK] Android 13+ Game Mode Applied"
else
    log "[WARN] Android version unsupported"
fi

log "[STEP] Setting Refresh Rate..."
settings put system peak_refresh_rate $fps
settings put system min_refresh_rate $fps
log "[OK] Refresh rate forced"

log "[STEP] Rendering Tweaks..."
setprop debug.force-opengl 1
settings put system multicore_packet_scheduler 1
log "[OK] Rendering tweaks applied"

log "[STEP] Compiling CODM..."
cmd package compile -m speed-profile -f "$package"
log "[OK] Compilation finished"

log "[STEP] Background Permissions..."
cmd appops set "$package" RUN_ANY_IN_BACKGROUND allow
cmd appops set "$package" RUN_IN_BACKGROUND allow
log "[OK] Background allowed"

log "[STEP] Removing Doze..."
dumpsys deviceidle whitelist +"$package"
am set-standby-bucket "$package" active
log "[OK] Doze removed"

log "[STEP] Performance Mode..."
cmd power set-fixed-performance-mode-enabled true
log "[OK] Performance mode enabled"

log "CODM Optimization Complete"
log "Final FPS: $fps"
log "Final Downscale: $downscale"
log "Log saved to: $LOG"