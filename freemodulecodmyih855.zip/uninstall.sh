#!/system/bin/sh

package="com.garena.game.codm"

settings put system peak_refresh_rate 90.0
settings put system min_refresh_rate 60.0
echo "System refresh rates reset to 60Hz"


setprop debug.hwui.renderer ""
settings put global sem_enhanced_cpu_responsiveness 0
echo "OpenGL and CPU responsiveness settings reverted"


cmd device_config delete game_overlay "$package"
if [ "$(getprop ro.build.version.release)" -ge 12 ]; then
    cmd game reset "$package"
fi
echo "Game overlay and mode reverted for $package"




cmd appops set "$package" RUN_ANY_IN_BACKGROUND deny
cmd appops set "$package" RUN_IN_BACKGROUND deny
dumpsys deviceidle whitelist -$package
am set-standby-bucket "$package" restricted
echo "Background permissions and idle bucket reset"


cmd power set-fixed-performance-mode-enabled false
echo "Fixed performance mode disabled"

echo " Optimizer Reset Complete "