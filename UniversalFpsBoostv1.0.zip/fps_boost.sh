#!/bin/bash
# ==============================================
# ⚡ Universal FPS Booster (Non-Root)
# By Rai Gaming PH
# ==============================================

echo ""
echo "=============================================="
echo "   🚀 ANDROID UNIVERSAL FPS BOOSTER (NON-ROOT)"
echo "=============================================="
echo ""

# ---- Device Info ----
echo "📱 Device Info:"
echo "Model: $(getprop ro.product.model)"
echo "Brand: $(getprop ro.product.brand)"
echo "Android: $(getprop ro.build.version.release)"
echo "SDK: $(getprop ro.build.version.sdk)"
echo ""

# ---- Boosting Sequence ----
echo "🧹 Cleaning temporary caches..."
cmd activity call com.android.systemui/.recents.RecentsActivity clearRecentTasks
pm trim-caches 512M >/dev/null 2>&1
echo "✔️ Cache cleaned!"

echo "💪 Optimizing CPU governor..."
cmd device_config put activity_manager max_cached_processes 8
cmd device_config put activity_manager max_running_processes 32
echo "✔️ CPU Optimization done!"

echo "⚡ Boosting graphics & frame pacing..."
cmd device_config put graphics enable_scheduler true
cmd device_config put graphics enable_gpu_optimizations true
cmd device_config put graphics frame_pacing 0
echo "✔️ Graphics optimization applied!"

echo "🚀 Enabling performance mode..."
cmd device_config put game_overlay perf_mode 1
cmd device_config put game_overlay use_system_performance_mode true
echo "✔️ Performance mode enabled!"

echo ""
echo "🔥 FPS Boost Applied Successfully!"
echo "=============================================="
echo "✅ Enjoy smoother gameplay & reduced lag!"
echo "=============================================="