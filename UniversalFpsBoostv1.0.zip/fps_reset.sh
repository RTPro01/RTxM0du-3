#!/bin/bash
# ==============================================
# 🔄 Reset FPS Booster Settings
# ==============================================

echo ""
echo "=============================================="
echo "   ♻️ RESTORING DEFAULT SYSTEM PERFORMANCE"
echo "=============================================="

cmd device_config delete activity_manager max_cached_processes
cmd device_config delete activity_manager max_running_processes
cmd device_config delete graphics enable_scheduler
cmd device_config delete graphics enable_gpu_optimizations
cmd device_config delete graphics frame_pacing
cmd device_config delete game_overlay perf_mode
cmd device_config delete game_overlay use_system_performance_mode

echo ""
echo "✅ System settings restored to default."
echo "=============================================="