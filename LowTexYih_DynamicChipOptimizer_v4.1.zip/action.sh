echo " HI GUYS IM LowTexYíH this is my first time to create basic plugin"
echo " Please support my channel — thank you!"

echo ""
echo "[LowTexYíH Plugins - Dynamic CHIP Gaming Optimizer]"
echo "Version: 4.1"
echo "Purpose: Auto chipset-based gaming optimization"
echo ""

echo "Features included in this module:"
echo ""

echo "NOTE:"
echo "Some devices may restrict or block certain system commands."
echo "Due to manufacturer limits (Xiaomi, Samsung, Oppo, Vivo, Realme, Huawei, etc.),"
echo "this module may work fully, partially, or not at all."
echo "Results depend on device model and Android version."
echo "Use this module at your own risk."
echo ""

echo "1) Smart Chipset Detection"
echo "   • Detects MediaTek / Snapdragon / UNISOC"
echo "   • Applies chipset-specific safe gaming tweaks"
echo "   • Prevents overheating by limiting CPU boost"

echo ""
echo "2) Auto Device Performance Class"
echo "   • Reads RAM size, CPU max frequency, Android version"
echo "   • Classifies device (HIGH / UPPER-MID / MID / LOW)"
echo "   • Automatically selects best downscaleFactor"

echo ""
echo "3) Dynamic FPS & Refresh Rate Control"
echo "   • Locks system refresh rate to stable 60 FPS"
echo "   • Prevents unstable high refresh overheating"
echo "   • Forces GPU rendering for smooth UI"

echo ""
echo "4) Game Overlay Performance Mode"
echo "   • Applies downscaleFactor to ALL installed games"
echo "   • Enables Android Game Performance Mode per app"


echo ""
echo "5) Display & UI Optimization"
echo "   • Disables system animations"
echo "   • Forces match-content frame rate"
echo "   • Disables HDR features that cause stutter"

echo ""
echo "6) Memory & Storage Optimization"
echo "   • Reduces background process pressure"
echo "   • Improves RAM management"
echo "   • Forces periodic storage trim (fstrim)"

echo ""
echo "7) Touch Boost Enhancements"
echo "   • Faster touch response"


echo ""
echo "8) Thermal & Power Safety Mode"
echo "   • Reduces CPU overheating behavior"
echo "   • Disables aggressive boost spikes"
echo "   • Balanced performance for long gaming sessions"

echo ""
echo "9) Cache & System Cleanup"
echo "   • Clears RAM cache on boot"
echo "   • Reduces background lag spikes"

echo ""
echo "All features run automatically — plug & play!"
echo "Safe to uninstall anytime using uninstall.sh"
echo ""