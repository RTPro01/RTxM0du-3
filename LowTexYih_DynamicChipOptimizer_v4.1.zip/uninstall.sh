#!/system/bin/sh
# LowTexYíH Dynamic CHIP FULL Reset & Uninstall Script
# Developer: LowTexYíH @yih855

log() {
  echo "[LowTexYíH RESET] $1"
}


while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

log "Starting FULL system restore..."


log "Resetting refresh rate..."
settings delete system peak_refresh_rate 2>/dev/null
settings delete system min_refresh_rate 2>/dev/null


log "Restoring animations..."
settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1


cmd display set-match-content-frame-rate-pref 0 2>/dev/null
cmd display clear-user-disabled-hdr-types 2>/dev/null


log "Restoring memory settings..."
settings delete global settings_enable_monitor_phantom_procs 2>/dev/null
settings put global app_standby_enabled 1
settings delete global fstrim_mandatory_interval 2>/dev/null


log "Restoring touch settings..."
settings delete secure long_press_timeout
settings delete secure multi_press_timeout

[ -e /sys/module/msm_performance/parameters/touchboost ] && \
echo 0 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null

[ -e /sys/power/pnpmgr/touch_boost ] && \
echo 0 > /sys/power/pnpmgr/touch_boost 2>/dev/null


log "Resetting CPU limits..."
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_max_freq; do
  cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq > "$cpu" 2>/dev/null
done


echo 1 > /sys/module/msm_performance/parameters/cpu_boost 2>/dev/null
echo 1 > /sys/module/msm_performance/parameters/sched_boost_on_input 2>/dev/null


setprop vendor.thermal.throttle.enable true
setprop persist.vendor.mtk.thermal.limit 0


setprop persist.vendor.sys.sprd.log 1
setprop persist.sys.sprd.log 1


setprop debug.hwui.max_fps 0
setprop debug.hwui.force_gpu_rendering false


setprop debug.thermal.throttle.support yes


log "Removing all game overlays..."
for pkg in $(cmd package list packages -3 | cut -f2 -d:); do
  cmd device_config delete game_overlay "$pkg" 2>/dev/null
done


cmd device_config delete game android.os.adpf_prefer_power_efficiency 2>/dev/null
cmd device_config delete game android.os.adpf_hwui_gpu 2>/dev/null


echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

log "LowTexYíH Dynamic CHIP FULL RESET DONE."
log "REBOOT YOUR PHONE FOR FULL EFFECT."