#!/system/bin/sh
logcat -G 128K >/dev/null 2>&1

NAME="🅱️-PerfExt"
VERSION="1.0.0 | PerfExt"
ANDROIDVERSION=$(getprop ro.build.version.release)
DEVICE=$(getprop ro.product.device)
MANUFACTURER=$(getprop ro.product.manufacturer)
DATE=$(date)

echo "==============================="
echo "   $NAME"
echo "   Version : $VERSION"
echo "   Android : ${ANDROIDVERSION:-Unknown}"
echo "   Device  : ${DEVICE:-Unknown}"
echo "   Maker   : ${MANUFACTURER:-Unknown}"
echo "   Date    : $DATE"
echo "==============================="
logcat -c >/dev/null 2>&1

cmd package compile -m speed-profile -f com.android.systemui
setprop debug.performance.tuning 1
cmd window logging disable
settings put global game_driver_prerelease_opt_in_apps ""
cmd accessibility stop-trace
setprop debug.hwui.msaa_sample_count 0
cmd thermalservice override-status 5
settings put global power_save_mode 0
cmd package reconcile-secondary-dex-files com.android.systemui
settings put secure screensaver_activate_on_dock 0
setprop sys.perf.boost true
device_config put runtime_native usap_pool_enabled true
cmd deviceidle whitelist -com.google.android.gms
settings put global adaptive_battery_management_enabled 0
settings put system tran_cpupower_mode 1
settings put global cached_apps_freezer 1
settings put global updatable_driver_prerelease_opt_in_apps ""
cmd thermalservice override-status 6
settings put global updatable_driver_production_denylist ""
setprop sys.perf.fbooster true
cmd window logging stop
cmd deviceidle sys-whitelist -com.google.android.gms
settings put global updatable_driver_prerelease_allowlist ""
cmd device_config put window_manager windowsmgr_max_events_per_sec 260
cmd appops set com.google.android.gms START_FOREGROUND allow
setprop debug.gfx.driver 1
settings put global binder_calls_stats "enabled=false"
cmd window logging disable-text
device_config put runtime_native usap_refill_threshold 1
setprop sys.init.perf_lsm_hooks 0
settings put global game_driver_all_apps 1
settings put system device_idle_constants "inactive_to=8000,idle_after_inactive_to=0,idle_pending_to=25000,idle_factor=1.2"
settings put global updatable_driver_sphal_libraries_filename "sphal_libraries"
cmd device_config put systemui max_event_per_sec 260
cmd device_config put systemui scrollingcache 2
cmd package compile -m speed --compile-layouts -f com.android.systemui
setprop persist.sys.cpu_perf_mode 1
settings put global battery_saver_enabled 0
cmd thermalservice override-status 3
settings put global updatable_driver_production_allowlist "$(cmd package list packages --user 0 | cut -f2 -d: | paste -sd, -)"
setprop sys.force_boost_cpu true
setprop sys.usap.enable true
cmd appops set android SCHEDULE_EXACT_ALARM allow
cmd input_method tracing stop
settings put secure screensaver_enabled 0
cmd settings put global netstats_enabled 1
device_config put runtime_native usap_pool_size_min 1
settings put global updatable_driver_production_opt_in_apps "$(cmd package list packages --user 0 | cut -f2 -d: | paste -sd, -)"
cmd appops set android WAKE_LOCK allow
cmd package compile -m speed -f com.android.systemui
device_config put interaction_jank_monitor enabled false
setprop debug.hwui.disable_msaa true
settings put global background_activity_starts_enabled 1
cmd power set-fixed-performance-mode-enabled 1
setprop debug.egl.force_msaa false
settings put global sustained_performance_mode_enabled 1
cmd package force-dex-opt com.android.systemui
setprop debug.gralloc.enable_fb_ubwc 1
setprop debug.vulkan.enable_msaa 0
setprop sys.perf.schd true
device_config put activity_manager disable_app_profiler_pss_profiling true
settings put global game_driver_opt_out_apps ""
cmd device_config put window_manager hardware_accelerated true
settings put global game_driver_whitelist ""
settings put global system_exempt_power_restrictions_enabled true
setprop persist.sys.usap_pool_enabled true
settings put global kill_bg_restricted_cached_idle true
settings put global low_power 0
cmd device_config put systemui min_fling_velocity 13000
settings put global game_driver_production_opt_in_apps ""
cmd appops set com.google.android.gms RUN_IN_BACKGROUND allow
setprop sys.trancare.performance.latency 1
settings put global game_driver_sphal_libraries "sphal_libraries"
cmd thermalservice override-status 4
settings put global updatable_driver_prerelease_denylist ""
settings put global updatable_driver_production_opt_out_apps ""
setprop debug.gralloc.map_fb_memory 0
settings put global updatable_driver_production_denylist ""
settings put global power_save_mode 0
setprop debug.gralloc.gfx_ubwc_disable 0
settings put global updatable_driver_all_apps 1
cmd device_config put systemui max_fling_velocity 26000
settings put global activity_manager_constants "proactive_kills_enabled=true,kill_bg_restricted_cached_idle=true,system_exempt_power_restrictions_enabled=true,low_swap_threshold_percent=40"
device_config put runtime_native usap_pool_size_max 4
cmd appops set com.google.android.gms RUN_ANY_IN_BACKGROUND allow
settings put global sustained_performance_mode_enabled 1
settings put global game_driver_blacklists ""
setprop debug.hwui.msaa_sample_count 0
setprop debug.vulkan.enable_msaa 0
settings put global updatable_driver_prerelease_opt_in_apps ""
settings put global adaptive_battery_management_enabled 0
cmd window tracing stop
cmd appops set android WAKE_LOCK allow
setprop sys.perf.tbooster true
cmd appops set com.google.android.gms RUN_ANY_IN_BACKGROUND allow
setprop persist.sys.force_highendgfx true
settings put global game_driver_opt_in_apps "$(cmd package list packages --user 0 | cut -f2 -d: | paste -sd, -)"
setprop debug.gralloc.disable_ahardware_buffer 0
cmd deviceidle whitelist -com.google.android.gms
cmd device_config put systemui max_event_per_sec 260
device_config put runtime_native usap_pool_refill_delay_ms 25
cmd deviceidle sys-whitelist -com.google.android.gms
cmd power set-adaptive-power-saver-enabled 0
settings put global cached_apps_freezer 1
settings put system tran_cpupower_mode 1
cmd window logging disable-text
cmd device_config put window_manager windowsmgr_max_events_per_sec 260
settings put global game_driver_prerelease_allowlist ""
setprop security.perf_harden 0
setprop sys.trancare.performance 1
am kill-all
cmd battery reset
pm trim-caches 999G
for part in system vendor data cache metadata odm system_ext product; do
    sm fstrim "/$part" >/dev/null 2>&1
done
for dir in /data/data/*; do
    [ -d "$dir" ] && {
        rm -rf "$dir"/cache/* "$dir"/code_cache/* "$dir"/no_backup/* "$dir"/app_webview/* 2>/dev/null
    }
done

find /data/user_de/*/*/cache/* -delete >/dev/null 2>&1
find /data/user_de/*/*/code_cache/* -delete >/dev/null 2>&1
find /sdcard/Android/data/*/cache/* -delete >/dev/null 2>&1

cmd notification post -S bigtext -t '🅱️-PerfExt' '✅' "Tweak Activated"