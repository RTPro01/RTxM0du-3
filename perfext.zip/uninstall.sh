#!/system/bin/sh

settings delete global binder_calls_stats
settings delete secure screensaver_enabled
settings delete secure screensaver_activate_on_dock
settings delete system haptic_feedback_disable
settings delete global cached_apps_freezer
settings delete global activity_manager_constants
settings delete system device_idle_constants
cmd settings delete global netstats_enabled
cmd power set-fixed-performance-mode-enabled 0
cmd power set-adaptive-power-saver-enabled 1
settings delete global sustained_performance_mode_enabled
settings delete global low_power
settings delete global power_save_mode
settings delete global adaptive_battery_management_enabled
settings delete global battery_saver_enabled
cmd thermalservice reset-thermal-status
cmd package compile --reset com.android.systemui
cmd package clear-dexopt com.android.systemui
cmd package reconcile-secondary-dex-files com.android.systemui
setprop sys.force_boost_cpu ""
setprop sys.perf.boost ""
setprop sys.perf.schd ""
setprop sys.perf.tbooster ""
setprop sys.perf.fbooster ""
setprop persist.sys.cpu_perf_mode ""
setprop debug.hwui.disable_msaa ""
setprop debug.hwui.msaa_sample_count ""
setprop debug.egl.force_msaa ""
setprop debug.vulkan.enable_msaa ""
setprop debug.performance.tuning ""
setprop security.perf_harden ""
setprop sys.init.perf_lsm_hooks ""
setprop sys.trancare.performance ""
setprop sys.trancare.performance.latency ""
settings delete system tran_cpupower_mode
setprop debug.usap_pool_enabled ""
setprop persist.sys.usap_pool_enabled ""
setprop sys.usap.enable ""
device_config delete runtime_native usap_pool_enabled
device_config delete runtime_native usap_refill_threshold
device_config delete runtime_native usap_pool_size_max
device_config delete runtime_native usap_pool_size_min
device_config delete runtime_native usap_pool_refill_delay_ms
device_config delete activity_manager disable_app_profiler_pss_profiling
device_config delete interaction_jank_monitor enabled
cmd deviceidle whitelist +com.google.android.gms
cmd deviceidle sys-whitelist +com.google.android.gms
cmd appops reset com.google.android.gms
cmd appops reset android
cmd device_config delete systemui max_fling_velocity
cmd device_config delete systemui min_fling_velocity
cmd device_config delete systemui max_event_per_sec
cmd device_config delete systemui scrollingcache
cmd device_config delete window_manager windowsmgr_max_events_per_sec
cmd device_config delete window_manager hardware_accelerated
settings delete global game_driver_preference
settings delete global game_driver_all_apps
settings delete global updatable_driver_all_apps
settings delete global game_driver_sphal_libraries
settings delete global updatable_driver_sphal_libraries_filename
settings delete global game_driver_blacklists
settings delete global game_driver_whitelist
settings delete global updatable_driver_production_allowlist
settings delete global updatable_driver_production_opt_in_apps
settings delete global updatable_driver_production_denylist
settings delete global updatable_driver_prerelease_allowlist
settings delete global updatable_driver_prerelease_opt_in_apps
settings delete global updatable_driver_prerelease_denylist
settings delete global game_driver_opt_in_apps
settings delete global game_driver_opt_out_apps
cmd battery reset

cmd notification post -S bigtext -t '🅱️-PerfExt' '🛑' " uninstalled(reboot recommended)"