#!/system/bin/sh
# LowTexYíH 6.3 Enhanced
#ano ?? nakaw naman haha naku dika kikita dyan boyyyy?!
log() {
    echo "[LowTexYíH 6.3 Enhanced] $1"
}


while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

log "Boot complete. Applying LongPlay Enhancements..."

GAME="com.garena.game.codm"
ANDROID_VER=$(getprop ro.build.version.release | cut -d. -f1)




log "Performing RAM boost / cleanup..."


am kill-all

log "RAM boost / cleanup done (no data loss)"



setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.early_app_phase_offset_ns 600000
setprop debug.sf.early_sf_phase_offset_ns 600000
setprop debug.sf.late_app_phase_offset_ns 900000
setprop debug.sf.late_sf_phase_offset_ns 900000
setprop debug.sf.max_frame_buffer_acquired_buffers 3

log "SurfaceFlinger timing tuned"





setprop debug.renderengine.backend skiaglthreaded
setprop debug.renderengine.enable_async_cache 1
setprop debug.renderengine.frame_submission_limit 3
settings put global angle_gl_driver_selection_pkgs com.garena.game.codm
‎settings put global angle_gl_driver_selection_values egl

log "RenderEngine enhanced"





settings put global activity_manager_constants \
"max_cached_processes=28,service_restart_duration=7000,fgservice_min_shown_time=2500,content_provider_retain_time=15000"

settings put global background_process_limit 4

log "Memory & service stability applied"





settings put global alarm_manager_constants \
"min_interval=60000,allow_while_idle_short_time=5000,max_batched_delay=15000"

settings put global sync_max_retry_delay_in_seconds 3600
settings put global connectivity_metrics_buffer_size 2000


settings put global background_throttling_enable 1
settings put global background_throttling_limit 50

log "Background alarm, sync, and I/O throttling applied"





settings put system pointer_speed 6
settings put global tap_timeout 80
settings put global long_press_timeout 300
settings put global multi_press_timeout 200

log "Input & touch stability applied"





if [ "$ANDROID_VER" -ge 13 ]; then
    cmd device_config override game android.os.adpf_predict_frame_time true
    cmd device_config override game android.os.adpf_sustained_performance_mode true
    log "Android 13+ sustained performance hints applied"
fi





cmd appops set "$GAME" WAKE_LOCK allow
cmd appops set "$GAME" RUN_ANY_IN_BACKGROUND allow
dumpsys deviceidle whitelist +"$GAME"

log "LowTexYíH 6.3 Enhanced Applied Successfully Nr"