#!/system/bin/sh

echo "[🔋] ENABLING BATTERY SAVER BY SASUKE TWEAKS..."

#  Enable System Battery Saver
settings put global low_power 1
settings put global battery_saver_constants advertise_is_enabled=true

# Disable Performance Boosts
settings put global force_gpu_rendering 0
settings put global hardware_acceleration_enabled 0
setprop video.accelerate.hw 0
setprop debug.performance.tuning 0

# Optimize System Animations
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0

# Enable Adaptive Battery & Doze
settings put global adaptive_battery_management_enabled 1
settings put global app_standby_enabled 1
dumpsys deviceidle enable

# Restrict Background Activity for Apps
am set-standby-bucket com.garena.game.codm rare
am set-standby-bucket com.mobile.legends rare

# Clear Memory
am kill-all
sync
echo 3 > /proc/sys/vm/drop_caches

echo "[✅] APPLY TWEAKS"