#!/system/bin/sh

echo "[🔋] ENABLING BATTERY SAVER BY SASUKE TWEAKS..."

#  Enable System Battery Saver
settings put global low_power 0
settings put global battery_saver_constants advertise_is_enabled=false

# Disable Performance Boosts
settings put global force_gpu_rendering 1
settings put global hardware_acceleration_enabled 1
setprop video.accelerate.hw 1
setprop debug.performance.tuning 1

# Optimize System Animations
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0

# Enable Adaptive Battery & Doze
settings put global adaptive_battery_management_enabled 0
settings put global app_standby_enabled 0
dumpsys deviceidle disable

# Restrict Background Activity for Apps
am set-standby-bucket com.garena.game.codm rare
am set-standby-bucket com.mobile.legends rare

# Clear Memory
am kill-all
sync
echo 3 > /proc/sys/vm/drop_caches

echo "[✅] APPLY TWEAKS"