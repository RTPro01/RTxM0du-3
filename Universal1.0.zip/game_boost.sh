#!/system/bin/sh
# ============================================
# 🚀 UNIVERSAL GAME BOOSTER (NON-ROOT)
# Safe for Android 10–14
# Author: Rai Gaming PH
# ============================================

# Colors
green='\033[1;32m'
yellow='\033[1;33m'
blue='\033[1;34m'
red='\033[1;31m'
nc='\033[0m' # No Color

clear
echo -e "${blue}"
echo "============================================"
echo "          🚀 GAME BOOST MODE ACTIVATED       "
echo "============================================"
echo -e "${nc}"

# ----------------------------
# 📱 Device Info
# ----------------------------
echo -e "${yellow}🔍 Collecting device information...${nc}"
brand=$(getprop ro.product.brand)
model=$(getprop ro.product.model)
android=$(getprop ro.build.version.release)
sdk=$(getprop ro.build.version.sdk)
soc=$(getprop ro.soc.model)
ram=$(grep MemTotal /proc/meminfo | awk '{print $2/1024 " MB"}')

echo -e "${green}"
echo "📱 Brand     : $brand"
echo "📦 Model     : $model"
echo "🤖 Android   : $android (SDK $sdk)"
echo "⚙️  SoC       : ${soc:-Unknown}"
echo "💾 RAM Total : $ram"
echo -e "${nc}"

sleep 1
echo -e "${blue}Applying performance and graphics tweaks...${nc}"
sleep 1

apply_prop() {
  local key="$1"
  local value="$2"
  cmd device_config put graphics "$key" "$value"
  setprop "$key" "$value"
  echo -e "${green}[OK]${nc} $key → $value"
}

# ----------------------------
# ⚡ Graphics & Rendering Boost
# ----------------------------
apply_prop enable_frame_rate_override true
apply_prop enable_gpu_acceleration true
apply_prop enable_hwc_vds false
apply_prop enable_skia_atrace true
apply_prop skia.reduce_gpu_context_priority false
apply_prop use_vulkan true

settings put global enable_gpu_debug_layers 1
settings put global debug.hwui.render_dirty_regions false
settings put global debug.hwui.disable_vsync true
settings put global debug.egl.hw 1
settings put global debug.sf.hw 1
settings put global debug.composition.type gpu

# ----------------------------
# 🖥️ SurfaceFlinger & Display
# ----------------------------
settings put global surface_flinger.max_frame_buffer_acquired_buffers 3
settings put global surface_flinger.use_frame_rate_api true
settings put global surface_flinger.force_hw_ui true

# ----------------------------
# ⚙️ CPU Scheduler & Power Hints
# ----------------------------
cmd device_config put activity_manager max_cached_processes 8
settings put global animator_duration_scale 0.0
settings put global transition_animation_scale 0.0
settings put global window_animation_scale 0.0

# ----------------------------
# 🧠 RAM & Background Management
# ----------------------------
settings put global low_power 0
settings put global app_standby_enabled 0
settings put global activity_manager_constants "max_cached_processes=6"

# ----------------------------
# 🧩 Misc Lag Fixes
# ----------------------------
settings put global thermal_event_timeout 0
settings put global zram_enabled 1
settings put global sys.use_fifo_ui true
settings put global debug.performance.tuning 1
settings put global profiler.force_disable_err_rpt 1
settings put global profiler.force_disable_ulog 1

# ----------------------------
# 🎮 Game Boost Focus
# ----------------------------
apply_prop boost.game.fps_boost true
apply_prop boost.game.low_latency true
apply_prop boost.game.disable_jank true
apply_prop boost.game.render_thread_priority 10

echo ""
echo -e "${green}✅ Game Boost Applied Successfully!${nc}"
echo -e "${yellow}⚠️  Restart your game or reboot device for best performance.${nc}"
echo ""
echo -e "${blue}============================================"
echo "         GAME BOOST MODE COMPLETED"
echo "============================================${nc}"