#!/system/bin/sh
# ============================================
# 🔄 RESET GAME BOOST SETTINGS (NON-ROOT)
# Safe for Android 10–14
# Author: Rai Gaming PH
# ============================================

green='\033[1;32m'
yellow='\033[1;33m'
blue='\033[1;34m'
red='\033[1;31m'
nc='\033[0m'

clear
echo -e "${red}"
echo "============================================"
echo "       🔄 RESET GAME BOOST SETTINGS          "
echo "============================================"
echo -e "${nc}"

echo -e "${yellow}📱 Gathering device info...${nc}"
brand=$(getprop ro.product.brand)
model=$(getprop ro.product.model)
android=$(getprop ro.build.version.release)
sdk=$(getprop ro.build.version.sdk)
echo -e "${green}Device: $brand $model ($android / SDK $sdk)${nc}"
sleep 1

reset_prop() {
  local key="$1"
  cmd device_config delete graphics "$key"
  resetprop -p "$key" || true
  echo -e "${green}[RESET]${nc} $key"
}

echo -e "${blue}Restoring default performance values...${nc}"
sleep 1

# ----------------------------
# 🎯 Reset Graphics Properties
# ----------------------------
reset_prop enable_frame_rate_override
reset_prop enable_gpu_acceleration
reset_prop enable_hwc_vds
reset_prop enable_skia_atrace
reset_prop skia.reduce_gpu_context_priority
reset_prop use_vulkan

# ----------------------------
# 🎯 Reset Global Settings
# ----------------------------
settings delete global surface_flinger.max_frame_buffer_acquired_buffers
settings delete global surface_flinger.force_hw_ui
settings put global animator_duration_scale 1.0
settings put global transition_animation_scale 1.0
settings put global window_animation_scale 1.0

settings delete global debug.sf.hw
settings delete global debug.egl.hw
settings delete global debug.hwui.render_dirty_regions
settings delete global debug.hwui.disable_vsync
settings delete global debug.composition.type
settings delete global app_standby_enabled
settings delete global activity_manager_constants
settings delete global low_power

echo ""
echo -e "${green}✅ All performance and graphics settings restored to default.${nc}"
echo ""
echo -e "${blue}============================================"
echo "             RESET COMPLETE"
echo "============================================${nc}"