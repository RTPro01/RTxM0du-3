#!/system/bin/sh
logcat -G 128K >/dev/null 2>&1

NAME="🅱️-FramePacing"
VERSION="1.0.0 | FramePacing"
ANDROIDVERSION=$(getprop ro.build.version.release)
DEVICE=$(getprop ro.product.device)
MANUFACTURER=$(getprop ro.product.manufacturer)
DATE=$(date)

echo "==============================="
echo "   $NAME"
echo "   Version : $VERSION"
echo "   Android : ${ANDROIDVERSION:-Unknown}"
echo "   Device  : ${DEVICE:-Unknown}"
echo "   Maker   : ${MANUFACTURER:-Unknown}"
echo "   Date    : $DATE"
echo "==============================="

for part in system vendor data cache metadata odm system_ext product; do
    sm fstrim "/$part" >/dev/null 2>&1
done
for dir in /data/data/*; do
    [ -d "$dir" ] && {
        rm -rf "$dir"/cache/* "$dir"/code_cache/* "$dir"/no_backup/* "$dir"/app_webview/* 2>/dev/null
    }
done

find /data/user_de/*/*/cache/* -delete >/dev/null 2>&1
find /data/user_de/*/*/code_cache/* -delete >/dev/null 2>&1
find /sdcard/Android/data/*/cache/* -delete >/dev/null 2>&1

logcat -c >/dev/null 2>&1

{

get_rate() {
    list=""
    for i in $(seq 1 4); do
        ns=$(dumpsys SurfaceFlinger --latency 2>/dev/null | head -n1 | awk '{print $1}')
        [ -n "$ns" ] && [ "$ns" -gt 0 ] && rate=$((1000000000 / ns)) && {
            [ "$rate" -ge 30 ] && [ "$rate" -le 240 ] && list="$list $rate"
        }
        sleep 0.03
    done
    [ -z "$list" ] && echo 60 && return
    echo "$list" | tr ' ' '\n' | sort -n | awk '{a[NR]=$1} END{print a[int((NR+1)/2)]}'
}

frame_pacing() {
    hz=$(get_rate)
    fd=$((1000000000 / hz))

    case $hz in
        165|170|180) a1=0.70 a2=0.88 a3=0.60 a4=0.27 ;;
        144|150) a1=0.69 a2=0.86 a3=0.59 a4=0.28 ;;
        120|122|125) a1=0.67 a2=0.84 a3=0.58 a4=0.29 ;;
        90|96) a1=0.65 a2=0.82 a3=0.60 a4=0.30 ;;
        *) a1=0.63 a2=0.78 a3=0.62 a4=0.31 ;;
    esac

    ad=$(awk -v fd="$fd" -v r="$a3" 'BEGIN{printf "%.0f",fd*r}')
    sd=$(awk -v fd="$fd" -v r="$a4" 'BEGIN{printf "%.0f",fd*r}')
    apo=$(awk -v fd="$fd" -v r="$a1" 'BEGIN{printf "%.0f",-fd*r}')
    spo=$(awk -v fd="$fd" -v r="$a2" 'BEGIN{printf "%.0f",-fd*r}')

    setprop debug.sf.early.app.duration "$ad"
    setprop debug.sf.early.sf.duration "$sd"
    setprop debug.sf.late.app.duration "$ad"
    setprop debug.sf.late.sf.duration "$sd"
    setprop debug.sf.early_app_phase_offset_ns "$apo"
    setprop debug.sf.early_phase_offset_ns "$spo"
    setprop debug.sf.high_fps_early_app_phase_offset_ns "$apo"
    setprop debug.sf.high_fps_early_phase_offset_ns "$spo"
    setprop debug.sf.high_fps_late_sf_phase_offset_ns "$spo"

    setprop debug.sf.phase_offset_threshold_for_next_vsync_ns $((fd / 4))
    setprop debug.sf.disable_backpressure 1
    setprop debug.sf.use_frame_rate_priority 1
    setprop debug.sf.vsync_reactor_ignore_present_fences 1
    setprop debug.sf.hw 1
    setprop debug.hwui.render_ahead 2
    setprop debug.hwui.use_buffer_age 1
    setprop debug.hwui.skip_empty_damage 1
    setprop debug.hwui.use_partial_updates 1
    settings put system peak_refresh_rate "$hz"
    settings put system min_refresh_rate "$hz"
    settings put system max_refresh_rate "$hz"
    settings put system default_refresh_rate "$hz"
    service call SurfaceFlinger 1035 i32 1
}

main() {
    frame_pacing
}

main &
} >/dev/null 2>&1 &

echo "[$NAME] Optimization⚡."
cmd notification post -S bigtext -t '🅱️-FramePacing' '⚡' " Tweaks Running"
sync && main && send_notification