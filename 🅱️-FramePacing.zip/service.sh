#!/system/bin/sh
logcat -G 128K >/dev/null 2>&1

NAME="🅱️-FramePacing"
VERSION="2.5.0 | FramePacing"
ANDROIDVERSION=$(getprop ro.build.version.release)
DEVICE=$(getprop ro.product.device)
MANUFACTURER=$(getprop ro.product.manufacturer)
DATE=$(date)

echo "==============================="
echo "   $NAME"
echo "   Version : $VERSION"
echo "   Android : ${ANDROIDVERSION:-Unknown}"
echo "   Device  : ${DEVICE:-Unknown}"
echo "   Maker   : ${MANUFACTURER:-Unknown}"
echo "   Date    : $DATE"
echo "==============================="

for part in system vendor data cache metadata odm system_ext product; do
    sm fstrim "/$part" >/dev/null 2>&1
done
for dir in /data/data/*; do
    [ -d "$dir" ] && {
        rm -rf "$dir"/cache/* "$dir"/code_cache/* "$dir"/no_backup/* "$dir"/app_webview/* 2>/dev/null
    }
done

find /data/user_de/*/*/cache/* -delete >/dev/null 2>&1
find /data/user_de/*/*/code_cache/* -delete >/dev/null 2>&1
find /sdcard/Android/data/*/cache/* -delete >/dev/null 2>&1

logcat -c >/dev/null 2>&1


R="\033[31m"
G="\033[32m"
Y="\033[33m"
B="\033[34m"
P="\033[35m"
C="\033[36m"
W="\033[37m"
N="\033[0m"

line() {
  echo -e "${B}────────────────────────────────────${N}"
}

echo -e "${P}===== DISPLAY & REFRESH RATE =====${N}"
echo -e "${C}System Peak  : ${W}$(settings get system peak_refresh_rate)${N}"
echo -e "${C}Secure Peak  : ${W}$(settings get secure peak_refresh_rate)${N}"
echo -e "${C}System Min   : ${W}$(settings get system min_refresh_rate)${N}"
echo -e "${C}Global Lock  : ${W}$(settings get global refresh_rate)${N}"

echo
line
echo -e "${P}===== SURFACEFLINGER APP DURATION (ns) =====${N}"
echo -e "${G}Early App        : ${W}$(getprop debug.sf.early.app.duration)${N}"
echo -e "${G}Late App         : ${W}$(getprop debug.sf.late.app.duration)${N}"
echo -e "${G}HFPS Early App   : ${W}$(getprop debug.sf.high_fps.early.app.duration)${N}"
echo -e "${G}HFPS Late App    : ${W}$(getprop debug.sf.high_fps.late.app.duration)${N}"

echo
line
echo -e "${P}===== SURFACEFLINGER SF DURATION (ns) =====${N}"
echo -e "${Y}Early SF         : ${W}$(getprop debug.sf.early.sf.duration)${N}"
echo -e "${Y}Late SF          : ${W}$(getprop debug.sf.late.sf.duration)${N}"
echo -e "${Y}HFPS Early SF    : ${W}$(getprop debug.sf.high_fps.early.sf.duration)${N}"
echo -e "${Y}HFPS Late SF     : ${W}$(getprop debug.sf.high_fps.late.sf.duration)${N}"

echo
line
echo -e "${P}===== VSYNC PHASE OFFSET (ns) =====${N}"
echo -e "${C}App Early Offset : ${W}$(getprop debug.sf.early.app.phase_offset_ns)${N}"
echo -e "${C}App Late Offset  : ${W}$(getprop debug.sf.late.app.phase_offset_ns)${N}"
echo -e "${C}HFPS App Early   : ${W}$(getprop debug.sf.high_fps.early.app.phase_offset_ns)${N}"
echo -e "${C}HFPS App Late    : ${W}$(getprop debug.sf.high_fps.late.app.phase_offset_ns)${N}"

echo -e "${C}SF Early Offset  : ${W}$(getprop debug.sf.early.sf.phase_offset_ns)${N}"
echo -e "${C}SF Late Offset   : ${W}$(getprop debug.sf.late.sf.phase_offset_ns)${N}"
echo -e "${C}HFPS SF Early    : ${W}$(getprop debug.sf.high_fps.early.sf.phase_offset_ns)${N}"
echo -e "${C}HFPS SF Late     : ${W}$(getprop debug.sf.high_fps.late.sf.phase_offset_ns)${N}"

line() {
  echo -e "${B}────────────────────────────────────${N}"
}


alias SP="setprop"
alias STS="settings put secure"
alias STG="settings put global"
alias STY="settings put system"

FPSI=$(dumpsys display 2>/dev/null | grep -Eo 'refreshRate=[0-9]+(\.[0-9]+)?' | cut -d= -f2 | sort -nr | head -n1)
[ -z "$FPSI" ] && FPSI=60
FPSI=${FPSI%.*}
[ "$FPSI" -lt 60 ] && FPSI=60
[ "$FPSI" -gt 240 ] && FPSI=240

FRAME_NS=$((1000000000 / FPSI))

case $FPSI in
165|170|180) EA=60 LA=82 ES=30 LS=52 ;;
144|150)     EA=59 LA=80 ES=31 LS=53 ;;
120|125)     EA=58 LA=78 ES=32 LS=54 ;;
90|96)       EA=60 LA=76 ES=33 LS=55 ;;
*)           EA=62 LA=74 ES=34 LS=56 ;;
esac

EARLY_APP=$((FRAME_NS * EA / 100))
LATE_APP=$((FRAME_NS * LA / 100))
EARLY_SF=$((FRAME_NS * ES / 100))
LATE_SF=$((FRAME_NS * LS / 100))

OFFSET_EARLY=$((-(FRAME_NS * 35 / 100)))
OFFSET_LATE=$((-(FRAME_NS * 45 / 100)))

SP debug.sf.use_phase_offsets_as_durations 1
SP debug.sf.vsync_reactor 1
SP debug.sf.vsync_reactor_apply_phase_offsets 1
SP debug.sf.enable_vsync_immed 1
SP debug.sf.disable_backpressure 0
SP debug.sf.latch_unsignaled true
SP debug.sf.max_frame_latency 1
SP debug.sf.use_frame_rate_priority 1
SP debug.sf.phase_offset_threshold_for_next_vsync_ns $((FRAME_NS / 4))

SP debug.sf.early.app.duration "$EARLY_APP"
SP debug.sf.late.app.duration "$LATE_APP"
SP debug.sf.high_fps.early.app.duration "$EARLY_APP"
SP debug.sf.high_fps.late.app.duration "$LATE_APP"

SP debug.sf.early.sf.duration "$EARLY_SF"
SP debug.sf.late.sf.duration "$LATE_SF"
SP debug.sf.high_fps.early.sf.duration "$EARLY_SF"
SP debug.sf.high_fps.late.sf.duration "$LATE_SF"

SP debug.sf.early.app.phase_offset_ns "$OFFSET_EARLY"
SP debug.sf.late.app.phase_offset_ns "$OFFSET_LATE"
SP debug.sf.high_fps.early.app.phase_offset_ns "$OFFSET_EARLY"
SP debug.sf.high_fps.late.app.phase_offset_ns "$OFFSET_LATE"

SP debug.sf.early.sf.phase_offset_ns "$OFFSET_EARLY"
SP debug.sf.late.sf.phase_offset_ns "$OFFSET_LATE"
SP debug.sf.high_fps.early.sf.phase_offset_ns "$OFFSET_EARLY"
SP debug.sf.high_fps.late.sf.phase_offset_ns "$OFFSET_LATE"

CALLBACK_US=$((1000000 / FPSI))
SP debug.choreographer.callback "$CALLBACK_US"
SP debug.choreographer.low_latency 1
SP debug.choreographer.zero_jitter 1
SP debug.choreographer.skipwarning "$FPSI"

SP debug.input.lowlatency 1
SP debug.touchscreen.latency.scale 0.0
SP debug.sf.default_touch_timer_ms 0
SP debug.sf.set_touch_timer_ms 0

SP debug.hwui.use_buffer_age 1
SP debug.hwui.enable_buffer_queue_pacing 1
SP debug.hwui.skip_empty_damage 1
SP debug.hwui.use_partial_updates 1
SP debug.hwui.disable_vsync 0

SP debug.egl.swapinterval 1
SP debug.gr.swapinterval 1

SP debug.refresh_rate.min_fps "$FPSI"
SP debug.refresh_rate.max_fps "$FPSI"
SP debug.javafx.animation.framerate "$FPSI"

SP persist.sys.smartfps 0
SP persist.sys.autofps.mode 0
SP persist.sys.fpsctrl.enable 0

STS peak_refresh_rate "$FPSI"
STS min_refresh_rate "$FPSI"
STS user_refresh_rate "$FPSI"

STG refresh_rate "$FPSI"
STG min_refresh_rate "$FPSI"
STG max_refresh_rate "$FPSI"

STY default_refresh_rate "$FPSI"
STY min_refresh_rate "$FPSI"
STY max_refresh_rate "$FPSI"

STG animator_duration_scale 0.35
STG transition_animation_scale 0.35
STG window_animation_scale 0.35

cmd notification post -S bigtext -t '🅱️-FramePacing' '⚡' " Tweaks Activated"

echo "[$NAME] Optimization⚡."