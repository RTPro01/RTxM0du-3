
#Modules By Bgaszz
##############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################
#  IMPORTANT NOTICE - DO NOT COPY, USE, OR DISTRIBUTE THIS CODE WITHOUT PERMISSION! THIS SCRIPT IS THE RESULT OF EXTENSIVE RESEARCH, COUNTLESS HOURS OF TESTING, AND HIGHLY SPECIALIZED OPTIMIZATION. EVERY SINGLE LINE HERE HAS BEEN CAREFULLY CRAFTED TO ACHIEVE MAXIMUM PERFORMANCE, STABILITY, AND EFFICIENCY. IT IS NOT A RANDOM COLLECTION OF COMMANDS — IT IS A HIGHLY CUSTOMIZED AND REFINED CONFIGURATION CREATED THROUGH A LONG PROCESS OF EXPERIMENTATION AND TROUBLESHOOTING. 
#  ANY UNAUTHORIZED COPYING OR SHARING IS STRICTLY PROHIBITED AND MAY RESULT IN UNINTENDED CONSEQUENCES ON OTHER DEVICES. THIS SCRIPT IS DESIGNED FOR SPECIFIC PURPOSES AND HARDWARE PROFILES — USING IT IMPROPERLY MAY DAMAGE SYSTEM PERFORMANCE OR CAUSE IRREVERSIBLE ISSUES. 
#  IF YOU HAVE OBTAINED THIS SCRIPT FROM ANY SOURCE OTHER THAN THE ORIGINAL CREATOR, YOU ARE STRONGLY ADVISED TO STOP AND REQUEST THE OFFICIAL VERSION DIRECTLY FROM THE AUTHOR. 
#  REMEMBER: RESPECT THE TIME, EFFORT, AND DEDICATION PUT INTO DEVELOPING THIS. THIS IS NOT JUST “A BUNCH OF CODE” — IT REPRESENTS DAYS, WEEKS, AND POSSIBLY MONTHS OF DETAILED WORK, TUNING, AND VERIFICATION. TREAT IT ACCORDINGLY.
##############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################
{

reset_display() {
    setprop debug.sf.early.app.duration ""
    setprop debug.sf.early.sf.duration ""
    setprop debug.sf.late.app.duration ""
    setprop debug.sf.late.sf.duration ""
    setprop debug.sf.early_app_phase_offset_ns ""
    setprop debug.sf.early_phase_offset_ns ""
    setprop debug.sf.high_fps_early_app_phase_offset_ns ""
    setprop debug.sf.high_fps_early_phase_offset_ns ""
    setprop debug.sf.high_fps_late_sf_phase_offset_ns ""
    setprop debug.sf.phase_offset_threshold_for_next_vsync_ns ""
    setprop debug.sf.disable_backpressure 0
    setprop debug.sf.use_frame_rate_priority 0
    setprop debug.sf.vsync_reactor_ignore_present_fences 0
    setprop debug.sf.hw 0
    setprop debug.hwui.render_ahead 1
    setprop debug.hwui.use_buffer_age 0
    setprop debug.hwui.skip_empty_damage 0
    setprop debug.hwui.use_partial_updates 0
    settings delete system peak_refresh_rate
    settings delete system min_refresh_rate
    settings delete system max_refresh_rate
    settings delete system default_refresh_rate
    service call SurfaceFlinger 1035 i32 0
}

main() {
    reset_display
}

main &
} >/dev/null 2>&1 &
cmd notification post -S bigtext -t '🅱️-FramePacing' '🛑' " stopped"
