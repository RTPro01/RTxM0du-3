#!/system/bin/sh

alias SP="setprop"
alias STS="settings delete secure"
alias STG="settings delete global"
alias STY="settings delete system"

SP debug.sf.use_phase_offsets_as_durations ""
SP debug.sf.vsync_reactor ""
SP debug.sf.vsync_reactor_apply_phase_offsets ""
SP debug.sf.enable_vsync_immed ""
SP debug.sf.disable_backpressure ""
SP debug.sf.latch_unsignaled ""
SP debug.sf.max_frame_latency ""
SP debug.sf.use_frame_rate_priority ""
SP debug.sf.phase_offset_threshold_for_next_vsync_ns ""

SP debug.sf.early.app.duration ""
SP debug.sf.late.app.duration ""
SP debug.sf.high_fps.early.app.duration ""
SP debug.sf.high_fps.late.app.duration ""

SP debug.sf.early.sf.duration ""
SP debug.sf.late.sf.duration ""
SP debug.sf.high_fps.early.sf.duration ""
SP debug.sf.high_fps.late.sf.duration ""

SP debug.sf.early.app.phase_offset_ns ""
SP debug.sf.late.app.phase_offset_ns ""
SP debug.sf.high_fps.early.app.phase_offset_ns ""
SP debug.sf.high_fps.late.app.phase_offset_ns ""

SP debug.sf.early.sf.phase_offset_ns ""
SP debug.sf.late.sf.phase_offset_ns ""
SP debug.sf.high_fps.early.sf.phase_offset_ns ""
SP debug.sf.high_fps.late.sf.phase_offset_ns ""

SP debug.choreographer.callback ""
SP debug.choreographer.low_latency ""
SP debug.choreographer.zero_jitter ""
SP debug.choreographer.skipwarning ""

SP debug.input.lowlatency ""
SP debug.touchscreen.latency.scale ""
SP debug.sf.default_touch_timer_ms ""
SP debug.sf.set_touch_timer_ms ""

SP debug.hwui.use_buffer_age ""
SP debug.hwui.enable_buffer_queue_pacing ""
SP debug.hwui.skip_empty_damage ""
SP debug.hwui.use_partial_updates ""
SP debug.hwui.disable_vsync ""

SP debug.egl.swapinterval ""
SP debug.gr.swapinterval ""

SP debug.refresh_rate.min_fps ""
SP debug.refresh_rate.max_fps ""
SP debug.javafx.animation.framerate ""

SP persist.sys.smartfps ""
SP persist.sys.autofps.mode ""
SP persist.sys.fpsctrl.enable ""

STS peak_refresh_rate
STS min_refresh_rate
STS user_refresh_rate

STG refresh_rate
STG min_refresh_rate
STG max_refresh_rate

STY default_refresh_rate
STY min_refresh_rate
STY max_refresh_rate

STG animator_duration_scale
STG transition_animation_scale
STG window_animation_scale

service call SurfaceFlinger 1035 i32 0 >/dev/null 2>&1
cmd notification post -S bigtext -t '🅱️-FramePacing' '🛑' " stopped"