#!/bin/bash

# Welcome Banner
sleep 1
echo ""
echo " 
█▀▄ █ █▀ ▄▀█ █▄▄ █░░ █▀▀
█▄▀ █ ▄█ █▀█ █▄█ █▄▄ ██▄

▀█▀ █░█ █▀▀ █▀█ █▀▄▀█ ▄▀█ █░░
░█░ █▀█ ██▄ █▀▄ █░▀░█ █▀█ █▄▄
"
sleep 1
echo ""
echo "🔥 Welcome to RC Modz Optimization Module 🔥"
sleep 1
echo ""

# Module Information
echo "📜 [ MODULE INFORMATION ]"
sleep 1
echo "⚙️ Developer: RC Modz"
echo "🛠️ Version: Stable NR"
echo "🔒 Status: No Root"
echo "🔧 Tools: Brevent"
sleep 1
echo ""

# Device Information
echo "📱 [ YOUR DEVICE INFORMATION ]"
sleep 1
echo "🔹 Brand: $(getprop ro.product.brand)"
echo "🔹 Model: $(getprop ro.product.model)"
echo "🔹 CPU: $(getprop ro.hardware)"
echo "🔹 GPU: $(getprop ro.hardware.egl)"
echo "🔹 SDK: $(getprop ro.build.version.sdk)"
sleep 1
echo ""

# Flashing Module
echo "🚀 [ FLASHING MODULE ]"
sleep 1
echo "☑ Executing Props"
sleep 1
echo "☑ Flashing Module"
sleep 1
echo "☑ Clearing Cache"
sleep 1
echo "☑ Finalizing, Please Wait..."
sleep 2
echo ""
echo "✅ MODULE FLASHED SUCCESSFULLY!"
sleep 1
echo ""
echo "🙏 Thank You for Using RC Modz Optimization Modules!"
sleep 1
echo ""
echo "🎉 All Optimizations Applied Successfully!"
sleep 1
echo "✨ Enjoy a Boosted Experience! ✨"
sleep 1
echo ""

# Thermal Configuration
echo "🌡️ [ CONFIGURING THERMAL PROPERTIES ]"
sleep 1

# Disable thermal limits for better FPS
echo "⚙️ Applying thermal properties..."
cmd thermalservice override-status 0
setprop debug.thermal.force_override true
setprop debug.thermal.engine.disable true
setprop debug.thermal.limits.disable true
setprop debug.thermal.ignore_sensor true
setprop debug.thermal_control 0
setprop debug.thermal.power_saver.disable true
setprop debug.thermal.smart_therm_control 0
setprop debug.thermal.temp_control.disable true
setprop debug.thermal.ignore_temp_check true
setprop debug.thermal.no_throttling true
setprop debug.thermal.hotplug_disable true
setprop debug.thermal.high_temp_warn 0
setprop debug.cpu.performance_boost 1
setprop debug.cpu.limit_disable true
setprop debug.power.hint.disable_thermal true
setprop debug.power.hint.disable_sustain true
setprop debug.performance.tuning 1
setprop debug.performance_mode 1
setprop debug.max_perf_enable 1
setprop debug.battery.saver.enable false
setprop debug.cpu.hotplug_disable true
setprop debug.power.perf_mode 1
setprop debug.power.saver.disable true
setprop debug.powerhal.thermal_mode_override true
setprop debug.thermal.force_override true
setprop debug.thermal.engine.disable true
setprop debug.thermal.limits.disable true
setprop debug.thermal.ignore_sensor true
setprop debug.thermal_control 0
setprop debug.thermal.power_saver.disable true
setprop debug.thermal.smart_therm_control 0
setprop debug.thermal.temp_control.disable true
setprop debug.thermal.ignore_temp_check true
setprop debug.thermal.no_throttling true
setprop debug.thermal.hotplug_disable true
setprop debug.thermal.high_temp_warn 0
setprop debug.cpu.performance_boost 1
setprop debug.cpu.limit_disable true
setprop debug.power.hint.disable_thermal true
setprop debug.power.hint.disable_sustain true
setprop debug.performance.tuning 1
setprop debug.performance_mode 1
setprop debug.max_perf_enable 1
setprop debug.battery.saver.enable false
setprop debug.cpu.hotplug_disable true
setprop debug.power.perf_mode 1
setprop debug.power.saver.disable true
setprop debug.powerhal.thermal_mode_override true
setprop debug.powerhal.perf_boost true
setprop debug.perf.force_max_power 1
setprop debug.cpu.no_limit_mode 1
setprop debug.thermal.emergency_disable true
setprop debug.thermal.bypass true
setprop debug.thermal.no_limit true
setprop debug.perf.no_limit true
setprop debug.performance.no_throttle true
setprop debug.battery.performance_mode 1
setprop debug.performance.high_performance 1
setprop debug.thermal.ignore_power_limits true
setprop debug.powerhal.performance_mode 1
setprop debug.thermal.engine.force_disable true
setprop debug.thermal.throttle_limit 100
setprop debug.thermal.temp_limit_override 100
setprop debug.thermal.perf_mode 1
setprop debug.powerhal.max_perf_mode 1
setprop debug.performance.limit_override true
setprop debug.thermal.disable_thermal_engine true
setprop debug.performance.lock_max_freq 1
setprop debug.cpu.max_boost_mode 1
setprop debug.power.force_max_performance true
setprop debug.cpu.high_performance_mode 1
setprop debug.performance.force_boost true
setprop debug.performance.maximize true
setprop debug.thermal.ignore_all_limits true
setprop debug.perf.max_power_mode 1
setprop debug.thermal.force_max_power 1
setprop debug.thermal.disable_temp_check true
setprop debug.thermal.disable_temp_protection true
setprop debug.power.enable_full_boost true
setprop debug.cpu.lock_max_frequency true
setprop debug.cpu.ignore_freq_scaling true
setprop debug.power.high_perf_mode 1
setprop debug.cpu.turbo_mode_enable true
setprop debug.performance.locked_boost true
setprop debug.performance.turbo_boost true
setprop debug.battery.disable_power_saver true
setprop debug.performance.force_turbo true
setprop debug.thermal.force_high_perf true
setprop debug.power.lock_performance true
setprop debug.performance.disable_throttling true
setprop debug.performance.unlock_max_power true
setprop debug.cpu.force_turbo_mode 1
setprop debug.thermal.ignore_temperature true
setprop debug.performance.max_boost_enabled true
setprop debug.power.ignore_limit true
setprop debug.thermal.disable_protection true
setprop debug.cpu.force_high_freq true
setprop debug.battery.force_performance_mode true
setprop debug.thermal.limit_off true
setprop debug.cpu.override_limits true
setprop debug.power.force_full_power true
setprop debug.power.enable_extreme_performance true
setprop debug.thermal.disable_all_sensors true
setprop debug.performance.unlock_extreme_mode true
setprop debug.cpu.performance_lock true
setprop debug.power.disable_limit_mode true
setprop debug.thermal.full_performance true
setprop debug.battery.boost_enabled true
setprop debug.power.force_turbo true
setprop debug.performance.extreme_boost true
setprop debug.thermal.disable_temp_control true
setprop debug.cpu.no_scaling_limit true
setprop debug.battery.force_boost_mode true
setprop debug.thermal.full_boost_enabled true
setprop debug.performance.full_turbo true
setprop debug.cpu.enable_max_boost true
setprop debug.powerhal.perf_boost true
setprop debug.perf.force_max_power 1
setprop debug.cpu.no_limit_mode 1
setprop debug.thermal.emergency_disable true
setprop debug.thermal.bypass true
setprop debug.thermal.no_limit true
setprop debug.perf.no_limit true
setprop debug.performance.no_throttle true
setprop debug.battery.performance_mode 1
setprop debug.performance.high_performance 1
setprop debug.thermal.ignore_power_limits true
setprop debug.powerhal.performance_mode 1
setprop debug.thermal.engine.force_disable true
setprop debug.thermal.throttle_limit 100
setprop debug.thermal.temp_limit_override 100
setprop debug.thermal.perf_mode 1
setprop debug.powerhal.max_perf_mode 1
setprop debug.performance.limit_override true
setprop debug.thermal.disable_thermal_engine true
setprop debug.performance.lock_max_freq 1
setprop debug.cpu.max_boost_mode 1
setprop debug.power.force_max_performance true
setprop debug.cpu.high_performance_mode 1
setprop debug.performance.force_boost true
setprop debug.performance.maximize true
setprop debug.thermal.ignore_all_limits true
setprop debug.thermal.engine.force_disable true
setprop debug.thermal.engine.ignore_limits true
setprop debug.thermal.control.disable true
setprop debug.thermal.control.ignore true
setprop debug.thermal.manager.disabled true
setprop debug.thermal.limits.off true
setprop debug.thermal.limit_bypass true
setprop debug.thermal.sensor_override true
setprop debug.thermal.temp_lock 0
setprop debug.thermal.throttle_override true
setprop debug.thermal.policy.disable true
setprop debug.thermal.suppress_temp_check true
setprop debug.thermal.max_power_mode true
setprop debug.thermal.protection_disabled true
setprop debug.thermal.force_bypass true
setprop debug.thermal.control.bypass true
setprop debug.thermal.temp_safety_margin 100
setprop debug.thermal.high_temp_protect false
setprop debug.thermal.auto_shutdown false
setprop debug.thermal.overheat_protection false
setprop debug.thermal.throttle_disable true
setprop debug.thermal.control.no_throttle true
setprop debug.thermal.full_perf true
setprop debug.thermal.throttle_mode 0
setprop debug.thermal.throttle_limit 100
setprop debug.thermal.temp_check_disable true
setprop debug.thermal.force_high_perf_mode true
setprop debug.thermal.disable_all true
setprop debug.thermal.control.off true
setprop debug.thermal.force_disable_throttle true
setprop debug.thermal.disable_protection true
setprop debug.thermal.temp_control.disable true
setprop debug.thermal.disable_temp_control true
setprop debug.thermal.no_temp_check true
setprop debug.thermal.engine.off true
setprop debug.thermal.sensor_disable true
setprop debug.thermal.control.ignore_all true
setprop debug.thermal.max_boost_enable true
setprop debug.thermal.temp_protect_off true
setprop debug.thermal.override_temp_limit true
setprop debug.thermal.full_boost_mode true
setprop debug.thermal.throttle_control.disable true
setprop debug.thermal.ignore_temp_limits true
setprop debug.thermal.force_max_mode true
setprop debug.thermal.disable_temp_sensor true
setprop debug.thermal.force_max_freq true
setprop debug.thermal.disable_all_throttles true
setprop debug.thermal.force_extreme_boost true
setprop debug.thermal.ignore_thermal_policies true
setprop debug.thermal.extreme_boost_enabled true
setprop debug.thermal.sensor_bypass true
setprop debug.thermal.disable_auto_throttle true
setprop debug.thermal.force_full_throttle true
setprop debug.thermal.high_perf_lock true
setprop debug.thermal.temp_limit_off true
setprop debug.thermal.disable_thermal_policy true
setprop debug.thermal.bypass_all_limits true
setprop debug.thermal.disable_sensors true
setprop debug.thermal.no_thermal_throttle true
setprop debug.thermal.full_power_mode true
setprop debug.thermal.temp_limit_override 100
setprop debug.thermal.force_max_performance true
setprop debug.thermal.disable_dynamic_throttle true
setprop debug.thermal.temp_ignore true
setprop debug.thermal.bypass_temp_check true
setprop debug.thermal.no_limit_mode true
setprop debug.thermal.force_ignore_temp true
setprop debug.thermal.temp_control_off true
setprop debug.thermal.force_unlock_limits true
setprop debug.thermal.disable_hotplug true
setprop debug.thermal.disable_temp_warnings true
setprop debug.thermal.force_temp_ignore true
setprop debug.thermal.force_no_throttle true
setprop debug.thermal.control.max_boost true
setprop debug.thermal.full_throttle_enable true
setprop debug.thermal.force_disable_protection true
setprop debug.thermal.sensor_ignore true
setprop debug.thermal.no_overheat_protection true
setprop debug.thermal.ignore_temp_warnings true
setprop debug.thermal.full_unlock_mode true
setprop debug.thermal.force_no_temp_check true
setprop debug.thermal.force_disable_limits true
setprop debug.thermal.no_throttle_mode true
setprop debug.thermal.engine.max_boost true
setprop debug.thermal.disable_temp_protection true
setprop debug.thermal.control.disable_all true
setprop debug.thermal.force_disable_all true
setprop debug.thermal.engine.bypass_mode true
setprop debug.thermal.force_max_lock true
setprop debug.thermal.full_boost_enable true
setprop debug.thermal.control.force_disable true
setprop debug.thermal.no_temp_limits true
setprop debug.thermal.force_extreme_mode true
setprop debug.thermal.ignore_all_sensors true
setprop debug.thermal.engine.status stopped
setprop debug.thermal.control.status stopped
setprop debug.thermal.manager.state stopped
setprop debug.thermal.policy.status stopped
setprop debug.thermal.limits.state stopped
setprop debug.thermal.sensor.monitor stopped
setprop debug.thermal.temp_monitor.status stopped
setprop debug.thermal.throttle.state stopped
setprop debug.thermal.control.lock stopped
setprop debug.thermal.protection.status stopped
setprop debug.thermal.temp_lock.state stopped
setprop debug.thermal.engine.operation stopped
setprop debug.thermal.temp_control.status stopped
setprop debug.thermal.sensors.state stopped
setprop debug.thermal.monitor.status stopped
setprop debug.thermal.safety_check.status stopped
setprop debug.thermal.sensor.status stopped
setprop debug.thermal.temp_protection.state stopped
setprop debug.thermal.throttle_control.status stopped
setprop debug.thermal.protection.mode stopped
setprop debug.thermal.temp_sensor.state stopped
setprop debug.thermal.high_temp_protect.status stopped
setprop debug.thermal.auto_shutdown.state stopped
setprop debug.thermal.control_mode.status stopped
setprop debug.thermal.temp_safety.status stopped
setprop debug.thermal.overheat_protection.status stopped
setprop debug.thermal.engine_monitor.state stopped
setprop debug.thermal.temp_monitor.state stopped
setprop debug.thermal.throttle_policy.status stopped
setprop debug.thermal.limits_monitor.state stopped
setprop debug.thermal.temp_safety_lock stopped
setprop debug.thermal.force_stop.status stopped
setprop debug.thermal.limits_control.state stopped
setprop debug.thermal.throttle_override.state stopped
setprop debug.thermal.protection_lock.status stopped
setprop debug.thermal.force_protection.state stopped
setprop debug.thermal.throttle_engine.status stopped
setprop debug.thermal.limits_lock.state stopped
setprop debug.thermal.temp_control.lock stopped
setprop debug.thermal.throttle_safety.status stopped
setprop debug.thermal.sensors_monitor.status stopped
setprop debug.thermal.high_temp_lock.state stopped
setprop debug.thermal.overheat_control.status stopped
setprop debug.thermal.auto_throttle.state stopped
setprop debug.thermal.high_temp_monitor.status stopped
setprop debug.thermal.temp_protection.lock stopped
setprop debug.thermal.temp_control.override stopped
setprop debug.thermal.force_throttle.status stopped
setprop debug.thermal.overheat_monitor.state stopped
setprop debug.thermal.protection_monitor.status stopped
setprop debug.thermal.temp_control_mode stopped
setprop debug.thermal.throttle_monitor.status stopped
setprop debug.thermal.force_shutdown.state stopped
setprop debug.thermal.temp_control_monitor stopped
setprop debug.thermal.temp_safety_check stopped
setprop debug.thermal.force_lock.status stopped
setprop debug.thermal.throttle_lock.state stopped
setprop debug.thermal.temp_protection_monitor stopped
setprop debug.thermal.limits_monitor.status stopped
setprop debug.thermal.sensors_control.state stopped
setprop debug.thermal.high_temp_status stopped
setprop debug.thermal.control_engine.state stopped
setprop debug.thermal.force_override.status stopped
setprop debug.thermal.engine_lock.state stopped
setprop debug.thermal.temp_check.status stopped
setprop debug.thermal.force_throttle_monitor stopped
setprop debug.thermal.temp_monitor_control stopped
setprop debug.thermal.force_monitor.state stopped
setprop debug.thermal.sensor_override.status stopped
setprop debug.thermal.throttle_check.state stopped
setprop debug.thermal.engine_protection.status stopped
setprop debug.thermal.temp_protection_check stopped
setprop debug.thermal.temp_lock_monitor stopped
setprop debug.thermal.protection_engine.state stopped
setprop debug.thermal.sensors_check.status stopped
setprop debug.thermal.limits_check.state stopped
setprop debug.thermal.force_safety.status stopped
setprop debug.thermal.temp_monitor_lock stopped
setprop debug.thermal.force_control.state stopped
setprop debug.thermal.safety_monitor.status stopped
setprop debug.thermal.high_temp_control stopped
setprop debug.thermal.auto_throttle_monitor stopped
setprop debug.thermal.temp_sensor_check stopped
setprop debug.thermal.throttle_control_lock stopped
setprop debug.thermal.force_temp_lock stopped
setprop debug.thermal.protection_check.state stopped
setprop debug.thermal.temp_control_engine stopped
setprop debug.thermal.limits_monitor_lock stopped
setprop debug.thermal.temp_override.state stopped
setprop debug.thermal.temp_lock_control stopped
setprop debug.thermal.throttle_override_monitor stopped
setprop debug.thermal.force_protection_monitor stopped
setprop debug.thermal.temp_protection_override stopped
setprop debug.thermal.high_temp_override stopped
setprop debug.thermal.force_locks.state stopped
setprop debug.init.svc.android.thermal-hal stopped
setprop debug.init.svc.thermal stopped
setprop debug.init.svc.mi-thermald stopped
setprop debug.init.svc.mi_thermald stopped
setprop debug.init.svc.thermal-hal stopped
setprop debug.init.svc.thermal-engine stopped
setprop debug.init.svc.thermalservice stopped
setprop debug.init.svc.thermal-manager stopped
setprop debug.init.svc.thermal_manager stopped
setprop debug.init.svc.thermal-managers stopped
setprop debug.init.svc.thermalloadalgod stopped
setprop debug.init.svc.vendor-thermal-hal-1-0 stopped
setprop debug.init.svc.thermal_mnt_hal_service stopped
setprop debug.debuggable 1
setprop debug.init.svc.thermal stopped
setprop debug.init.svc.thermal_manager stopped
setprop debug.init.svc.thermald stopped
setprop debug.init.svc.thermalloadalgod stopped
setprop debug.svc.thermal stopped
setprop debug.svc.thermal_manager stopped
setprop debug.svc.thermald stopped
setprop debug.svc.thermalloadalgod stopped
setprop debug.sys.shutdown_state 6
setprop debug.thermal.engine.disable true
setprop debug.thermal.config.override 1
setprop debug.thermal.force_override 1
setprop debug.thermal.tuning 0
setprop debug.thermal.performance_mode 1
setprop debug.thermal.max_temp 100
setprop debug.thermal.monitoring 0
setprop debug.thermal.throttling 0
setprop debug.thermal.policy_override high_performance
setprop debug.thermal.enable_failsafe 0
setprop debug.cpu.thermal_policy 0
setprop debug.cpu.thermal_throttle_disable true
setprop debug.cpu.temperature_limit 100
setprop debug.cpu.cooling_offload 0
setprop debug.gpu.thermal_throttling 0
setprop debug.gpu.max_temp 100
setprop debug.gpu.temp_limit 100
setprop debug.power.thermal_protection 0
setprop debug.power.cooling_disable 1
setprop debug.power.failsafe_disable true
setprop debug.vulkan.thermal_throttling false
setprop debug.performance.thermal_override 1
setprop debug.performance.throttle_disable true
setprop debug.performance.temp_limit 100
setprop debug.android.thermal_control 0
setprop debug.android.max_temp 100
setprop debug.sys.thermal_protection 0
setprop debug.sys.thermal_limit_disable true
setprop debug.sys.temp_monitoring 0
setprop debug.thermal.engine.performance 1
setprop debug.thermal.engine.high_limit 110
setprop debug.thermal.engine.cooling_mode 0
setprop debug.thermal.engine.temp_override true
setprop debug.thermal.config.max_temperature 110
setprop debug.performance.cpu.temp_control 0
setprop debug.performance.gpu.temp_control 0
setprop debug.performance.temp_protection 0
setprop debug.system.temp_override 1
setprop debug.system.cooling_mode 0
setprop debug.system.max_temp 120
setprop debug.cpu.thermal_ignore true
setprop debug.gpu.thermal_ignore true
setprop debug.battery.temp_control 0
setprop debug.battery.temp_protection 0
setprop debug.battery.max_temp 100
setprop debug.thermal.config.temp_ignore true
setprop debug.thermal.high_limit 120
setprop debug.thermal.temp_ignore 1
setprop debug.thermal.max_threshold 130
setprop debug.thermal.ignore_temp true
setprop debug.thermal.high_performance 1
setprop debug.thermal.temp_monitor 0
cmd device_config put thermal_service enable_temperature_check false
cmd device_config put thermal_service disable_thermal_throttling true
cmd device_config put thermal_service max_temperature_limit 100
cmd device_config put thermal_service thermal_override_mode high_performance
cmd device_config put thermal_service performance_throttle_disable true
cmd device_config put thermal_service temp_monitoring_off true
cmd device_config put thermal_service failsafe_protection_disable true
cmd device_config put thermal_service temp_protection_off true
cmd device_config put thermal_service max_temp_threshold 110
cmd device_config put thermal_service cooling_policy_override none
cmd device_config put thermal_service temp_limit_disable true
cmd device_config put thermal_service temp_check_interval 0
cmd device_config put thermal_service high_temp_limit 120
cmd device_config put thermal_service disable_temp_protection true
cmd device_config put thermal_service ignore_temperature_limits true
cmd device_config put thermal_service max_cpu_temp 100
cmd device_config put thermal_service max_gpu_temp 100
cmd device_config put thermal_service thermal_protection_disabled true
cmd device_config put thermal_service high_performance_mode_enabled true
cmd device_config put thermal_service disable_temp_check true
cmd device_config put thermal_service temp_threshold_override 110
cmd device_config put thermal_service max_battery_temp 100
cmd device_config put thermal_service disable_failsafe true
cmd device_config put thermal_service performance_mode_enabled true
cmd device_config put thermal_service disable_throttle_protection true
cmd device_config put thermal_service temp_override_enabled true
cmd device_config put thermal_service disable_cooling_mode true
cmd device_config put thermal_service ignore_temp_warnings true
cmd device_config put thermal_service max_temp_allowed 120
cmd device_config put thermal_service disable_temp_monitoring true
cmd device_config put thermal_service temp_policy_override aggressive
cmd device_config put thermal_service disable_temp_checking true
cmd device_config put thermal_service temp_ignore_limits true
cmd device_config put thermal_service disable_thermal_management true
cmd device_config put thermal_service enable_high_temp_threshold 130
cmd device_config put thermal_service disable_all_temp_limits true
cmd device_config put thermal_service high_temp_override_enabled true
cmd device_config put thermal_service aggressive_temp_ignore true
cmd device_config put thermal_service disable_thermal_temp_control true
cmd device_config put thermal_service ignore_all_temp_limits true
cmd device_config put thermal_service performance_mode_override high
cmd device_config put thermal_service disable_throttle_all true
cmd device_config put thermal_service max_allowed_temperature 130
cmd device_config put hardware_properties_manager battery_shutdown_temperatures 250.0
cmd device_config put hardware_properties_manager battery_throttling_temperatures 250.0
cmd device_config put hardware_properties_manager cpu_shutdown_temperatures 250.0
cmd device_config put hardware_properties_manager cpu_throttling_temperatures 250.0
cmd device_config put hardware_properties_manager gpu_shutdown_temperatures 250.0
cmd device_config put hardware_properties_manager gpu_throttling_temperatures 250.0
cmd device_config put thermal_manager thermal_control_enabled false
cmd device_config put thermal_manager thermal_throttling_enabled false
cmd device_config put thermal_manager cpu_throttle_disabled true
cmd device_config put thermal_manager gpu_throttle_disabled true
cmd device_config put thermal_manager temp_protection_enabled false
cmd device_config put power_manager ignore_temperature_limits true
cmd device_config put power_manager disable_thermal_shutdown true
cmd device_config put performance_manager max_performance_mode true
cmd device_config put power_manager thermal_limiter_enabled false
cmd device_config put battery_manager disable_overheat_protection true
cmd device_config put thermal_sensors sensor_monitor_disabled true
cmd device_config put thermal_sensors ignore_high_temp_check true
cmd device_config put device_performance force_high_performance_mode true
cmd device_config put cpu_manager temp_throttle_disabled true
cmd device_config put gpu_manager temp_throttle_disabled true
cmd device_config put device_config_overrides disable_temp_throttle true
cmd device_config put device_control temp_monitor_override true
cmd device_config put system_control ignore_thermal_policy true
cmd device_config put performance_tuner bypass_thermal_limits true
cmd device_config put cooling_manager disable_auto_cooling true
device_config put power boost_performance true
device_config put power thermal_mode_override false
device_config put power disable_thermal_throttling true
device_config put power performance_mode 1
device_config put performance max_thermal_limit_override true
device_config put thermal_config disable_thermal_engine true
device_config put power force_high_performance true
device_config put power ignore_thermal_sensors true
device_config put cpu_config hotplug_disabled true
device_config put cpu_config disable_throttle true
device_config put powerhal thermal_control_disabled true
device_config put powerhal boost_mode 1
device_config put battery_config disable_saver_mode true
device_config put power enable_max_power_mode true
device_config put power disable_power_saver true
device_config put thermal_control ignore_sensor_data true
device_config put power force_max_performance true
device_config put performance boost_mode_enabled true
device_config put thermal_config emergency_disable true
device_config put cpu_config max_frequency_override true
device_config put cpu_config disable_dynamic_scaling true
device_config put power enable_extreme_mode true
device_config put power enable_boost_performance true
device_config put performance disable_temp_control true
device_config put cpu_config no_limit_mode_enabled true
device_config put power ignore_temp_warnings true
device_config put power force_no_throttling true
device_config put power enable_thermal_bypass true
device_config put thermal_config disable_temp_limits true
device_config put cpu_config lock_max_frequency true
device_config put power enable_full_boost true
device_config put thermal_config override_temp_limit true
device_config put battery_config high_performance_mode true
device_config put powerhal enable_max_performance true
device_config put performance ignore_all_thermal_limits true
device_config put thermal_sensor ignore_all_readings true
device_config put cpu_config disable_hotplug true
device_config put power force_max_cpu_boost true
device_config put powerhal enable_extreme_boost true
device_config put power thermal_management_disabled true
device_config put performance enable_turbo_mode true
device_config put thermal_config temp_control_disabled true
device_config put power force_high_perf_mode true
device_config put cpu_config disable_core_throttling true
device_config put power max_boost_enabled true
device_config put thermal_control disable_temp_check true
device_config put performance enable_full_power true
device_config put cpu_config disable_scaling_limits true
device_config put battery_config enable_boost_mode true
device_config put power enable_unlimited_performance true
device_config put power boost_performance true
device_config put power thermal_mode_override false
device_config put power disable_thermal_throttling true
device_config put power performance_mode 1
device_config put performance max_thermal_limit_override true
device_config put thermal_config disable_thermal_engine true
device_config put power force_high_performance true
device_config put power ignore_thermal_sensors true
device_config put cpu_config hotplug_disabled true
device_config put cpu_config disable_throttle true
device_config put powerhal thermal_control_disabled true
device_config put powerhal boost_mode 1
device_config put battery_config disable_saver_mode true
device_config put power enable_max_power_mode true
device_config put power disable_power_saver true
device_config put thermal_control ignore_sensor_data true
device_config put power force_max_performance true
device_config put performance boost_mode_enabled true
device_config put thermal_config emergency_disable true
device_config put cpu_config max_frequency_override true
device_config put cpu_config disable_dynamic_scaling true
device_config put power enable_extreme_mode true
device_config put power enable_boost_performance true
device_config put performance disable_temp_control true
device_config put cpu_config no_limit_mode_enabled true
device_config put power ignore_temp_warnings true
device_config put power force_no_throttling true
device_config put power enable_thermal_bypass true
device_config put thermal_config disable_temp_limits true
device_config put cpu_config lock_max_frequency true
device_config put power enable_full_boost true
device_config put thermal_config override_temp_limit true
device_config put battery_config high_performance_mode true
device_config put powerhal enable_max_performance true
device_config put performance ignore_all_thermal_limits true
device_config put thermal_sensor ignore_all_readings true
device_config put cpu_config disable_hotplug true
device_config put power force_max_cpu_boost true
device_config put powerhal enable_extreme_boost true
device_config put power thermal_management_disabled true
device_config put performance enable_turbo_mode true
device_config put thermal_config temp_control_disabled true
device_config put power force_high_perf_mode true
device_config put cpu_config disable_core_throttling true
device_config put power max_boost_enabled true
device_config put thermal_control disable_temp_check true
device_config put performance enable_full_power true
device_config put cpu_config disable_scaling_limits true
device_config put battery_config enable_boost_mode true
device_config put power enable_unlimited_performance true
device_config put cpu_config force_max_freq true
device_config put power extreme_performance_enabled true
device_config put powerhal max_performance_mode true
device_config put thermal_config no_throttle_mode true
device_config put cpu_config force_no_scaling true
device_config put power enable_high_performance true
device_config put power enable_turbo_boost true
device_config put cpu_config override_temp_limits true
device_config put power force_performance_mode true
device_config put thermal_config disable_thermal_protection true
device_config put power enable_full_throttle true
device_config put power disable_all_limits true
device_config put cpu_config full_boost_enabled true
device_config put power extreme_boost_enabled true
device_config put thermal_config force_max_power_mode true
device_config put power unlock_extreme_performance true
device_config put cpu_config disable_thermal_limits true
device_config put power enable_boost_mode true
device_config put thermal_control disable_limit_checks true
device_config put performance lock_max_boost true
device_config put cpu_config force_high_frequency true
device_config put battery_config unlock_performance_mode true
device_config put power force_extreme_performance true
device_config put power enable_no_throttling true
device_config put thermal_control unlock_temp_limits true
device_config put cpu_config disable_freq_scaling true
device_config put power extreme_mode_enabled true
device_config put performance unlock_max_power true
device_config put power force_turbo_mode true
device_config put cpu_config disable_all_throttles true
settings put system thermal_limit_refresh_rate 120
settings put global thermal_engine_enabled 0
settings put system thermal_limiter_enabled 0
settings put secure high_temp_warning_enabled 0
settings put global cpu_throttle_mode 0
settings put system thermal_management_policy 0
settings put secure thermal_protection_enabled 0
settings put global disable_temp_throttling 1
settings put system ignore_thermal_policy 1
settings put secure temp_monitor_disabled 1
settings put global throttle_limit_override 100
settings put system disable_auto_shutdown 1
settings put secure overheat_protection_enabled 0
settings put global temp_control_override 1
settings put system thermal_sensor_check 0
settings put secure force_max_performance 1
settings put global cpu_performance_mode 1
settings put system thermal_throttle_disable 1
settings put secure temp_safety_margin 100
settings put global bypass_thermal_limits 1
settings put system full_throttle_enabled 1
sleep 1
echo ""
echo "✅ Thermal properties applied successfully!"
sleep 1
echo ""
echo "✨ Thermal limits disabled! Enjoy enhanced performance and FPS! ✨"
sleep 1