#!/bin/bash

# Welcome Banner
sleep 1
echo ""
echo "
█▀▄ █ █▀ ▄▀█ █▄▄ █░░ █▀▀
█▄▀ █ ▄█ █▀█ █▄█ █▄▄ ██▄

▀█▀ █░█ █▀▀ █▀█ █▀▄▀█ ▄▀█ █░░
░█░ █▀█ ██▄ █▀▄ █░▀░█ █▀█ █▄▄
"
sleep 1
echo ""
echo "🔥 Welcome to RC Modz Module Uninstaller 🔥"
sleep 1
echo ""

# Module Information
echo "📜 [ MODULE INFORMATION ]"
sleep 1
echo "⚙️ Developer: RC Modz"
sleep 1
echo "🛠️ Module: Uninstallation"
sleep 1
echo "🔒 Status: No Root"
sleep 1
echo ""

# Uninstallation Process
echo "🗑️ [ UNINSTALLATION IN PROGRESS... ]"
sleep 2
sleep 1
echo ""
echo "✅ Uninstallation Complete!"
sleep 1
echo "🙏 Thank You for Using RC Modz Modules!"
sleep 1
echo "✨ Have a Great Day! ✨"
echo ""

cmd thermalservice override-status 1
setprop debug.thermal.force_override false
setprop debug.thermal.engine.disable false
setprop debug.thermal.limits.disable false
setprop debug.thermal.ignore_sensor false
setprop debug.thermal_control 1
setprop debug.thermal.power_saver.disable false
setprop debug.thermal.smart_therm_control 1
setprop debug.thermal.temp_control.disable false
setprop debug.thermal.ignore_temp_check false
setprop debug.thermal.no_throttling false
setprop debug.thermal.hotplug_disable false
setprop debug.thermal.high_temp_warn 1
setprop debug.cpu.performance_boost 0
setprop debug.cpu.limit_disable false
setprop debug.power.hint.disable_thermal false
setprop debug.power.hint.disable_sustain false
setprop debug.performance.tuning 0
setprop debug.performance_mode 0
setprop debug.max_perf_enable 0
setprop debug.battery.saver.enable true
setprop debug.cpu.hotplug_disable false
setprop debug.power.perf_mode 0
setprop debug.power.saver.disable false
setprop debug.powerhal.thermal_mode_override false
setprop debug.thermal.force_override false
setprop debug.thermal.engine.disable false
setprop debug.thermal.limits.disable false
setprop debug.thermal.ignore_sensor false
setprop debug.thermal_control 1
setprop debug.thermal.power_saver.disable false
setprop debug.thermal.smart_therm_control 1
setprop debug.thermal.temp_control.disable false
setprop debug.thermal.ignore_temp_check false
setprop debug.thermal.no_throttling false
setprop debug.thermal.hotplug_disable false
setprop debug.thermal.high_temp_warn 1
setprop debug.cpu.performance_boost 0
setprop debug.cpu.limit_disable false
setprop debug.power.hint.disable_thermal false
setprop debug.power.hint.disable_sustain false
setprop debug.performance.tuning 0
setprop debug.performance_mode 0
setprop debug.max_perf_enable 0
setprop debug.battery.saver.enable true
setprop debug.cpu.hotplug_disable false
setprop debug.power.perf_mode 0
setprop debug.power.saver.disable false
setprop debug.powerhal.thermal_mode_override false
setprop debug.powerhal.perf_boost false
setprop debug.perf.force_max_power 0
setprop debug.cpu.no_limit_mode 0
setprop debug.thermal.emergency_disable false
setprop debug.thermal.bypass false
setprop debug.thermal.no_limit false
setprop debug.perf.no_limit false
setprop debug.performance.no_throttle false
setprop debug.battery.performance_mode 0
setprop debug.performance.high_performance 0
setprop debug.thermal.ignore_power_limits false
setprop debug.powerhal.performance_mode 0
setprop debug.thermal.engine.force_disable false
setprop debug.thermal.throttle_limit 0
setprop debug.thermal.temp_limit_override 0
setprop debug.thermal.perf_mode 0
setprop debug.powerhal.max_perf_mode 0
setprop debug.performance.limit_override false
setprop debug.thermal.disable_thermal_engine false
setprop debug.performance.lock_max_freq 0
setprop debug.cpu.max_boost_mode 0
setprop debug.power.force_max_performance false
setprop debug.cpu.high_performance_mode 0
setprop debug.performance.force_boost false
setprop debug.performance.maximize false
setprop debug.thermal.ignore_all_limits false
setprop debug.perf.max_power_mode 0
setprop debug.thermal.force_max_power 0
setprop debug.thermal.disable_temp_check false
setprop debug.thermal.disable_temp_protection false
setprop debug.power.enable_full_boost false
setprop debug.cpu.lock_max_frequency false
setprop debug.cpu.ignore_freq_scaling false
setprop debug.power.high_perf_mode 0
setprop debug.cpu.turbo_mode_enable false
setprop debug.performance.locked_boost false
setprop debug.performance.turbo_boost false
setprop debug.battery.disable_power_saver false
setprop debug.performance.force_turbo false
setprop debug.thermal.force_high_perf false
setprop debug.power.lock_performance false
setprop debug.performance.disable_throttling false
setprop debug.performance.unlock_max_power false
setprop debug.cpu.force_turbo_mode 0
setprop debug.thermal.ignore_temperature false
setprop debug.performance.max_boost_enabled false
setprop debug.power.ignore_limit false
setprop debug.thermal.disable_protection false
setprop debug.cpu.force_high_freq false
setprop debug.battery.force_performance_mode false
setprop debug.thermal.limit_off false
setprop debug.cpu.override_limits false
setprop debug.power.force_full_power false
setprop debug.power.enable_extreme_performance false
setprop debug.thermal.disable_all_sensors false
setprop debug.performance.unlock_extreme_mode false
setprop debug.cpu.performance_lock false
setprop debug.power.disable_limit_mode false
setprop debug.thermal.full_performance false
setprop debug.battery.boost_enabled false
setprop debug.power.force_turbo false
setprop debug.performance.extreme_boost false
setprop debug.thermal.disable_temp_control false
setprop debug.cpu.no_scaling_limit false
setprop debug.battery.force_boost_mode false
setprop debug.thermal.full_boost_enabled false
setprop debug.performance.full_turbo false
setprop debug.cpu.enable_max_boost false
setprop debug.powerhal.perf_boost false
setprop debug.perf.force_max_power 0
setprop debug.cpu.no_limit_mode 0
setprop debug.thermal.emergency_disable false
setprop debug.thermal.bypass false
setprop debug.thermal.no_limit false
setprop debug.perf.no_limit false
setprop debug.performance.no_throttle false
setprop debug.battery.performance_mode 0
setprop debug.performance.high_performance 0
setprop debug.thermal.ignore_power_limits false
setprop debug.powerhal.performance_mode 0
setprop debug.thermal.engine.force_disable false
setprop debug.thermal.throttle_limit 0
setprop debug.thermal.temp_limit_override 0
setprop debug.thermal.perf_mode 0
setprop debug.powerhal.max_perf_mode 0
setprop debug.performance.limit_override false
setprop debug.thermal.disable_thermal_engine false
setprop debug.performance.lock_max_freq 0
setprop debug.cpu.max_boost_mode 0
setprop debug.power.force_max_performance false
setprop debug.cpu.high_performance_mode 0
setprop debug.performance.force_boost false
setprop debug.performance.maximize false
setprop debug.thermal.ignore_all_limits false
setprop debug.thermal.engine.force_disable false
setprop debug.thermal.engine.ignore_limits false
setprop debug.thermal.control.disable false
setprop debug.thermal.control.ignore false
setprop debug.thermal.manager.disabled false
setprop debug.thermal.limits.off false
setprop debug.thermal.limit_bypass false
setprop debug.thermal.sensor_override false
setprop debug.thermal.temp_lock 1
setprop debug.thermal.throttle_override false
setprop debug.thermal.policy.disable false
setprop debug.thermal.suppress_temp_check false
setprop debug.thermal.max_power_mode false
setprop debug.thermal.protection_disabled false
setprop debug.thermal.force_bypass false
setprop debug.thermal.control.bypass false
setprop debug.thermal.temp_safety_margin 0
setprop debug.thermal.high_temp_protect true
setprop debug.thermal.auto_shutdown true
setprop debug.thermal.overheat_protection true
setprop debug.thermal.throttle_disable false
setprop debug.thermal.control.no_throttle false
setprop debug.thermal.full_perf false
setprop debug.thermal.throttle_mode 1
setprop debug.thermal.throttle_limit 0
setprop debug.thermal.temp_check_disable false
setprop debug.thermal.force_high_perf_mode false
setprop debug.thermal.disable_all false
setprop debug.thermal.control.off false
setprop debug.thermal.force_disable_throttle false
setprop debug.thermal.disable_protection false
setprop debug.thermal.temp_control.disable false
setprop debug.thermal.disable_temp_control false
setprop debug.thermal.no_temp_check false
setprop debug.thermal.engine.off false
setprop debug.thermal.sensor_disable false
setprop debug.thermal.control.ignore_all false
setprop debug.thermal.max_boost_enable false
setprop debug.thermal.temp_protect_off false
setprop debug.thermal.override_temp_limit false
setprop debug.thermal.full_boost_mode false
setprop debug.thermal.throttle_control.disable false
setprop debug.thermal.ignore_temp_limits false
setprop debug.thermal.force_max_mode false
setprop debug.thermal.disable_temp_sensor false
setprop debug.thermal.force_max_freq false
setprop debug.thermal.disable_all_throttles false
setprop debug.thermal.force_extreme_boost false
setprop debug.thermal.ignore_thermal_policies false
setprop debug.thermal.extreme_boost_enabled false
setprop debug.thermal.sensor_bypass false
setprop debug.thermal.disable_auto_throttle false
setprop debug.thermal.force_full_throttle false
setprop debug.thermal.high_perf_lock false
setprop debug.thermal.temp_limit_off false
setprop debug.thermal.disable_thermal_policy false
setprop debug.thermal.bypass_all_limits false
setprop debug.thermal.disable_sensors false
setprop debug.thermal.no_thermal_throttle false
setprop debug.thermal.full_power_mode false
setprop debug.thermal.disable_temp_limit false
setprop debug.thermal.limit_disabled false
setprop debug.thermal.performance_disabled false
setprop debug.thermal.no_limit_enabled false