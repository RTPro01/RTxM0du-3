setprop debug.performance.tuning 0
setprop debug.composition.type null
setprop debug.gr.numframebuffers 2
setprop debug.hwui.target_cpu_time_percent 50
setprop debug.hwui.level 1
setprop debug.hwui.show_layers_updates true
setprop debug.hwui.overdraw true
setprop debug.hwui.profile false
setprop debug.hwui.show_dirty_regions true
setprop debug.hwui.skip_empty_damage false
setprop debug.hwui.filter_test_overhead true
setprop debug.hwui.use_gpu_pixel_buffers false
setprop debug.hwui.renderer default
setprop debug.hwui.capture_skp_enabled false
setprop debug.hwui.trace_gpu_resources false
setprop debug.hwui.skia_tracing_enabled false
setprop debug.hwui.skia_use_perfetto_track_events false
setprop renderthread.skia.reduceopstasksplitting false
setprop debug.hwui.webview_overlays_enabled true
setprop debug.hwui.drawing_enabled true
setprop debug.hwui.use_hint_manager false
setprop debug.hwui.app_memory_policy balanced
setprop debug.hwui.8bit_hdr_headroom 2
setprop debug.hwui.initialize_gl_always false
setprop debug.hwui.skip_eglmanager_telemetry false
setprop debug.hwui.early_preload_gl_context false
setprop debug.hwui.use_buffer_age false
setprop debug.hwui.use_partial_updates false
setprop debug.hwui.disable_vsync false
setprop debug.hwui.force_draw_frame false
setprop debug.hwui.enable_partial_updates false
setprop debug.hwui.override_render_pipeline null
setprop debug.hwui.override_gpu_tracking false
setprop debug.renderengine.backend default
setprop debug.renderengine.graphite_preview_optin false
setprop debug.renderengine.capture_skia_ms 0
setprop debug.renderengine.capture_filename ""
setprop debug.renderengine.blur_algorithm default
setprop debug.renderengine.skia_atrace_enabled false
setprop debug.sf.set_idle_timer_ms 5000
setprop debug.sf.set_idle_timer_ms_0 5000
setprop debug.sf.support_kernel_idle_timer_0 false
setprop debug.sf.enable_layer_caching true
setprop debug.sf.disable_client_composition_cache false
setprop debug.sf.predict_hwc_composition_strategy 0
setprop debug.sf.treat_170m_as_sRGB 0
setprop debug.sf.dim_in_gamma_in_enhanced_screenshots 1
setprop debug.sf.ignore_hwc_physical_display_orientation false
setprop debug.sf.enable_gl_backpressure 1
setprop debug.sf.use_frame_rate_priority 0
setprop debug.sf.luma_sampling 0
setprop debug.sf.treble_testing_override false
setprop debug.sf.auto_latch_unsignaled false
setprop debug.sf.hwc_service_name default
setprop debug.sf.enable_hwc_vds 1
setprop debug.sf.latch_unsignaled 0
setprop debug.sf.hw 0
setprop debug.egl.hw 0
setprop debug.egl.buffercount 1
setprop debug.gralloc.map_fb_memory 1
setprop debug.gralloc.gfx_ubwc_disable 1
setprop debug.gralloc.enable_fb_ubwc 0
setprop debug.graphics.game_default_frame_rate.disabled false
setprop debug.graphics.hint_session_cts_api_override 0
setprop debug.hwc.use_rate_limiter true
setprop debug.hwc.bq_count 0
setprop debug.hwc.compose_level 0
setprop debug.hwc.nodirtyregion 0
setprop debug.hwc.dynThreshold 1.0
setprop debug.perf_event_max_sample_rate 1000
setprop debug.perf_cpu_time_max_percent 100
setprop debug.perf_event_mlock_kb 0
setprop debug.sf.frame_rate_multiple_threshold 1
setprop debug.sf.stable_edid_ids 1
setprop debug.sf.multithreaded_present 0
setprop debug.egl.force_msaa true
setprop debug.egl.swapbehavior 1
setprop debug.gl.disable_batching 1
setprop debug.gl.profiler 0
setprop debug.gl.buffer_age 0
setprop debug.sf.vsync_reactor_ignore_present_fences false
setprop debug.sf.late_sf_use_app_refresh 1
setprop debug.sf.useSmart90ForVideo 1
setprop debug.qc.hardware false
setprop debug.qctwa.statusbar 0
setprop debug.qctwa.preservebuf 0
setprop debug.sf.showupdates 1
setprop debug.sf.showcpu 1
setprop debug.sf.showbackground 1
setprop debug.sf.showfps 1
setprop debug.refresh_rate.min_fps 0
setprop debug.refresh_rate.max_fps 0
setprop debug.refresh_rate.peak_fps 0
setprop debug.sf.high_fps_late_app_phase_offset_ns 0
setprop debug.sf.high_fps_late_sf_phase_offset_ns 0
setprop debug.sf.high_fps_early_phase_offset_ns 0
setprop debug.sf.high_fps_early_gl_phase_offset_ns 0
setprop debug.sf.high_fps_early_app_phase_offset_ns 0
setprop debug.sf.early_gl_app_phase_offset_ns 0
setprop debug.sf.early_phase_offset_ns 0
setprop debug.sf.early_gl_phase_offset_ns 0
setprop debug.sf.early_app_phase_offset_ns 0
setprop debug.sf.late.app.duration 0
setprop debug.sf.early.sf.duration 0
setprop debug.sf.early.app.duration 0
setprop debug.sf.earlyGl.sf.duration 0
setprop debug.sf.earlyGl.app.duration 0
setprop debug.sf.hwc.min.duration 0
setprop debug.gpu.fake_gpu_vendor ""
setprop debug.gpu.fake_gpu_renderer ""
setprop debug.touch_sensitivity_mode 0
settings put system db_screen_rate 0
settings put system perf_proc_threshold 50
settings put system perf_proc_power 50
settings put system perf_shielder_Proc 1
settings put system POWER_PERFORMANCE_MODE_OPEN 0
settings put system multicore_packet_scheduler 0
settings put system high_performance_mode_on 0
settings put system sem_performance_mode 0
settings put system speed_mode 0
settings put secure high_priority 0
settings put secure speed_mode_enable 0
settings put global sem_enchanced_cpu_responsiveness 0
settings put global cached_apps_freezer disabled
settings put global restricted_device_performance 1,1
settings put global adaptive_battery_management_enabled 1
settings put global game_auto_temperature_control 1
settings put system perf_shielder_SF 1
settings put system perf_shielder_RTMODE 0
settings put system perf_shielder_GESTURE 1
settings put system perf_shielder_smartpower 1
settings put system screen_game_mode 0
settings put secure gb_boosting 0
settings put system POWER_SAVE_MODE_OPEN 1
settings put global automatic_power_save_mode 1
settings put global low_power 1
settings put system framepredict_enable 0
settings put system is_smart_fps 1
settings put system screen_optimize_mode 0
settings put system fstb_target_fps_margin_high_fps 0
settings put system fstb_target_fps_margin_low_fps 0
settings put system gcc_fps_margin 0
settings put secure support_highfps 0
settings put system peak_refresh_rate 0
settings put system user_refresh_rate 0
settings put system min_refresh_rate 0
settings put system thermal_limit_refresh_rate 60
settings put system miui_refresh_rate 0
settings put secure user_refresh_rate 0
settings put secure max_refresh_rate 0
settings put secure miui_refresh_rate 0
settings put secure match_content_frame_rate 1
settings put secure refresh_rate_mode 1
settings put system ext_force_refresh_rate_list 0
settings put system framepredict_enable 0
settings put system is_smart_fps 1
settings put system screen_optimize_mode 0
setprop debug.hwui.profile.maxframes 0
setprop debug.hwui.fpslimit 0
setprop debug.hwui.fps_limit 0
setprop debug.display.allow_non_native_refresh_rate_override false
setprop debug.display.render_frame_rate_is_physical_refresh_rate false
setprop debug.sf.frame_rate_multiple_threshold 1
setprop debug.sf.scroll_boost_refreshrate 0
setprop debug.sf.touch_boost_refreshrate 0
setprop debug.sf.prim_perf_120hz_base_brightness_zone ""
setprop debug.sf.prim_std_brightness_zone ""
setprop debug.sf.cli_perf_brightness_zone ""
setprop debug.sf.cli_std_brightness_zone ""
cmd display set-match-content-frame-rate-pref 1
cmd power set-fixed-performance-mode-enabled false
cmd power set-adaptive-power-saver-enabled true
cmd power set-mode 1
cmd thermalservice override-status 1
pm enable-user com.miui.powerkeeper
