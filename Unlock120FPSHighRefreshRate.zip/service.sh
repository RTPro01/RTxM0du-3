#!/system/bin/sh

NAME="Unlock 120 FPS / High Refresh Rate"
VERSION="1.0.0 | Unlock120FPS"
ANDROIDVERSION=$(getprop ro.build.version.release)
DEVICE=$(getprop ro.product.device)
MANUFACTURER=$(getprop ro.product.manufacturer)
DATE=$(date)

sleep 2
echo "
▄█─ █▀█ █▀▀█ 　 ── 　 ░█▀▀▀ ░█▀▀█ ░█▀▀▀█ 
─█─ ─▄▀ █▄▀█ 　 ▀▀ 　 ░█▀▀▀ ░█▄▄█ ─▀▀▀▄▄ 
▄█▄ █▄▄ █▄▄█ 　 ── 　 ░█─── ░█─── ░█▄▄▄█"
echo ""
sleep 2

echo "==============================="
echo "   $NAME"
echo "   Version : $VERSION"
echo "   Android : ${ANDROIDVERSION:-Unknown}"
echo "   Device  : ${DEVICE:-Unknown}"
echo "   Maker   : ${MANUFACTURER:-Unknown}"
echo "   Date    : $DATE"
echo "==============================="

setprop debug.performance.tuning 1
setprop debug.composition.type gpu
setprop debug.gr.numframebuffers 3
setprop debug.hwui.target_cpu_time_percent 100
setprop debug.hwui.level 0
setprop debug.hwui.show_layers_updates false
setprop debug.hwui.overdraw false
setprop debug.hwui.profile false
setprop debug.hwui.show_dirty_regions false
setprop debug.hwui.skip_empty_damage true
setprop debug.hwui.filter_test_overhead false
setprop debug.hwui.use_gpu_pixel_buffers true
setprop debug.hwui.renderer skiagl
setprop debug.hwui.capture_skp_enabled false
setprop debug.hwui.trace_gpu_resources false
setprop debug.hwui.skia_tracing_enabled false
setprop debug.hwui.skia_use_perfetto_track_events false
setprop renderthread.skia.reduceopstasksplitting true
setprop debug.hwui.webview_overlays_enabled false
setprop debug.hwui.drawing_enabled true
setprop debug.hwui.use_hint_manager true
setprop debug.hwui.app_memory_policy aggressive
setprop debug.hwui.8bit_hdr_headroom 0
setprop debug.hwui.initialize_gl_always true
setprop debug.hwui.skip_eglmanager_telemetry true
setprop debug.hwui.early_preload_gl_context true
setprop debug.hwui.use_buffer_age true
setprop debug.hwui.use_partial_updates true
setprop debug.hwui.disable_vsync true
setprop debug.hwui.force_draw_frame true
setprop debug.hwui.enable_partial_updates true
setprop debug.hwui.override_render_pipeline skiagl
setprop debug.hwui.override_gpu_tracking true
setprop debug.hwui.override_render_pipeline skiagl
setprop debug.renderengine.backend skiagl
setprop debug.renderengine.graphite_preview_optin true
setprop debug.renderengine.capture_skia_ms 0
setprop debug.renderengine.capture_filename ""
setprop debug.renderengine.blur_algorithm none
setprop debug.renderengine.skia_atrace_enabled false
setprop debug.sf.set_idle_timer_ms 0
setprop debug.sf.set_idle_timer_ms_0 0
setprop debug.sf.support_kernel_idle_timer_0 true
setprop debug.sf.enable_layer_caching true
setprop debug.sf.disable_client_composition_cache false
setprop debug.sf.predict_hwc_composition_strategy 1
setprop debug.sf.treat_170m_as_sRGB 1
setprop debug.sf.dim_in_gamma_in_enhanced_screenshots 0
setprop debug.sf.ignore_hwc_physical_display_orientation true
setprop debug.sf.enable_gl_backpressure 0
setprop debug.sf.use_frame_rate_priority 1
setprop debug.sf.luma_sampling 1
setprop debug.sf.treble_testing_override true
setprop debug.sf.auto_latch_unsignaled true
setprop debug.sf.hwc_service_name default
setprop debug.sf.enable_hwc_vds 0
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.hw 1
setprop debug.egl.hw 1
setprop debug.egl.buffercount 2
setprop debug.gralloc.map_fb_memory 0
setprop debug.gralloc.gfx_ubwc_disable 0
setprop debug.gralloc.enable_fb_ubwc 1
setprop debug.graphics.game_default_frame_rate.disabled 1
setprop debug.graphics.hint_session_cts_api_override 1
setprop debug.hwc.use_rate_limiter false
setprop debug.hwc.bq_count 3
setprop debug.hwc.compose_level 3
setprop debug.hwc.nodirtyregion 1
setprop debug.hwc.dynThreshold 2.0
setprop debug.perf_event_max_sample_rate 0
setprop debug.perf_cpu_time_max_percent 0
setprop debug.perf_event_mlock_kb 0
setprop debug.sf.frame_rate_multiple_threshold 0
setprop debug.sf.stable_edid_ids 0
setprop debug.sf.multithreaded_present 1
setprop debug.egl.force_msaa false
setprop debug.egl.swapbehavior 0
setprop debug.gl.disable_batching 0
setprop debug.gl.profiler 0
setprop debug.gl.buffer_age 1
setprop debug.sf.vsync_reactor_ignore_present_fences true
setprop debug.sf.late_sf_use_app_refresh 0
setprop debug.sf.useSmart90ForVideo 0
setprop debug.qc.hardware true
setprop debug.qctwa.statusbar 1
setprop debug.qctwa.preservebuf 1
setprop debug.sf.showupdates 0
setprop debug.sf.showcpu 0
setprop debug.sf.showbackground 0
setprop debug.sf.showfps 0
setprop debug.sf.multithreaded_present 1
setprop debug.sf.auto_latch_unsignaled true
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.hw 1
setprop debug.refresh_rate.min_fps 120
setprop debug.refresh_rate.max_fps 120
setprop debug.refresh_rate.peak_fps 120
setprop debug.display.allow_non_native_refresh_rate_override true
setprop debug.display.render_frame_rate_is_physical_refresh_rate true
setprop debug.graphics.game_default_frame_rate.disabled 1
setprop debug.graphics.hint_session_cts_api_override 1
setprop debug.hwc.force_gpu 0
setprop debug.egl.swapinterval 0
setprop debug.hwui.override_render_pipeline skiagl
setprop debug.renderengine.backend skiagl
setprop debug.renderengine.blur_algorithm none
setprop debug.gl.swapinterval 0
setprop debug.composition.type gpu
setprop debug.gralloc.enable_fb_ubwc 1
setprop debug.gralloc.gfx_ubwc_disable 0
setprop debug.gralloc.map_fb_memory 0
setprop debug.sf.high_fps_late_app_phase_offset_ns -5000000
setprop debug.sf.high_fps_late_sf_phase_offset_ns -5000000
setprop debug.sf.high_fps_early_phase_offset_ns -5000000
setprop debug.sf.high_fps_early_gl_phase_offset_ns -5000000
setprop debug.sf.high_fps_early_app_phase_offset_ns -5000000
setprop debug.sf.early_gl_app_phase_offset_ns -5000000
setprop debug.sf.early_phase_offset_ns -5000000
setprop debug.sf.early_gl_phase_offset_ns -5000000
setprop debug.sf.early_app_phase_offset_ns -5000000
setprop debug.sf.late.app.duration 0
setprop debug.sf.early.sf.duration -5000000
setprop debug.sf.early.app.duration -5000000
setprop debug.sf.earlyGl.sf.duration -5000000
setprop debug.sf.earlyGl.app.duration -5000000
setprop debug.sf.hwc.min.duration -1000000
setprop debug.sf.hwc.min.duration 0
setprop debug.gpu.fake_gpu_vendor "Qualcomm"
setprop debug.gpu.fake_gpu_renderer "Adreno (TM) 830"
setprop debug.touch_sensitivity_mode 1
settings put system db_screen_rate 2
settings put system perf_proc_threshold 0
settings put system perf_proc_power 0
settings put system perf_shielder_Proc 0
settings put system POWER_PERFORMANCE_MODE_OPEN 1
settings put system multicore_packet_scheduler 1
settings put system high_performance_mode_on 1
settings put system sem_performance_mode 4
settings put system speed_mode 1
settings put secure high_priority 1
settings put secure speed_mode_enable 1
settings put global sem_enchanced_cpu_responsiveness 1
settings put global cached_apps_freezer "enabled"
settings put global restricted_device_performance "0,0"
settings put global adaptive_battery_management_enabled 0
settings put global game_auto_temperature_control 0
settings put system perf_shielder_SF 0
settings put system perf_shielder_RTMODE 1
settings put system perf_shielder_GESTURE 0
settings put system perf_shielder_smartpower 0
settings put system screen_game_mode 1
settings put secure gb_boosting 1
settings put secure high_priority 1
settings put system POWER_SAVE_MODE_OPEN 0
settings put global automatic_power_save_mode 0
settings put global low_power 0
settings put system framepredict_enable 1
settings put system is_smart_fps 0
settings put system screen_optimize_mode 1
settings put system framepredict_enable 1
settings put system perf_shielder_SF 0
settings put system fstb_target_fps_margin_high_fps 20
settings put system fstb_target_fps_margin_low_fps 20
settings put system gcc_fps_margin 10
settings put secure support_highfps 1

settings put system peak_refresh_rate 1
settings put system user_refresh_rate 120
settings put system min_refresh_rate 120
settings put system thermal_limit_refresh_rate 0
settings put system miui_refresh_rate 120
settings put secure user_refresh_rate 1
settings put secure max_refresh_rate 120
settings put secure miui_refresh_rate 120
settings put secure match_content_frame_rate 0
settings put secure refresh_rate_mode 2
settings put system ext_force_refresh_rate_list 120
settings put system db_screen_rate 2
settings put system framepredict_enable 1
settings put system is_smart_fps 0
settings put system screen_optimize_mode 1
setprop debug.hwui.profile.maxframes 120
setprop debug.hwui.fpslimit 120
setprop debug.hwui.fps_limit 120
setprop debug.display.allow_non_native_refresh_rate_override true
setprop debug.display.render_frame_rate_is_physical_refresh_rate true
setprop debug.sf.frame_rate_multiple_threshold 0
setprop debug.sf.scroll_boost_refreshrate 120
setprop debug.sf.touch_boost_refreshrate 120
setprop debug.sf.showupdates 0
setprop debug.sf.showcpu 0
setprop debug.sf.showbackground 0
setprop debug.sf.showfps 0
setprop debug.refresh_rate.min_fps 120
setprop debug.refresh_rate.max_fps 120
setprop debug.refresh_rate.peak_fps 120
setprop debug.graphics.game_default_frame_rate.disabled true
setprop debug.sf.prim_perf_120hz_base_brightness_zone 120:120:120,120:120:120
setprop debug.sf.prim_perf_120hz_base_brightness_zone 120:120:120,120:120:120,120:120:120
setprop debug.sf.prim_std_brightness_zone 120:120:120,120:120:120
setprop debug.sf.cli_perf_brightness_zone 120:120:120
setprop debug.sf.cli_std_brightness_zone 120:120:120

cmd display set-match-content-frame-rate-pref 0
cmd power set-fixed-performance-mode-enabled true
cmd power set-adaptive-power-saver-enabled false
cmd power set-mode 0
cmd thermalservice override-status 0
pm disable-user com.miui.powerkeeper

echo "[$NAME] Optimization⚡."
cmd notification post -S bigtext -t 'Unlock 120 FPS' '⚡' " Tweaks Running"