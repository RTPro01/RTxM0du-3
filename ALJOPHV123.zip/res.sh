#!/system/bin/sh

echo "
 🔄 CODM  BOOST RESET (SAFE)
 Mode    : Restore Default System Settings
 Access  : Non-Root (ADB / Shizuku)
"

sleep 2

echo "========================================"
echo " RESETTING CODM  BOOST SETTINGS "
echo "========================================"

sleep 2

echo "
 🔓 CPU / POWER STABILITY RESET
"

# Disable fixed performance mode
cmd power set-fixed-performance-mode-enabled false

# Restore default memory factor
cmd activity memory-factor set 1

sleep 2

echo "
 🧠 FREEZE & STUTTER SETTINGS RESET
"

# Restore phantom & background process killer
settings put global settings_enable_monitor_phantom_procs true 2>/dev/null
settings put global app_standby_enabled 1 2>/dev/null

# Restore background process limit
settings put global cached_apps_freezer enabled true
settings put global background_process_limit 3

sleep 2

echo "
 🧹 LOGGING & OVERHEAD RESET
"

# Restore logging
setprop persist.sys.log.level 1
setprop persist.vendor.log.level 1
setprop log.tag.ActivityManager DEFAULT
setprop log.tag.WindowManager DEFAULT

sleep 2

echo "
 🚀 BACKGROUND GOOGLE APP RESET
"

ESSENTIAL_PACKAGES="com.google.android.gms
com.google.android.gsf
com.android.vending"

for pkg in $(cmd package list packages google | cut -f2 -d:); do
  echo "$ESSENTIAL_PACKAGES" | grep -q "$pkg" && continue
  echo "Restoring: $pkg"
  cmd appops reset "$pkg"
  cmd appops set "$pkg" RUN_IN_BACKGROUND allow
  cmd appops set "$pkg" RUN_ANY_IN_BACKGROUND allow
done

sleep 2

echo "
 🎯 CODM GAME OPTIMIZATION RESET
"

CODM_PKG="com.garena.game.codm"

# Reset CODM appops
cmd appops reset $CODM_PKG
cmd appops set $CODM_PKG RUN_IN_BACKGROUND ignore
cmd appops set $CODM_PKG RUN_ANY_IN_BACKGROUND ignore

# Reset game mode
settings put global game_mode 0

sleep 2
echo "✅  BOOST RESET COMPLETE
"

sleep 2

echo "========================================"
echo " CODM  BOOST SETTINGS FULLY RESTORED "
echo "========================================"