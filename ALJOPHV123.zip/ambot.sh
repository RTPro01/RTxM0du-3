#!/system/bin/sh

echo "
 🎮 CODM GARENA  BOOSTER (SAFE)
 Edition : PAID / 
 Mode    : Extreme Performance (No Screen Issues)
 Access  : Non-Root (ADB / Shizuku)
"

sleep 2

echo "========================================"
echo " CODM GARENA  PERFORMANCE MODE ACTIVE "
echo "========================================"

sleep 2

echo "
 🔒 CPU / POWER STABILITY (ANTI-FREEZE)
"

# Lock device to sustained performance mode
cmd power set-fixed-performance-mode-enabled true

# Lowest memory pressure (prevents frame drops)
cmd activity memory-factor set 0

sleep 2

echo "
 🧠 FREEZE & STUTTER FIX (ANDROID SYSTEM)
"

# Disable phantom & background process killer
settings put global settings_enable_monitor_phantom_procs false 2>/dev/null
settings put global app_standby_enabled 0 2>/dev/null

# Reduce aggressive task killing
settings put global cached_apps_freezer enabled false
settings put global background_process_limit 0

sleep 2

echo "
 🧹 LOGGING & OVERHEAD REMOVAL
"

# Disable unnecessary logs
setprop persist.sys.log.level 0 2>/dev/null
setprop persist.vendor.log.level 0 2>/dev/null
setprop log.tag.ActivityManager SUPPRESS 2>/dev/null
setprop log.tag.WindowManager SUPPRESS 2>/dev/null

sleep 2

echo "
 🛡️ GOOGLE CORE SERVICES (SAFE LIST)
"

ESSENTIAL_PACKAGES="com.google.android.gms
com.google.android.gsf
com.android.vending"

echo "
 🚀 BACKGROUND GOOGLE APP LIMITER (SAFE)
"

for pkg in $(cmd package list packages google | cut -f2 -d:); do
   Skip essential packages
  echo "$ESSENTIAL_PACKAGES" | grep -q "$pkg" && continue
  echo "Optimizing: $pkg"

  cmd appops reset "$pkg"
  cmd appops set "$pkg" RUN_IN_BACKGROUND ignore
  cmd appops set "$pkg" RUN_ANY_IN_BACKGROUND ignore
done

sleep 2

echo "
 🎯 CODM GARENA GAME OPTIMIZATION
"

CODM_PKG="com.garena.game.codm"

# Prioritize CODM background execution
cmd appops set $CODM_PKG RUN_IN_BACKGROUND allow
cmd appops set $CODM_PKG RUN_ANY_IN_BACKGROUND allow

# Reduce system interference during gameplay
settings put global game_mode 2

sleep 2
echo "
 ✅ BOOST COMPLETE
"

sleep 2

echo "========================================"
echo " CODM  BOOST APPLIED SUCCESSFULLY "
echo "========================================"