#!/system/bin/sh
#

# LowTex Shader Preload SERVICE v2.1.0






log() {
  echo "[LowTex Shader Service v2.1.0] $1"
}


log "Waiting for system boot..."
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

log "Boot completed. Starting Shader Preload SERVICE..."




settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0




setprop debug.hwui.renderer opengl
setprop debug.hwui.force_gpu_rendering true
setprop debug.hwui.disable_vsync true
setprop debug.hwui.render_thread false
setprop debug.hwui.use_buffer_age false





setprop debug.egl.max_texture_size 256
setprop debug.hwui.texture_cache_size 4
setprop debug.hwui.texture_cache_flush 1
setprop debug.hwui.filter_quality lowest
setprop debug.hwui.texture_quality lowest
setprop debug.hwui.disable_textures true




setprop debug.egl.disable_texture_compression 1
setprop debug.hwui.drop_shadow_cache true
setprop debug.hwui.disable_layers_cache true
setprop debug.hwui.disable_profile_rendering true
setprop debug.hwui.render_dirty_regions false




setprop debug.egl.swapinterval 1
setprop debug.gr.swapinterval 1
setprop debug.egl.sync 1




setprop debug.sf.hw 1
setprop debug.sf.disable_backpressure 1
setprop debug.sf.enable_gl_backpressure 1
setprop debug.sf.disable_client_composition 1
setprop debug.sf.use_client_composition false




setprop persist.sys.gpu.profiler false
setprop debug.hwui.overdraw 0
setprop debug.hwui.disable_scissor true




log "Starting temperature control loop..."

while true; do
  TEMP=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null)

  if [ ! -z "$TEMP" ]; then
    TEMP_C=$((TEMP / 1000))

    if [ "$TEMP_C" -ge 45 ]; then
      log "High temp detected: ${TEMP_C}°C → lowering load"

      
      setprop debug.hwui.disable_vsync true
      setprop debug.hwui.texture_cache_flush 1
      setprop debug.egl.max_texture_size 256
    fi
  fi

  sleep 10
done