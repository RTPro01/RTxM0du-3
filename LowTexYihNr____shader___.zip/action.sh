#!/system/bin/sh

BLUE='\033[34m'
RESET='\033[0m'

echo -e "${BLUE}==========================================${RESET}"
echo -e "${BLUE}   LowTex Shader Preload SERVICE v2.1.0   ${RESET}"
echo -e "${BLUE}==========================================${RESET}"
echo ""

echo -e "${BLUE} Developer : @yih855${RESET}"
echo -e "${BLUE} Engine    : Shader Preload / HWUI Control${RESET}"
echo -e "${BLUE} Profile   : Low GPU Load • Temp Control${RESET}"
echo ""

echo -e "${BLUE} Features:${RESET}"
echo -e "${BLUE} - Forces OpenGL HWUI renderer${RESET}"
echo -e "${BLUE} - Preloads & limits shader/texture usage${RESET}"
echo -e "${BLUE} - Reduces GPU overdraw & memory pressure${RESET}"
echo -e "${BLUE} - Dynamic thermal load reduction${RESET}"
echo ""

echo -e "${BLUE} [YES] Shader Preload service ACTIVE${RESET}"
echo -e "${BLUE}==========================================${RESET}"
echo ""