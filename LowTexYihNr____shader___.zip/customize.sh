#!/system/bin/sh

BLUE='\033[34m'
RESET='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════════╗${RESET}"
echo -e "${BLUE}║      Starting LowTex Shader Preload Service    ║${RESET}"
echo -e "${BLUE}║                   Installation v2.1.0     ║${RESET}"
echo -e "${BLUE}╚════════════════════════════════════════════╝${RESET}"
echo ""

echo -e "${BLUE}   Developer      : @yih855${RESET}"
echo -e "${BLUE}   Module Name    : LowTex Shader Preload${RESET}"
echo -e "${BLUE}   Module Version : v2.1.0${RESET}"
echo -e "${BLUE}   Profile        : Low GPU Load / Thermal Safe${RESET}"
echo ""

echo -e "${BLUE}   Module Function:${RESET}"
echo -e "${BLUE}   - Forces OpenGL HWUI renderer${RESET}"
echo -e "${BLUE}   - Preloads and limits shader execution${RESET}"
echo -e "${BLUE}   - Reduces texture size and GPU memory usage${RESET}"
echo -e "${BLUE}   - Dynamic temperature-based load control${RESET}"
echo ""

echo -e "${BLUE} [-] Installing shader preload service...${RESET}"
sleep 1
echo -e "${BLUE} [-] Applying GPU and HWUI limits...${RESET}"
sleep 1
echo -e "${BLUE} [-] Configuring thermal protection loop...${RESET}"
sleep 1
echo -e "${BLUE} [-] Finalizing installation...${RESET}"
sleep 1

echo -e "${BLUE} [-] Installation Successful${RESET}"
echo ""

echo -e "${BLUE}╔════════════════════════════════════════════╗${RESET}"
echo -e "${BLUE}║  LowTex Shader Preload Service is ACTIVE  ║${RESET}"
echo -e "${BLUE}╚════════════════════════════════════════════╝${RESET}"
echo ""