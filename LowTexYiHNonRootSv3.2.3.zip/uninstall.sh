#!/system/bin/sh


# Revert all tweaks
# Developer:yih855


echo() {
  echo "[Sulasuk  optimization RESET] $1"
}

echo "Starting module reset. Reverting all performance tweaks..."





echo "Resetting graphics & GPU..."
settings put global force_msaa 0
settings put global force_gpu_rendering 0
settings delete global debug_hwui_renderer
settings delete global enable_gpu_debug_layers
setprop debug.force-opengl 0
setprop debug.hwui.renderer ""
setprop debug.hwui.force_gpu 0
setprop debug.hwui.render_dirty_regions 1
settings delete global force_hardware_layers
settings delete global render_thread_priority




echo "Restoring UI & animations..."
settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1
settings delete global disable_window_blurs
settings delete global accessibility_reduce_transparency
settings delete secure long_press_timeout
settings delete secure multi_press_timeout
settings delete secure tap_duration_threshold
settings delete secure touch_blocking_period




echo "Restoring refresh rate & FPS..."
settings delete system peak_refresh_rate
settings delete system min_refresh_rate
settings delete system refresh_rate_mode
settings delete system touch_latency_mode
settings delete global max_frame_rate
settings delete global vsync_enabled




echo "Resetting touch & input..."
settings put system pointer_speed 5
settings delete system touchscreen_gestures_enabled
settings delete global gesture_touches_enabled
settings delete global stylus_high_precision
settings delete secure pointer_accuracy




echo "Disabling performance mode..."
cmd power set-fixed-performance-mode-enabled false
settings put global low_power 1
settings put global battery_saver_enabled 1
settings delete global high_performance_mode
settings delete global game_mode_enabled
settings delete global cpu_boost_enabled
settings delete global gpu_boost_enabled
settings delete global performance_mode_enabled




echo "Restoring memory & background settings..."
settings delete global cached_apps_freezer
settings delete global background_process_limit
settings delete global bg_job_scheduler_enabled
settings delete global service_auto_restart
settings delete global enable_zram
settings delete global dalvik_heap_growth_limit
settings delete global dalvik_gc_tuning_enabled
settings delete global memory_pressure_reduce
settings delete global aggressive_cache_clear




echo "Resetting thermal & FPS tweaks..."
setprop debug.thermal.throttle.support yes
settings delete global thermal_limit_refresh_rate
settings delete global throttle_cpu_enabled
settings delete global throttle_gpu_enabled
settings delete global sem_low_heat_mode
settings delete global cpu_thermal_boost
settings delete global gpu_thermal_boost
settings delete global frame_drop_protection




echo "Restoring network settings..."
settings delete global network_speed_boost_enabled
settings delete global wifi_scan_throttle_enabled
settings delete global tcp_fastopen_enabled
settings delete global low_latency_network_mode
settings delete global multiplayer_mode_enabled
settings delete global reduce_packet_loss




echo "Resetting game overlays & performance mode..."
for pkg in $(cmd package list packages -3 | cut -f2 -d:); do
    device_config delete game_overlay "$pkg"
    cmd game mode reset "$pkg"
done

echo "Sulasok optimization reset completed."


echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

echo "RESET COMPLETE. Device should now behave like default settings. Restart recommended."