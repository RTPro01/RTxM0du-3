#!/system/bin/sh

#Sulasuk  optimization
#Developer:@yih855

echo() {
  echo "[MaxPerfFullGraphics] $1"
}


while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

echo "Boot completed. Starting  Sulasuk  optimization..."




echo "Applying graphics & GPU tweaks..."
settings put global force_gpu_rendering 1
settings put global debug_hwui_renderer skiagl
settings put global enable_gpu_debug_layers 0
setprop debug.force-opengl 1
setprop debug.hwui.renderer skiagl
setprop debug.hwui.force_gpu 1
setprop debug.hwui.render_dirty_regions 0
settings put global force_hardware_layers 1
settings put global render_thread_priority 2




echo "Smooth animations..."
settings put global window_animation_scale 0.4
settings put global transition_animation_scale 0.4
settings put global animator_duration_scale 0.5
settings put global disable_window_blurs 1
settings put global accessibility_reduce_transparency 1
settings put secure long_press_timeout 180
settings put secure multi_press_timeout 200
settings put secure tap_duration_threshold 0.0
settings put secure touch_blocking_period 0.0





echo "Maximizing refresh rate & FPS..."
settings put system peak_refresh_rate 120
settings put system min_refresh_rate 120
settings put system refresh_rate_mode 2
settings put system touch_latency_mode 1
settings put global max_frame_rate 144
settings put global vsync_enabled 1




echo "Optimizing touch & input..."
settings put system pointer_speed 7
settings put system touchscreen_gestures_enabled 1
settings put global gesture_touches_enabled 1
settings put global stylus_high_precision 1
settings put secure pointer_accuracy 1





echo "Applying performance mode..."
cmd power set-fixed-performance-mode-enabled true
settings put global low_power 0
settings put global battery_saver_enabled 0
settings put global high_performance_mode 1
settings put global game_mode_enabled 1
settings put global cpu_boost_enabled 1
settings put global gpu_boost_enabled 1
settings put global performance_mode_enabled 1




echo "Optimizing memory & background apps..."
settings put global cached_apps_freezer enabled
settings put global background_process_limit 1
settings put global bg_job_scheduler_enabled 0
settings put global service_auto_restart 0
settings put global enable_zram 1
settings put global dalvik_heap_growth_limit 512
settings put global dalvik_gc_tuning_enabled 1
pm trim-caches 128G
settings put global memory_pressure_reduce 1
settings put global aggressive_cache_clear 1



echo "Reducing thermal limits & stabilizing FPS..."
setprop debug.thermal.throttle.support no
settings put global thermal_limit_refresh_rate 0
settings put global throttle_cpu_enabled 0
settings put global throttle_gpu_enabled 0
settings put global sem_low_heat_mode 1
settings put global cpu_thermal_boost 1
settings put global gpu_thermal_boost 1
settings put global frame_drop_protection 1




echo "Optimizing network for gaming..."
settings put global network_speed_boost_enabled 1
settings put global wifi_scan_throttle_enabled 0
settings put global tcp_fastopen_enabled 1
settings put global low_latency_network_mode 1
settings put global multiplayer_mode_enabled 1
settings put global reduce_packet_loss 1




echo "Applying Sulasuk  optimization performance mode to all installed games..."

for pkg in $(cmd package list packages -3 | cut -f2 -d:); do

  
  device_config put game_overlay "$pkg" \
  mode=2,downscaleFactor=0.49,fps=144

  cmd game mode performance "$pkg"


  echo "Applied to: $pkg | scale=0.49"
done
  pid=$(pidof "$pkg")
  if [ -n "$pid" ]; then
    nice -n -1 -p "$pid"
    renice -n -6 -p "$pid"
  fi
  echo "Applied max perf to: $pkg"
done




echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

echo "Sulasuk  optimization module applied successfully. Restart recommended for full effect."