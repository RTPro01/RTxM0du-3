#!/system/bin/sh
#
# OWKININAM 1.0 - TWEAKS
# Developer: OWKININAM 1.0 @owkinenam
#
# Define logging function
log() {
  echo "[OWKININAM 1.0] $1"
}

# Wait for boot completion
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

log "Boot completed. Starting AUTO-GAME optimization..."

# Detect system properties
FPS=$(settings get system peak_refresh_rate 2>/dev/null || 
      settings get system user_refresh_rate 2>/dev/null || echo 120)
log "Detected max refresh rate: $FPS"

RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 1500000)
ANDROID_VER=$(getprop ro.build.version.release)
log "RAM: $RAM_KB KB | CPU: $CPU_MAX_FREQ | Android: $ANDROID_VER"

# Determine device class and downscale factor
if [ "$RAM_KB" -ge 8000000 ] && [ "$CPU_MAX_FREQ" -ge 2600000 ]; then
  DOWNSCALE=0.55
  CLASS="HIGH-END"
elif [ "$RAM_KB" -ge 6000000 ]; then
  DOWNSCALE=0.5
  CLASS="UPPER-MID"
elif [ "$RAM_KB" -ge 4000000 ]; then
  DOWNSCALE=0.47
  CLASS="MID"
else
  DOWNSCALE=0.45
  CLASS="LOW-END"
fi

log "Device class: $CLASS"
log "Auto-selected downscaleFactor = $DOWNSCALE"

# Apply performance tweaks
log "Applying super smooth performance tweaks..."
apply_performance_tweaks() {
  setprop debug.sf.early_app_transition 1
  setprop debug.sf.earlyGlAppFrames 3
  setprop debug.sf.early_scheduling 1
  setprop debug.sf.hw 1
  setprop debug.sf.latch_unsignaled 1
  setprop debug.sf.perf 1
}

# Enable SKIAGL rendering for CODM
log "Enabling SKIAGL rendering for CODM..."
setprop debug.skiagl.game com.garena.game.codm
setprop debug.skiagl.game.enable true

# Apply super low texture command
log "Applying super low texture command..."
setprop debug.force_low_texture true

# Disable animations
log "Disabling animations..."
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

# Optimize display
log "Optimizing display..."
cmd display set-match-content-frame-rate-pref 1 2>/dev/null
cmd display set-user-disabled-hdr-types 1 2 3 4 2>/dev/null

# Optimize memory
log "Optimizing memory..."
cmd activity memory-factor set 0 2>/dev/null
settings put global settings_enable_monitor_phantom_procs false
settings put global app_standby_enabled 0
settings put global fstrim_mandatory_interval 1

# Enable touch boost
log "Enabling touch boost..."
settings put secure long_press_timeout 180
settings put secure multi_press_timeout 200
[ -e /sys/module/msm_performance/parameters/touchboost ] && 
 echo 1 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null
[ -e /sys/power/pnpmgr/touch_boost ] && 
 echo 1 > /sys/power/pnpmgr/touch_boost 2>/dev/null

# Enable gaming performance and flagship mode
log "Enabling gaming performance and flagship mode..."
setprop persist.sys.gaming.performance 1
setprop ro.product.gaming.flagship 1
log "Gaming performance and flagship mode enabled for Oppo, Infinix, Realme, Samsung, Itel, Tecno, Xiaomi devices"

# Apply system performance tweaks
log "Applying system performance tweaks..."
apply_performance_tweaks
setprop debug.hwui.render_dirty_regions false
settings put global game_driver_all_apps 1

# Apply AUTO downscale and performance mode to all installed games
log "Applying AUTO downscale + performance mode to all installed games..."
for pkg in $(cmd package list packages -3 | cut -f2 -d:); do
  cmd device_config put game_overlay "$pkg" mode=2,downscaleFactor=$DOWNSCALE,fps=60
  cmd game mode performance "$pkg"
  log "Applying process priority tweaks..."
  pid=$(pidof "$pkg")
  if [ -n "$pid" ]; then
    nice -n -1 -p "$pid"
    renice -n -1 -p "$pid"
  fi
  log "Applied to: $pkg | scale=$DOWNSCALE"
done

# Optimize Google packages
log "Optimizing Google packages (background apps & appops)..."
for a in $(cmd package list packages google | cut -f2 -d: | grep -v ia.mo); do
  cmd appops reset "$a"
  cmd appops set "$a" FOREGROUND_SERVICE_SPECIAL_USE ignore
  cmd appops set "$a" INSTANT_APP_START_FOREGROUND ignore
  cmd appops set "$a" RUN_ANY_IN_BACKGROUND ignore
  cmd appops set "$a" RUN_IN_BACKGROUND ignore
  cmd package revoke --all-permissions "$a"
done

# Grant essential permissions to Google Play Services
log "Granting essential permissions back to Google Play Services..."
cmd package grant com.google.android.gms android.permission.READ_CONTACTS
cmd package grant com.google.android.gms android.permission.WRITE_CONTACTS

# Apply Android 14+ game flags
if [ "$ANDROID_VER" -ge 14 ]; then
  log "Applying Android 14+ game flags..."
  cmd device_config override game android.os.adpf_prefer_power_efficiency false 2>/dev/null
  cmd device_config override game android.os.adpf_hwui_gpu true 2>/dev/null
fi

# Drop caches
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
log "OWKININAM 1.0 tweaks applied successfully."