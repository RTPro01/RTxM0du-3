#!/system/bin/sh



# This is my first time to create basic plugins 
#Developer: LowTexYíH @yih855

echo() {
  echo "[LowTexYíH Dynamic CHIP] $1"
}


while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

echo "Boot completed. LowTexYíH Dynamic CHIP Starting AUTO-GAME optimization..."




FPS=$(settings get system peak_refresh_rate 2>/dev/null || \
      settings get system user_refresh_rate 2>/dev/null || echo 120)

echo "Detected max refresh rate: $FPS"

CHIPSET=$(getprop ro.hardware | tr 'A-Z' 'a-z')
SOC_VENDOR=$(getprop ro.soc.manufacturer | tr 'A-Z' 'a-z')

IS_MTK=0
IS_QCOM=0
IS_UNISOC=0

echo "$CHIPSET $SOC_VENDOR" | grep -q "mtk\|mediatek" && IS_MTK=1
echo "$CHIPSET $SOC_VENDOR" | grep -q "qcom\|qualcomm" && IS_QCOM=1
echo "$CHIPSET $SOC_VENDOR" | grep -q "unisoc\|spreadtrum" && IS_UNISOC=1

SAFE_FPS=60




if [ "$IS_MTK" -eq 1 ]; then
  echo "MediaTek detected! Enabling MTK SAFE Gaming Mode..."

  settings put system peak_refresh_rate $SAFE_FPS 2>/dev/null
  settings put system min_refresh_rate $SAFE_FPS 2>/dev/null

  
  for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_max_freq; do
    echo 1800000 > "$cpu" 2>/dev/null
  done

  
  setprop vendor.thermal.throttle.enable true
  setprop persist.vendor.mtk.thermal.limit 1

  echo "MTK SAFE MODE applied (60FPS, low heat)."
fi




if [ "$IS_QCOM" -eq 1 ]; then
  echo "Snapdragon detected! Enabling Snapdragon SAFE Gaming Mode..."

  settings put system peak_refresh_rate $SAFE_FPS 2>/dev/null
  settings put system min_refresh_rate $SAFE_FPS 2>/dev/null

  
  for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_max_freq; do
    echo 2000000 > "$cpu" 2>/dev/null
  done

  
  echo 0 > /sys/module/msm_performance/parameters/cpu_boost 2>/dev/null
  echo 0 > /sys/module/msm_performance/parameters/sched_boost_on_input 2>/dev/null

  
  setprop debug.hwui.max_fps $SAFE_FPS
  setprop debug.hwui.force_gpu_rendering true

  echo "Snapdragon SAFE MODE applied (60FPS stable)."
fi




if [ "$IS_UNISOC" -eq 1 ]; then
  echo "UNISOC detected! Enabling UNISOC SAFE Gaming Mode..."

  settings put system peak_refresh_rate $SAFE_FPS 2>/dev/null
  settings put system min_refresh_rate $SAFE_FPS 2>/dev/null


  for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_max_freq; do
    echo 1600000 > "$cpu" 2>/dev/null
  done

  
  setprop persist.vendor.sys.sprd.echo 0
  setprop persist.sys.sprd.echo 0

  echo "UNISOC SAFE MODE applied (60FPS stable)."
fi


RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 1500000)
ANDROID_VER=$(getprop ro.build.version.release)

echo "RAM: $RAM_KB KB | CPU: $CPU_MAX_FREQ | Android: $ANDROID_VER"


if [ "$RAM_KB" -ge 8000000 ] && [ "$CPU_MAX_FREQ" -ge 2600000 ]; then
  DOWNSCALE=0.5
  CLASS="HIGH-END"
elif [ "$RAM_KB" -ge 6000000 ]; then
  DOWNSCALE=0.49
  CLASS="UPPER-MID"
elif [ "$RAM_KB" -ge 4000000 ]; then
  DOWNSCALE=0.48
  CLASS="MID"
else
  DOWNSCALE=0.47
  CLASS="LOW-END"
fi

echo "Device class: $CLASS"
echo "Auto-selected downscaleFactor = $DOWNSCALE"




echo "Disabling animations..."
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0




echo "Optimizing display..."
cmd display set-match-content-frame-rate-pref 1 2>/dev/null
cmd display set-user-disabled-hdr-types 1 2 3 4 2>/dev/null




echo "Optimizing memory..."
cmd activity memory-factor set 0 2>/dev/null
settings put global settings_enable_monitor_phantom_procs false
settings put global app_standby_enabled 0
settings put global fstrim_mandatory_interval 1




echo "Enabling touch boost..."
settings put secure long_press_timeout 180
settings put secure multi_press_timeout 200

[ -e /sys/module/msm_performance/parameters/touchboost ] && \
echo 1 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null

[ -e /sys/power/pnpmgr/touch_boost ] && \
echo 1 > /sys/power/pnpmgr/touch_boost 2>/dev/null




echo "Reducing thermal limits..."
setprop debug.thermal.throttle.support no 2>/dev/null





echo "Applying AUTO downscale + performance mode to all installed games..."

for pkg in $(cmd package list packages -3 | cut -f2 -d:); do

  
  cmd device_config put game_overlay "$pkg" \
  mode=2,downscaleFactor=$DOWNSCALE,fps=$FPS

  cmd game mode performance "$pkg"

  echo "Applied to: $pkg | scale=$DOWNSCALE"
done




if [ "$ANDROID_VER" -ge 14 ]; then
  echo "Applying Android 14+ game flags..."

  cmd device_config override game android.os.adpf_prefer_power_efficiency false 2>/dev/null
  cmd device_config override game android.os.adpf_hwui_gpu true 2>/dev/null
fi




echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

echo "LowTexYíH Dynamic CHIP applied successfully."
