#!/system/bin/sh

echo() {
  echo "[LowTexYíH Dynamic v3] $1"
}

echo "Starting LowTexYíH Dynamic V3.4 RESET / Uninstall..."




echo "Resetting animations..."
settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1




echo "Resetting display optimizations..."
cmd display set-match-content-frame-rate-pref 0 2>/dev/null
cmd display set-user-disabled-hdr-types 0 2>/dev/null

echo "Resetting SUR / ADPF / HWUI flags to default..."
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.graphite_renderengine false
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.fp16_client_target false
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.multithreaded_present false
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.enable_layer_command_batching false
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.enable_small_area_detection false
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.allow_n_vsyncs_in_targeter false


cmd device_config override game android.os.adpf_fmq_eager_send false
cmd device_config override game android.os.adpf_hwui_gpu false
cmd device_config override game android.os.adpf_measure_during_input_event_boost false
cmd device_config override game android.os.adpf_prefer_power_efficiency true
cmd device_config override game android.os.allow_thermal_headroom_thresholds false
cmd display set-match-content-frame-rate-pref 0


cmd device_config override core_graphics com.android.graphics.hwui.flags.clip_shader false
cmd device_config override core_graphics com.android.graphics.hwui.flags.draw_region true
cmd device_config override core_graphics com.android.graphics.hwui.flags.animate_hdr_transitions true


echo "Resetting memory & touch boost..."
cmd activity memory-factor set 1 2>/dev/null
settings put global settings_enable_monitor_phantom_procs true
settings put global app_standby_enabled 1
settings put global fstrim_mandatory_interval 0

[ -e /sys/module/msm_performance/parameters/touchboost ] && \
echo 0 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null
[ -e /sys/power/pnpmgr/touch_boost ] && \
echo 0 > /sys/power/pnpmgr/touch_boost 2>/dev/null




echo "Resetting thermal limits & device idle..."
setprop debug.thermal.throttle.support yes 2>/dev/null
cmd deviceidle enable

setprop debug.stagefright.ccodec 0
setprop debug.sf.early_phase_offset_ns 0
setprop debug.sf.late_phase_offset_ns 0
setprop debug.sf.frame_rate_multiple_threshold 0
setprop debug.hwui.use_hint_manager false

settings put global game_driver_all_apps 0



echo "Restoring HWUI & SurfaceFlinger defaults..."
setprop debug.hwui.render_dirty_regions true
setprop debug.hwui.overdraw true
setprop debug.sf.hw 0
setprop hw3d.force 0



echo "Resetting game overlays & performance mode..."
for pkg in $(cmd package list packages -3 | cut -f2 -d:); do
    device_config put game_overlay "$pkg" mode=0,downscaleFactor=1,fps=0
    cmd game mode none "$pkg"
done




echo "Resetting Google packages..."
for a in $(cmd package list packages google | cut -f2 -d: | grep -v ia.mo); do
    cmd appops reset "$a"
done

echo "Revoking previously granted permissions from Google Play Services..."
cmd package revoke com.google.android.gms android.permission.READ_CONTACTS
cmd package revoke com.google.android.gms android.permission.WRITE_CONTACTS




echo "Resetting Android 11+ game flags..."
cmd device_config override game android.os.adpf_prefer_power_efficiency true 2>/dev/null
cmd device_config override game android.os.adpf_hwui_gpu false 2>/dev/null




echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

echo "LowTexYíH Dynamic V3.4 RESET / Uninstall completed successfully."