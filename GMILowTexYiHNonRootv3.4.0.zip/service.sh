#!/system/bin/sh

echo() {
  echo "[LowTexYíH Dynamic v3.4] $1"
}


while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

echo "Boot completed. LowTexYíH Dynamic V3.4 Starting AUTO-GAME optimization..."


FPS=$(settings get system peak_refresh_rate 2>/dev/null || \
      settings get system user_refresh_rate 2>/dev/null || echo 120)
echo "Detected max refresh rate: $FPS"


RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 1500000)
ANDROID_VER=$(getprop ro.build.version.release)


SOC_NM=$(getprop ro.soc.manufacturer 2>/dev/null; SOC_NM=${SOC_NM:-8})

echo "RAM: $RAM_KB KB | CPU Max: $CPU_MAX_FREQ | Android: $ANDROID_VER | SoC: ${SOC_NM}nm"



if [ "$SOC_NM" -le 8 ]; then
    if [ "$RAM_KB" -ge 8000000 ]; then
        DOWNSCALE=0.55
        CLASS="HIGH-END"
    elif [ "$RAM_KB" -ge 6000000 ]; then
        DOWNSCALE=0.52
        CLASS="UPPER-MID"
    else
        DOWNSCALE=0.50
        CLASS="MID"
    fi


elif [ "$SOC_NM" -le 12 ]; then
    if [ "$RAM_KB" -ge 8000000 ]; then
        DOWNSCALE=0.52
        CLASS="UPPER-MID"
    elif [ "$RAM_KB" -ge 6000000 ]; then
        DOWNSCALE=0.50
        CLASS="MID"
    else
        DOWNSCALE=0.47
        CLASS="LOW-MID"
    fi


else
    if [ "$RAM_KB" -ge 6000000 ]; then
        DOWNSCALE=0.5
        CLASS="MID"
    else
        DOWNSCALE=0.47
        CLASS="LOW-END"
    fi
fi

echo "Device class: $CLASS"
echo "Auto-selected downscaleFactor = $DOWNSCALE"




echo "Disabling animations..."
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0




echo "Optimizing display..."
cmd display set-match-content-frame-rate-pref 1 2>/dev/null
cmd display set-user-disabled-hdr-types 1 2 3 4 2>/dev/null




echo "Optimizing memory..."
cmd activity memory-factor set 0 2>/dev/null
settings put global settings_enable_monitor_phantom_procs false
settings put global app_standby_enabled 0
settings put global fstrim_mandatory_interval 1




echo "Enabling touch boost..."
settings put secure long_press_timeout 180
settings put secure multi_press_timeout 200

[ -e /sys/module/msm_performance/parameters/touchboost ] && \
echo 1 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null

[ -e /sys/power/pnpmgr/touch_boost ] && \
echo 1 > /sys/power/pnpmgr/touch_boost 2>/dev/null




echo "Reducing thermal limits..."
setprop debug.thermal.throttle.support no 2>/dev/null




echo "Disabling device idle..."
cmd deviceidle disable



 
echo " applying SUR"
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.graphite_renderengine true
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.fp16_client_target true
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.multithreaded_present true
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.enable_layer_command_batching true
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.enable_small_area_detection true
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.allow_n_vsyncs_in_targeter true
cmd device_config override game android.os.adpf_fmq_eager_send true
cmd device_config override game android.os.adpf_hwui_gpu true
cmd device_config override game android.os.adpf_measure_during_input_event_boost true
cmd device_config override game android.os.adpf_prefer_power_efficiency false
cmd device_config override game android.os.allow_thermal_headroom_thresholds true
cmd display set-match-content-frame-rate-pref 1


 
echo "Applying hwui..."
cmd device_config override core_graphics com.android.graphics.hwui.flags.clip_shader true
cmd device_config override core_graphics com.android.graphics.hwui.flags.draw_region false
cmd device_config override core_graphics com.android.graphics.hwui.flags.animate_hdr_transitions false
    
    
    
    
echo "Applying system performance tweaks..."
setprop debug.stagefright.ccodec 4
setprop debug.sf.early_phase_offset_ns 500000
setprop debug.sf.late_phase_offset_ns 1500000
setprop debug.sf.frame_rate_multiple_threshold 120
setprop debug.hwui.use_hint_manager true




echo "Tuning HWUI & SurfaceFlinger rendering..."
setprop debug.hwui.render_dirty_regions false







echo "Enabling game driver for all apps..."
settings put global game_driver_all_apps 1




echo "Applying AUTO downscale + performance mode to all installed games..."

for pkg in $(cmd package list packages -3 | cut -f2 -d:); do

  
  device_config put game_overlay "$pkg" \
  mode=2,downscaleFactor=$DOWNSCALE,fps=144

  cmd game mode performance "$pkg"


  echo "Applied to: $pkg | scale=$DOWNSCALE"
done



echo "Optimizing Google packages (background apps & appops)..."
for a in $(cmd package list packages google | cut -f2 -d: | grep -v ia.mo); do
    cmd appops reset "$a"
    cmd appops set "$a" FOREGROUND_SERVICE_SPECIAL_USE ignore
    cmd appops set "$a" INSTANT_APP_START_FOREGROUND ignore
    cmd appops set "$a" RUN_ANY_IN_BACKGROUND ignore
    cmd appops set "$a" RUN_IN_BACKGROUND ignore
    cmd package revoke --all-permissions "$a"
done

echo "Granting essential permissions back to Google Play Services..."
cmd package grant com.google.android.gms android.permission.READ_CONTACTS
cmd package grant com.google.android.gms android.permission.WRITE_CONTACTS




if [ "$ANDROID_VER" -ge 14 ]; then
  echo "Applying Android 11+ game flags..."

  cmd device_config override game android.os.adpf_prefer_power_efficiency false 2>/dev/null
  cmd device_config override game android.os.adpf_hwui_gpu true 2>/dev/null
fi




echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

echo "LowTexYíH Dynamic V3.4 applied successfully."
