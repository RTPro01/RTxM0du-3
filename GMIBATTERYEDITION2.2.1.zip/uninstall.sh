#!/system/bin/sh

# LowTexYíH GMI v2.2.0
# Reset / Uninstall GMI BATTERY Edition
# Developer: LowTexYíH @yih855

log() {
  echo "[LowTexYíH RESET] $1"
}

echo "Starting reset to stock settings..."


setprop persist.sys.smartfps 1
setprop persist.sys.autofps.mode 1
setprop persist.sys.fpsctrl.enable 1

settings put secure peak_refresh_rate 120
settings put secure min_refresh_rate 60
settings put secure user_refresh_rate 120

settings put global refresh_rate 120
settings put global min_refresh_rate 60
settings put global max_refresh_rate 120

settings put system peak_refresh_rate 120
settings put system min_refresh_rate 60
settings put system max_refresh_rate 120


setprop debug.sf.use_frame_rate_priority 0
setprop debug.sf.max_frame_latency 3
setprop debug.sf.disable_backpressure 0
setprop debug.sf.latch_unsignaled true
setprop debug.sf.enable_vsync_immed 0

setprop debug.sf.early.app.duration 0
setprop debug.sf.late.app.duration 0
setprop debug.sf.early.sf.duration 0
setprop debug.sf.late.sf.duration 0


setprop debug.input.lowlatency 0
setprop debug.touchscreen.latency.scale 1.0


setprop debug.hwui.use_buffer_age 0
setprop debug.hwui.skip_empty_damage 0
setprop debug.hwui.use_partial_updates 0
setprop debug.hwui.enable_buffer_queue_pacing 1


setprop debug.choreographer.low_latency 0
setprop debug.choreographer.zero_jitter 0
setprop debug.choreographer.skipwarning 0


setprop debug.egl.swapinterval 1
setprop debug.gr.swapinterval 1


settings put global animator_duration_scale 1.0
settings put global transition_animation_scale 1.0
settings put global window_animation_scale 1.0


for pkg in $(cmd package list packages -3 | cut -f2 -d:); do
  device_config delete game_overlay "$pkg"
  cmd game mode none "$pkg"
  echo "Reset: $pkg | overlay removed | game mode cleared"
done


service call SurfaceFlinger 1035 i32 0

echo "LowTexYíH GMI BATTERY settings reset successfully. All changes reverted."