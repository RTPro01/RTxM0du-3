#!/system/bin/sh

# LowTexYíH Dynamic v2.2.0
# GMI Edition
# Battery Game Mode • 60FPS
# Developer: LowTexYíH @yih855
echo"=============================================="
echo"  LowTexYíH Dynamic v2.2.0  |  GMI Battery     "
echo"=============================================="
echo ""

echo" Developer : @yih855"
echo" Engine     : Dynamic Game Manager Interface"
echo" Profile      : Battery / COOL / 60FPS"
echo ""

echo" Features:"
echo" - Device-based resolution downscale"
echo" - Forced 60Hz refresh rate"
echo" - SmartFPS / AutoFPS disabled"
echo" - Game Mode: BATTERY (GMI)"
echo ""

echo() {
  echo "[LowTexYíH COOL] $1"
}


while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

echo "Boot completed. Starting COOL dynamic optimization..."


SOC_NM=$(getprop ro.soc.manufacturing_process)
[ -z "$SOC_NM" ] && SOC_NM=12


RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 1500000)
ANDROID_VER=$(getprop ro.build.version.release)

echo "Detected SoC: ${SOC_NM}nm | RAM: ${RAM_KB}KB | CPU Max: ${CPU_MAX_FREQ} | Android: $ANDROID_VER"


if [ "$SOC_NM" -le 6 ]; then

  if [ "$RAM_KB" -ge 8000000 ]; then
    DOWNSCALE=0.53
  elif [ "$RAM_KB" -ge 6000000 ]; then
    DOWNSCALE=0.51
  else
    DOWNSCALE=0.49
  fi
else
  
  if [ "$RAM_KB" -ge 6000000 ]; then
    DOWNSCALE=0.49
  else
    DOWNSCALE=0.46
  fi
fi

echo "Auto-selected downscaleFactor = $DOWNSCALE"




setprop persist.sys.smartfps 0
setprop persist.sys.autofps.mode 0
setprop persist.sys.fpsctrl.enable 0

settings put secure peak_refresh_rate 60
settings put secure min_refresh_rate 60
settings put secure user_refresh_rate 60

settings put global refresh_rate 60
settings put global min_refresh_rate 60
settings put global max_refresh_rate 60

settings put system peak_refresh_rate 60
settings put system min_refresh_rate 60
settings put system max_refresh_rate 60




setprop debug.sf.early.app.duration 10000000
setprop debug.sf.late.app.duration 13000000


setprop debug.sf.early.sf.duration 8000000
setprop debug.sf.late.sf.duration 11000000




setprop debug.input.lowlatency 1
setprop debug.touchscreen.latency.scale 0.25

 



setprop debug.hwui.skip_empty_damage 1
setprop debug.hwui.use_partial_updates 1
setprop debug.hwui.enable_buffer_queue_pacing 0




setprop debug.choreographer.low_latency 1
setprop debug.choreographer.zero_jitter 0





setprop debug.egl.swapinterval 1
setprop debug.gr.swapinterval 1




settings put global animator_duration_scale 0.2
settings put global transition_animation_scale 0.2
settings put global window_animation_scale 0.2




for pkg in $(cmd package list packages -3 | cut -f2 -d:); do

  device_config put game_overlay "$pkg" \
  mode=3,downscaleFactor=$DOWNSCALE,fps=$FPS

  cmd game mode battery "$pkg"

  echo "Applied: $pkg | scale=$DOWNSCALE | BATTERY | 60FPS"
done


echo" [>] Initializing dynamic service..."
sleep 1
echo" [>] Applying frame pacing & latency config..."
sleep 1
echo" [>] Locking system refresh rate..."
sleep 1

echo" [YES] Dynamic GMI optimization ACTIVE"
echo"=============================================="
echo ""


echo "COOL Dynamic optimization applied successfully."