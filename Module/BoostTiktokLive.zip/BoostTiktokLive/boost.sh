#!/system/bin/sh
echo "Boosting for TikTok Live Gaming..."
settings put global window_animation_scale 0.0
settings put global transition_animation_scale 0.0
settings put global animator_duration_scale 0.0
cmd power set-fixed-performance-mode-enabled true
settings put system peak_refresh_rate 120.0
settings put system min_refresh_rate 120.0
settings put global disable_window_blurs 1
settings put global accessibility_reduce_transparency 1
settings put global zram_enabled 0
settings put global ram_expand_size 0
settings put global wifi_power_save 0
settings put global adaptive_battery_management_enabled 0
settings put system multicore_packet_scheduler 1
settings put global sem_enhanced_cpu_responsiveness 1
settings put secure long_press_timeout 250
settings put secure multi_press_timeout 250
settings put global app_restriction_enabled true
sleep 1
echo "Boost complete! Launch TikTok Live now."