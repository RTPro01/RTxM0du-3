#!/system/bin/sh
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0
cmd power set-fixed-performance-mode-enabled false
settings put global zram_enabled 1
settings put global wifi_power_save 1
settings put system peak_refresh_rate 120.0
settings put system min_refresh_rate 60.0
settings put global disable_window_blurs 0
echo "All settings reverted to defaults!"