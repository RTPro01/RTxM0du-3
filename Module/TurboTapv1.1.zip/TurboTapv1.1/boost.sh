#!/system/bin/sh
#===============================================================
# boost.sh - Android Performance Script (NON-ROOT)
#===============================================================


#------------------- BOOST -------------------

    log "Applying boost settings..."

    settings put global window_animation_scale 0
    settings put global transition_animation_scale 0
    settings put global animator_duration_scale 0
    settings put global cached_apps_freezer enabled
    settings put global app_standby_enabled 1
    settings put global adaptive_battery_management_enabled 1
    settings put global enable_gpu_debug_layers 0
    settings put global show_hw_screen_updates 0
    settings put global show_hw_layers_updates 0
    settings put global debug_view_attributes 0
    settings put global force_gpu_rendering 0

    settings put secure long_press_timeout 250
    settings put secure multi_press_timeout 180

    settings put system pointer_speed 5
    settings put system haptic_feedback_enabled 0
    settings put system sound_effects_enabled 0
    settings put system lockscreen_sounds_enabled 0
    settings put system min_refresh_rate 120
    settings put system peak_refresh_rate 120

    log "Boost settings applied"
    log "Clearing caches..."
    cmd package trim-caches 999G 2>/dev/null
    logcat -c 2>/dev/null
    log "Caches cleared"

        echo ""