#!/system/bin/sh

# ============================================================
# Device Capability Scanner v1.0.0
# ============================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[OK]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_header() { echo -e "${MAGENTA}$1${NC}"; }

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║          Device Capability Scanner v1.0.0                ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

# BASIC INFO
log_header "📱 DEVICE INFORMATION"
echo ""
DEVICE_MODEL=$(getprop ro.product.model 2>/dev/null || echo "Unknown")
DEVICE_BRAND=$(getprop ro.product.brand 2>/dev/null || echo "Unknown")
DEVICE_MANUFACTURER=$(getprop ro.product.manufacturer 2>/dev/null || echo "Unknown")
ANDROID_VERSION=$(getprop ro.build.version.release 2>/dev/null || echo "Unknown")
SDK_LEVEL=$(getprop ro.build.version.sdk 2>/dev/null || echo "0")
SECURITY_PATCH=$(getprop ro.build.version.security_patch 2>/dev/null || echo "Unknown")

echo "  Model:           $DEVICE_MODEL"
echo "  Brand:           $DEVICE_BRAND"
echo "  Manufacturer:    $DEVICE_MANUFACTURER"
echo "  Android:         $ANDROID_VERSION (API $SDK_LEVEL)"
echo "  Security Patch:  $SECURITY_PATCH"
echo ""

# HARDWARE INFO
log_header "⚙️ HARDWARE INFORMATION"
echo ""

CPU_HARDWARE=$(cat /proc/cpuinfo | grep Hardware | cut -d':' -f2 | xargs 2>/dev/null || echo "Unknown")
CPU_CORES=$(cat /proc/cpuinfo | grep "processor" | wc -l 2>/dev/null || echo "0")
CPU_GOVERNOR=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null || echo "Unknown")
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo "0")

if [ "$CPU_MAX_FREQ" != "0" ]; then
    CPU_MAX_MHZ=$(($CPU_MAX_FREQ / 1000))
else
    CPU_MAX_MHZ="Unknown"
fi

echo "  Chipset:         $CPU_HARDWARE"
echo "  CPU Cores:       $CPU_CORES"
echo "  CPU Governor:    $CPU_GOVERNOR"
echo "  Max CPU Freq:    ${CPU_MAX_MHZ}MHz"
echo ""

GPU_RENDERER=$(dumpsys SurfaceFlinger | grep "GLES:" | cut -d':' -f2 | xargs 2>/dev/null || echo "Unknown")
echo "  GPU:             $GPU_RENDERER"
echo ""

TOTAL_RAM_KB=$(cat /proc/meminfo | grep MemTotal | awk '{print $2}' 2>/dev/null || echo "0")
TOTAL_RAM_GB=$(($TOTAL_RAM_KB / 1024 / 1024))
AVAILABLE_RAM_KB=$(cat /proc/meminfo | grep MemAvailable | awk '{print $2}' 2>/dev/null || echo "0")
AVAILABLE_RAM_GB=$(($AVAILABLE_RAM_KB / 1024 / 1024))

echo "  Total RAM:       ${TOTAL_RAM_GB}GB"
echo "  Available RAM:   ${AVAILABLE_RAM_GB}GB"
echo ""

ZRAM_STATUS=$(cat /sys/block/zram0/disksize 2>/dev/null | awk '{print $1/1024/1024/1024"GB"}' || echo "Disabled")
echo "  ZRAM/Swap:       $ZRAM_STATUS"
echo ""

# DISPLAY INFO
log_header "🖥️ DISPLAY INFORMATION"
echo ""

DISPLAY_INFO=$(dumpsys display 2>/dev/null)
RESOLUTION=$(echo "$DISPLAY_INFO" | grep -m 1 "displayWidth" | sed 's/.*displayWidth=\([0-9]*\).*displayHeight=\([0-9]*\).*/\1x\2/' 2>/dev/null || echo "Unknown")
REFRESH_RATE=$(echo "$DISPLAY_INFO" | grep -m 1 "refreshRate" | grep -o "[0-9]*\.\?[0-9]*" | head -1 2>/dev/null || echo "60")

echo "  Resolution:      $RESOLUTION"
echo "  Refresh Rate:    ${REFRESH_RATE}Hz"
echo ""

# BATTERY INFO
log_header "🔋 BATTERY INFORMATION"
echo ""

BATTERY_LEVEL=$(dumpsys battery | grep level | awk '{print $2}' 2>/dev/null || echo "Unknown")
BATTERY_TEMP=$(dumpsys battery | grep temperature | awk '{print $2}' 2>/dev/null || echo "0")

if [ "$BATTERY_TEMP" != "0" ] && [ "$BATTERY_TEMP" != "Unknown" ]; then
    BATTERY_TEMP_C=$(($BATTERY_TEMP / 10))
else
    BATTERY_TEMP_C="Unknown"
fi

echo "  Battery Level:   ${BATTERY_LEVEL}%"
echo "  Temperature:     ${BATTERY_TEMP_C}°C"
echo ""

# COMPATIBILITY CHECK
log_header "✅ COMPATIBILITY CHECK"
echo ""

COMPAT_SCORE=0
MAX_SCORE=0

check_feature() {
    local name=$1
    local condition=$2
    local points=$3
    MAX_SCORE=$((MAX_SCORE + points))
    
    if eval "$condition"; then
        log_success "$name: PASS (+$points)"
        COMPAT_SCORE=$((COMPAT_SCORE + points))
    else
        log_warn "$name: FAIL"
    fi
}

check_feature "Android 9+ (API 28+)" "[ $SDK_LEVEL -ge 28 ]" 20
check_feature "4GB+ RAM" "[ $TOTAL_RAM_GB -ge 4 ]" 15
check_feature "60Hz+ Display" "[ $(echo "$REFRESH_RATE >= 60" | bc 2>/dev/null || echo "0") -eq 1 ]" 10
check_feature "ADB Shell Access" "true" 15
check_feature "Settings Write Access" "settings put global tiktok_boost_test 1 2>/dev/null && settings delete global tiktok_boost_test 2>/dev/null && true" 15
check_feature "Game Mode API (Android 12+)" "[ $SDK_LEVEL -ge 31 ]" 10
check_feature "Fixed Performance Mode" "cmd power get-fixed-performance-mode-enabled 2>/dev/null >/dev/null && true" 10
check_feature "Background App Killing" "am kill-all 2>/dev/null && true" 5

echo ""
echo "  Score: $COMPAT_SCORE / $MAX_SCORE"

if [ $COMPAT_SCORE -ge 80 ]; then
    log_success "EXCELLENT: Full optimization support!"
elif [ $COMPAT_SCORE -ge 60 ]; then
    log_success "GOOD: Most optimizations will work"
elif [ $COMPAT_SCORE -ge 40 ]; then
    log_warn "FAIR: Some optimizations unavailable"
else
    log_error "POOR: Limited support"
fi

echo ""

# TIKTOK DETECTION
log_header "📲 TIKTOK APP DETECTION"
echo ""

TIKTOK_FOUND=0
for pkg in "com.zhiliaoapp.musically" "com.ss.android.ugc.trill" "com.zhiliaoapp.musically.go" "com.ss.android.ugc.trill.go"; do
    if pm list packages | grep -q "$pkg"; then
        VERSION=$(dumpsys package "$pkg" | grep versionName | head -1 | cut -d'=' -f2 2>/dev/null || echo "Unknown")
        echo "  Package:  $pkg"
        echo "  Version:  $VERSION"
        TIKTOK_FOUND=1
        echo ""
    fi
done

if [ $TIKTOK_FOUND -eq 0 ]; then
    log_error "TikTok not installed!"
else
    log_success "TikTok detected"
fi

echo ""

# RECOMMENDATIONS
log_header "💡 RECOMMENDATIONS"
echo ""

if [ $TOTAL_RAM_GB -lt 4 ]; then
    log_warn "Low RAM. Close ALL background apps before streaming."
fi

if [ $(echo "$REFRESH_RATE < 90" | bc 2>/dev/null || echo "0") -eq 1 ]; then
    log_warn "60Hz display. Consider 720p30 stream."
fi

if [ "$BATTERY_TEMP_C" != "Unknown" ] && [ $BATTERY_TEMP_C -gt 40 ]; then
    log_warn "Device hot! Use cooling fan before boost."
fi

if [ $SDK_LEVEL -lt 31 ]; then
    log_warn "Android <12. Game Mode API unavailable."
fi

log_info "Optimal stream settings:"
if [ $TOTAL_RAM_GB -ge 8 ] && [ $(echo "$REFRESH_RATE >= 90" | bc 2>/dev/null || echo "0") -eq 1 ]; then
    echo "  • 1080p60 / 4000-6000 kbps / High-Ultra"
elif [ $TOTAL_RAM_GB -ge 6 ]; then
    echo "  • 720p60 / 3000-4500 kbps / Medium-High"
else
    echo "  • 720p30 / 2000-3000 kbps / Low-Medium"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# ============================================================
# TikTok Live Gaming Performance Booster - Universal Module
# Version: 1.0.0
# Compatible: Android 9+ (All Devices)
# ============================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[OK]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_step() { echo -e "${CYAN}[STEP]${NC} $1"; }

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║     TikTok Live Gaming Performance Booster v1.0.0      ║"
echo "║              Universal ADB Optimization Module           ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

# ======================= DEVICE DETECTION =======================
log_step "Detecting device capabilities..."

DEVICE_MODEL=$(getprop ro.product.model 2>/dev/null || echo "Unknown")
DEVICE_BRAND=$(getprop ro.product.brand 2>/dev/null || echo "Unknown")
ANDROID_VERSION=$(getprop ro.build.version.release 2>/dev/null || echo "Unknown")
SDK_LEVEL=$(getprop ro.build.version.sdk 2>/dev/null || echo "0")
CHIPSET=$(getprop ro.hardware 2>/dev/null || echo "Unknown")
TOTAL_RAM=$(cat /proc/meminfo | grep MemTotal | awk '{print int($2/1024/1024)}' 2>/dev/null || echo "0")
REFRESH_RATE=$(dumpsys display | grep -m 1 "refreshRate" | grep -o "[0-9]*" | head -1 2>/dev/null || echo "60")

TIKTOK_PKG=""
if pm list packages | grep -q "com.zhiliaoapp.musically"; then
    TIKTOK_PKG="com.zhiliaoapp.musically"
elif pm list packages | grep -q "com.ss.android.ugc.trill"; then
    TIKTOK_PKG="com.ss.android.ugc.trill"
fi

echo ""
echo "  Device:    $DEVICE_BRAND $DEVICE_MODEL"
echo "  Android:   $ANDROID_VERSION (API $SDK_LEVEL)"
echo "  Chipset:   $CHIPSET"
echo "  RAM:       ${TOTAL_RAM}GB"
echo "  Display:   ${REFRESH_RATE}Hz"
echo "  TikTok:    ${TIKTOK_PKG:-Not Installed}"
echo ""

if [ "$SDK_LEVEL" -lt 28 ]; then
    log_warn "Android version below 9 (API 28). Some optimizations may not work."
fi

# ======================= BACKUP =======================
log_step "Creating settings backup..."

BACKUP_DIR="/sdcard/tiktok_boost_backup"
mkdir -p "$BACKUP_DIR"

echo "$(date): Backup before boost" > "$BACKUP_DIR/backup_timestamp.txt"

settings get global window_animation_scale > "$BACKUP_DIR/window_animation_scale.txt" 2>/dev/null
settings get global transition_animation_scale > "$BACKUP_DIR/transition_animation_scale.txt" 2>/dev/null
settings get global animator_duration_scale > "$BACKUP_DIR/animator_duration_scale.txt" 2>/dev/null
settings get system peak_refresh_rate > "$BACKUP_DIR/peak_refresh_rate.txt" 2>/dev/null
settings get system min_refresh_rate > "$BACKUP_DIR/min_refresh_rate.txt" 2>/dev/null
settings get global disable_window_blurs > "$BACKUP_DIR/disable_window_blurs.txt" 2>/dev/null
settings get global accessibility_reduce_transparency > "$BACKUP_DIR/reduce_transparency.txt" 2>/dev/null
settings get global wifi_power_save > "$BACKUP_DIR/wifi_power_save.txt" 2>/dev/null
settings get global zram_enabled > "$BACKUP_DIR/zram_enabled.txt" 2>/dev/null
settings get global ram_expand_size > "$BACKUP_DIR/ram_expand_size.txt" 2>/dev/null
settings get global adaptive_battery_management_enabled > "$BACKUP_DIR/adaptive_battery.txt" 2>/dev/null
settings get secure long_press_timeout > "$BACKUP_DIR/long_press_timeout.txt" 2>/dev/null
settings get secure multi_press_timeout > "$BACKUP_DIR/multi_press_timeout.txt" 2>/dev/null

log_success "Backup saved to $BACKUP_DIR"

# ======================= OPTIMIZATIONS =======================

optimize_display() {
    log_step "Applying display & animation optimizations..."
    
    settings put global window_animation_scale 0.0
    settings put global transition_animation_scale 0.0
    settings put global animator_duration_scale 0.0
    log_success "Animations disabled"
    
    if [ "$REFRESH_RATE" -ge 90 ]; then
        settings put system peak_refresh_rate ${REFRESH_RATE}.0
        settings put system min_refresh_rate ${REFRESH_RATE}.0
        log_success "Refresh rate locked to ${REFRESH_RATE}Hz"
    else
        settings put system peak_refresh_rate 60.0
        settings put system min_refresh_rate 60.0
        log_success "Refresh rate locked to 60Hz"
    fi
    
    settings put global disable_window_blurs 1
    settings put global accessibility_reduce_transparency 1
    log_success "Blur & transparency effects disabled"
}

optimize_performance() {
    log_step "Applying CPU/GPU performance optimizations..."
    
    if [ "$SDK_LEVEL" -ge 31 ]; then
        cmd power set-fixed-performance-mode-enabled true 2>/dev/null
        if [ $? -eq 0 ]; then
            log_success "Fixed Performance Mode enabled"
        else
            log_warn "Fixed Performance Mode not supported"
        fi
    else
        log_warn "Fixed Performance Mode requires Android 12+"
    fi
    
    settings put global sem_enhanced_cpu_responsiveness 1 2>/dev/null
    settings put global multicore_packet_scheduler 1 2>/dev/null
    log_success "CPU responsiveness enhanced"
}

optimize_memory() {
    log_step "Applying memory optimizations..."
    
    am kill-all 2>/dev/null
    log_success "Background apps killed"
    
    pm trim-caches 128G 2>/dev/null
    log_success "App caches trimmed"
    
    if [ "$TOTAL_RAM" -ge 6 ]; then
        settings put global zram_enabled 0 2>/dev/null
        settings put global ram_expand_size 0 2>/dev/null
        log_success "Virtual RAM disabled"
    else
        log_warn "Device has <6GB RAM - keeping virtual RAM"
    fi
}

optimize_input() {
    log_step "Applying touch input optimizations..."
    
    settings put secure long_press_timeout 250 2>/dev/null
    settings put secure multi_press_timeout 250 2>/dev/null
    settings put secure tap_duration_threshold 0 2>/dev/null
    settings put secure touch_blocking_period 0 2>/dev/null
    log_success "Touch latency reduced"
}

optimize_network() {
    log_step "Applying network optimizations..."
    
    settings put global wifi_power_save 0 2>/dev/null
    settings put global mobile_data_always_on 0 2>/dev/null
    settings put global ble_scan_always_enabled 0 2>/dev/null
    settings put global network_scoring_ui_enabled 0 2>/dev/null
    settings put global network_recommendations_enabled 0 2>/dev/null
    log_success "Network power saving disabled"
}

optimize_system() {
    log_step "Applying system-level optimizations..."
    
    settings put system send_security_reports 0 2>/dev/null
    settings put secure send_action_app_error 0 2>/dev/null
    settings put global activity_starts_logging_enabled 0 2>/dev/null
    settings put system rakuten_denwa 0 2>/dev/null
    
    settings put global adaptive_battery_management_enabled 0 2>/dev/null
    settings put global app_restriction_enabled false 2>/dev/null
    settings put global auto_sync 0 2>/dev/null
    
    log_success "Background logging, sync, battery restrictions disabled"
}

optimize_tiktok() {
    log_step "Optimizing TikTok app..."
    
    if [ -n "$TIKTOK_PKG" ]; then
        if [ "$SDK_LEVEL" -ge 31 ]; then
            cmd game mode performance "$TIKTOK_PKG" 2>/dev/null
            if [ $? -eq 0 ]; then
                log_success "TikTok set to Performance Mode"
            fi
        fi
        
        am force-stop "$TIKTOK_PKG" 2>/dev/null
        log_info "TikTok restarted with clean state"
    else
        log_warn "TikTok not detected"
    fi
}

# ======================= EXECUTE =======================

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

optimize_display
optimize_performance
optimize_memory
optimize_input
optimize_network
optimize_system
optimize_tiktok

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

log_step "Optimization complete! Ready for TikTok Live Gaming."
echo ""
echo "  ✓ Animations disabled"
echo "  ✓ Max refresh rate active"
echo "  ✓ CPU/GPU performance mode enabled"
echo "  ✓ Memory optimized"
echo "  ✓ Touch latency reduced"
echo "  ✓ Network stabilized"
echo "  ✓ Background processes minimized"
echo ""
log_warn "IMPORTANT:"
echo "  • Device will run hotter and drain battery faster"
echo "  • Use active cooling fan for sessions >30 minutes"
echo "  • Run 'restore_defaults.sh' after streaming to revert"
echo ""
echo "  Backup: $BACKUP_DIR"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

svc power stayon true 2>/dev/null || settings put system screen_off_timeout 1800000 2>/dev/null

exit 0
