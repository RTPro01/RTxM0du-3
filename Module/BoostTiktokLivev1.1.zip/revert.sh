#!/system/bin/sh
# ============================================================
# TikTok Live Gaming Booster - Restore Defaults
# Version: 1.0.0
# ============================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[OK]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_step() { echo -e "${CYAN}[STEP]${NC} $1"; }

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║     TikTok Live Gaming Booster - Restore Defaults      ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

BACKUP_DIR="/sdcard/tiktok_boost_backup"

restore_setting() {
    local namespace=$1
    local key=$2
    local backup_file=$3
    local default_value=$4
    
    if [ -f "$backup_file" ]; then
        local value=$(cat "$backup_file" 2>/dev/null)
        if [ -n "$value" ] && [ "$value" != "null" ]; then
            settings put $namespace $key "$value" 2>/dev/null
            log_success "Restored $key = $value"
        else
            settings put $namespace $key "$default_value" 2>/dev/null
            log_info "Restored $key to default"
        fi
    else
        settings put $namespace $key "$default_value" 2>/dev/null
        log_info "Restored $key to default"
    fi
}

log_step "Restoring display & animation settings..."
restore_setting "global" "window_animation_scale" "$BACKUP_DIR/window_animation_scale.txt" "1.0"
restore_setting "global" "transition_animation_scale" "$BACKUP_DIR/transition_animation_scale.txt" "1.0"
restore_setting "global" "animator_duration_scale" "$BACKUP_DIR/animator_duration_scale.txt" "1.0"
restore_setting "global" "disable_window_blurs" "$BACKUP_DIR/disable_window_blurs.txt" "0"
restore_setting "global" "accessibility_reduce_transparency" "$BACKUP_DIR/reduce_transparency.txt" "0"

log_step "Restoring refresh rate..."
restore_setting "system" "peak_refresh_rate" "$BACKUP_DIR/peak_refresh_rate.txt" "120.0"
restore_setting "system" "min_refresh_rate" "$BACKUP_DIR/min_refresh_rate.txt" "60.0"

log_step "Restoring performance settings..."
cmd power set-fixed-performance-mode-enabled false 2>/dev/null
log_success "Fixed Performance Mode disabled"
settings put global sem_enhanced_cpu_responsiveness 0 2>/dev/null
settings put global multicore_packet_scheduler 0 2>/dev/null

log_step "Restoring memory settings..."
restore_setting "global" "zram_enabled" "$BACKUP_DIR/zram_enabled.txt" "1"
restore_setting "global" "ram_expand_size" "$BACKUP_DIR/ram_expand_size.txt" "4096"

log_step "Restoring input settings..."
restore_setting "secure" "long_press_timeout" "$BACKUP_DIR/long_press_timeout.txt" "400"
restore_setting "secure" "multi_press_timeout" "$BACKUP_DIR/multi_press_timeout.txt" "300"
settings put secure tap_duration_threshold -1 2>/dev/null
settings put secure touch_blocking_period 10 2>/dev/null

log_step "Restoring network settings..."
restore_setting "global" "wifi_power_save" "$BACKUP_DIR/wifi_power_save.txt" "1"
settings put global mobile_data_always_on 1 2>/dev/null
settings put global ble_scan_always_enabled 1 2>/dev/null
settings put global network_scoring_ui_enabled 1 2>/dev/null
settings put global network_recommendations_enabled 1 2>/dev/null

log_step "Restoring system settings..."
settings put system send_security_reports 1 2>/dev/null
settings put secure send_action_app_error 1 2>/dev/null
settings put global activity_starts_logging_enabled 1 2>/dev/null
settings put system rakuten_denwa 1 2>/dev/null
restore_setting "global" "adaptive_battery_management_enabled" "$BACKUP_DIR/adaptive_battery.txt" "1"
settings put global app_restriction_enabled true 2>/dev/null
settings put global auto_sync 1 2>/dev/null

log_step "Restoring screen timeout..."
svc power stayon false 2>/dev/null
settings put system screen_off_timeout 30000 2>/dev/null

TIKTOK_PKG=""
if pm list packages | grep -q "com.zhiliaoapp.musically"; then
    TIKTOK_PKG="com.zhiliaoapp.musically"
elif pm list packages | grep -q "com.ss.android.ugc.trill"; then
    TIKTOK_PKG="com.ss.android.ugc.trill"
fi

if [ -n "$TIKTOK_PKG" ] && [ "$(getprop ro.build.version.sdk)" -ge 31 ]; then
    cmd game mode standard "$TIKTOK_PKG" 2>/dev/null
    log_success "TikTok game mode reset"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
log_step "All settings restored to defaults!"
echo ""
echo "  ✓ Animations restored"
echo "  ✓ Refresh rate adaptive"
echo "  ✓ Performance mode disabled"
echo "  ✓ Memory settings restored"
echo "  ✓ Touch latency reset"
echo "  ✓ Network power saving restored"
echo "  ✓ Background sync & logging restored"
echo ""
log_info "Backup kept at: $BACKUP_DIR"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

exit 0
