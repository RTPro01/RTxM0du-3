#!/system/bin/sh
# TurboTap v1.3 - Revert to Defaults
# Restore Stock Android Touch Settings
# Version: 1.3 | Date: 2026-05-23

    echo ""
    echo "==============================================="
    echo "              TURBOTAP v1.3"
    echo "               Restore Script"
    echo "   Restore Stock Android Touch Settings"
    echo "==============================================="
    echo ""

echo "TurboTap v1.3 - Reverting to Defaults..."

# Motion & Prediction
settings put global motion_prediction_enabled 0
settings put global motion_prediction_max_samples 4
settings put global acceleration_compensation 1.0
settings put global velocity_prediction_strength 0.5

# Touch Sensitivity
settings put system pointer_speed 0
settings put secure touch_slop 8
settings put secure touch_slop_scale 1
settings put secure long_press_timeout 400
settings put secure multi_press_timeout 300
settings put secure tap_timeout 180

# Touch Filtering
settings put system touch_filter_enabled 1
settings put system acceleration_factor 0
settings put system touch_resampling 0
settings put system touch_boost 0

# Gaming Detection
settings put global collision_detection_quality 0
settings put global touch_sampling_rate 0

# Display Sync
settings put system min_refresh_rate 0
settings put system peak_refresh_rate 0
settings put global disable_hw_overlays 0

# Input Optimization
settings put secure stylus_handwriting_enabled 0
settings put system show_touches 0
settings put system pointer_location 0

# Gaming Mode
settings put system game_mode_touch_response 0
settings put system touch_optimization_enabled 0
settings put system touch_response_priority 0

# Animation Latency
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0

# Memory/IO
settings put global sys_vm_stats 1
settings put global sys_vm_stats_interval 7200

# Ultra Gaming
settings put global touch_sensitivity_mode 0
settings put global touch_edge_filter 1
settings put global touch_prediction_horizon 8
settings put system touch_acceleration_profile 1

echo "Done."
echo "Successfully Reverted"
