#!/system/bin/sh
# TurboTap v1.3 - Apply Optimizations
# Ultra-Low Latency Touch Optimizer for Android Premium Devices
# Version: 1.3 | Date: 2026-05-23

    echo ""
    echo "==============================================="
    echo "              TURBOTAP v1.3"
    echo "                Apply Script"
    echo "   Ultra-Low Latency Touch Optimizer"
    echo "==============================================="
    echo ""

echo "TurboTap v1.3 - Applying Optimizations..."

# Backup
mkdir -p /sdcard/TurboTap_Backups 2>/dev/null
settings list global > /sdcard/TurboTap_Backups/global_$(date +%Y%m%d_%H%M%S).txt 2>/dev/null
settings list system > /sdcard/TurboTap_Backups/system_$(date +%Y%m%d_%H%M%S).txt 2>/dev/null
settings list secure > /sdcard/TurboTap_Backups/secure_$(date +%Y%m%d_%H%M%S).txt 2>/dev/null

# Motion & Prediction
settings put global motion_prediction_enabled 1
settings put global motion_prediction_max_samples 8
settings put global acceleration_compensation 1.5
settings put global velocity_prediction_strength 0.85

# Touch Sensitivity
settings put system pointer_speed 12
settings put secure touch_slop 6
settings put secure touch_slop_scale 8
settings put secure long_press_timeout 120
settings put secure multi_press_timeout 80
settings put secure tap_timeout 80

# Touch Filtering
settings put system touch_filter_enabled 0
settings put system acceleration_factor 1
settings put system touch_resampling 1
settings put system touch_boost 1

# Gaming Detection
settings put global collision_detection_quality 2
settings put global touch_sampling_rate 480

# Display Sync
settings put system min_refresh_rate 120
settings put system peak_refresh_rate 120
settings put global disable_hw_overlays 1

# Input Optimization
settings put secure stylus_handwriting_enabled 0
settings put system show_touches 0
settings put system pointer_location 0

# Gaming Mode
settings put system game_mode_touch_response 1
settings put system touch_optimization_enabled 1
settings put system touch_response_priority 1

# Animation Latency
settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

# Memory/IO
settings put global sys_vm_stats 0
settings put global sys_vm_stats_interval 0

# Ultra Gaming
settings put global touch_sensitivity_mode 2
settings put global touch_edge_filter 0
settings put global touch_prediction_horizon 16
settings put system touch_acceleration_profile 0

echo "Done"
echo "Successfully Applied"