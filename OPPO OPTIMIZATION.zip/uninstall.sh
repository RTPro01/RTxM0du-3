#!/system/bin/sh
# ===========================================================
# OPPO CODM BOOSTER (UNINSTALL VERSION) - BY SASUKEFILES
# ===========================================================

echo "=== OPTIMIZATION (UNINSTALL MODE)........ ==="

# ===========================================================
# REFRESH RATE & DISPLAY BOOST
# ===========================================================
echo "Refresh Rate..."

# Force Peak Refresh Rate
settings put system min_refresh_rate 1
settings put system peak_refresh_rate 1
settings put system user_refresh_rate 1
settings put global power_mode_enable 0
settings put global oppo_power_save_mode 0
settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

echo "Display boosted to Max Performance."

# Game Package Name
GAME_PKG="com.garena.game.codm"

# -----------------------------------------
# STABLE PERFORMANCE
# -----------------------------------------
# Renices the game process to highest user priority (-20)
# This tells the CPU to handle game threads before background apps.
for pid in $(pidof $GAME_PKG); do
    renice -n -20 -p $pid
    # Ionice sets I/O priority (loading speeds)
    ionice $pid be 0
done

# -----------------------------------------
# GAME OVERLAY & THREAD MANAGEMENT
# -----------------------------------------
# CODM BOOSTER
for pid in $(pidof $GAME_PKG); do
    # Attempt to move threads to the performance cluster (if accessible)
    if [ -d "/dev/cpuset/top-app" ]; then
        echo $pid > /dev/cpuset/top-app/tasks 2>/dev/null
    elif [ -d "/dev/cpuset/foreground" ]; then
        echo $pid > /dev/cpuset/foreground/tasks 2>/dev/null
    fi
done

# CODM BOOSTER
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.use_partial_updates false
setprop debug.composition.type gpu
setprop persist.sys.ui.hw true
# Trim memory
am send-trim-memory 80

# ===========================================================
# (UNINSTALL BLOATWARE) - PERMANENT
# ===========================================================
echo "Uninstalling background apps causing lag..."

# --user 0 flag uninstalls the app for the current user (works without root on most devices)
pm uninstall -k --user 0 com.oppo.market
pm uninstall -k --user 0 com.heytap.market
pm uninstall -k --user 0 com.heytap.browser
pm uninstall -k --user 0 com.nearme.statistics
pm uninstall -k --user 0 com.oppo.statistics
pm uninstall -k --user 0 com.coloros.activation
pm uninstall -k --user 0 com.facebook.system
pm uninstall -k --user 0 com.facebook.appmanager
pm uninstall -k --user 0 com.facebook.services
pm uninstall -k --user 0 com.oppo.logkit
pm uninstall -k --user 0 com.oppo.operationlog
pm uninstall -k --user 0 com.dropboxclient
pm uninstall -k --user 0 com.oppo.usercenter
pm uninstall -k --user 0 com.glance.internet

# Disable Logging
setprop debug.log.slow 0
setprop debug.hwui.profile false

echo "=== OPTIMIZATION COMPLETE ==="
echo "ACTION REQUIRED:"
echo "1. Go to Settings > Battery > Advanced Settings > High Performance Mode (Turn ON)"
echo "2. Go to Settings > Display > Screen Refresh Rate > Select HIGH (120Hz)"