sleep 1
echo ""
echo " 
█▀▀ █▀█ █▀   █░░ █▀█ █▀▀ █▄▀
█▀░ █▀▀ ▄█   █▄▄ █▄█ █▄▄ █░█ "
sleep 1
echo ""
echo " ************************************************************************ "
echo " Developer     :     RC Modz "
sleep 0.1
echo " Version       :     Stable NR "
sleep 0.1
echo " Tools         :     Brevent "
sleep 1
echo ""
echo " ************************************************************************ "
echo " CHECKING DEVICE INFORMATION "
sleep 1
echo ""
echo "CPU      : $(getprop ro.board.platform)"
echo "GPU      : $(getprop ro.hardware)"
echo "Android  : $(getprop ro.build.version.release)"
echo "Kernel   : $(uname -r)"
echo "Build    : $(getprop ro.build.display.id)"
echo "Root     : $(if [ $(id -u) -eq 0 ]; then echo 'Yes'; else echo 'No'; fi)"
echo "SELinux  : $(getenforce)"
sleep 3
echo ""
echo " ************************************************************************ "
echo " - Trimming up Partitions "
sleep 3
echo " - Deleting Cache and Trash "
sleep 5
echo " - Finalizing Props "
sleep 2
echo " - Module Flashed Successfully "
sleep 1
echo ""
echo " - RC Modz "

(
# Stable Optimized FPS - Debug Properties
setprop debug.sys.display.fps ""
setprop debug.sys.display_refresh_rate ""
setprop debug.sys.display.refresh_rate ""
setprop debug.sys.game.minfps ""
setprop debug.sys.game.maxfps ""
setprop debug.sys.game.minframerate ""
setprop debug.sys.game.maxframerate ""
setprop debug.sys.min_refresh_rate ""
setprop debug.sys.max_refresh_rate ""
setprop debug.sys.peak_refresh_rate ""
setprop debug.sys.sf.fps ""
setprop debug.sys.smartfps ""
setprop debug.sys.display.min_refresh_rate ""
setprop debug.sys.vsync_optimization_enable ""
setprop debug.sys.hwui.dyn_vsync ""
setprop debug.sys.vsync ""
setprop debug.sys.hwui.fps_mode ""
setprop debug.sys.first.frame.accelerates ""
setprop debug.sys.fps_unlock_allowed ""
setprop debug.sys.display.max_fps ""
setprop debug.sys.video.max.fps ""
setprop debug.sys.surfaceflinger.idle_reduce_framerate_enable ""
) > /dev/null 2>&1 &
(
# Stable Optimized FPS - Device System Properties
setprop sys.display.fps 120
setprop sys.display_refresh_rate 120
setprop sys.display.refresh_rate 120
setprop sys.game.minfps 120
setprop sys.game.maxfps 120
setprop sys.game.minframerate 120
setprop sys.game.maxframerate 120
setprop sys.min_refresh_rate 120
setprop sys.max_refresh_rate 120
setprop sys.peak_refresh_rate 120
setprop sys.sf.fps 120
setprop sys.smartfps 1
setprop sys.display.min_refresh_rate 120
setprop sys.vsync_optimization_enable false
setprop sys.hwui.dyn_vsync 0
setprop sys.vsync false
setprop sys.hwui.fps_mode 1
setprop sys.first.frame.accelerates true
setprop sys.fps_unlock_allowed 120
setprop sys.display.max_fps 120
setprop sys.video.max.fps 120
setprop sys.surfaceflinger.idle_reduce_framerate_enable false
) > /dev/null 2>&1 &
(
# Uninstall FPS Tweak - Remove System & Debug Props and Settings
settings delete global refresh_rate_mode
settings delete global refresh_rate_switching_type
settings delete global refresh_rate_force_high

setprop debug.hwui.refresh_rate ""
setprop debug.sf.perf_mode ""
setprop debug.hwui.disable_vsync ""
setprop debug.sf.set_idle_timer_ms ""
setprop debug.sf.latch_unsignaled ""
setprop debug.sf.high_fps_early_phase_offset_ns ""
setprop debug.sf.high_fps_late_app_phase_offset_ns ""
setprop debug.graphics.game_default_frame_rate ""
setprop debug.graphics.game_default_frame_rate.disabled ""
setprop persist.sys.gpu_perf_mode ""
setprop debug.mtk.powerhal.hint.bypass ""
setprop persist.sys.surfaceflinger.idle_reduce_framerate_enable ""
setprop sys.surfaceflinger.idle_reduce_framerate_enable ""
setprop debug.performance.profile ""
setprop debug.perf.tuning ""

settings delete global surface_flinger.use_content_detection_for_refresh_rate
settings delete global media.recorder-max-base-layer-fps
settings delete global vendor.fps.switch.default
settings delete global vendor.display.default_fps
settings delete global refresh.active

settings delete system vendor.disable_idle_fps
settings delete system vendor.display.idle_default_fps
settings delete system vendor.display.enable_optimize_refresh
settings delete system vendor.display.video_or_camera_fps.support

settings delete system game_driver_min_frame_rate
settings delete system game_driver_max_frame_rate
settings delete system game_driver_power_saving_mode
settings delete system game_driver_frame_skip_enable
settings delete system game_driver_vsync_enable
settings delete system game_driver_gpu_mode
settings delete system game_driver_fps_limit

settings delete system user_refresh_rate
settings delete system fps_limit
settings delete system max_refresh_rate_for_ui
settings delete system hwui_refresh_rate
settings delete system display_refresh_rate
settings delete system max_refresh_rate_for_gaming
settings delete system user_refresh_rate
settings delete system thermal_limit_refresh_rate
settings delete system max_refresh_rate
settings delete system min_refresh_rate

settings put system peak_refresh_rate 60
) > /dev/null 2>&1 &