#!/system/bin/sh

ANDROIDVERSION=$(getprop ro.build.version.release)
DEVICES=$(getprop ro.product.board)
MANUFACTURER=$(getprop ro.product.manufacturer)
API=$(getprop ro.build.version.sdk)
NAME="SkiaGL Renderer"
VERSION="1.0"
DATE=$(date)

printf "░█▀▀▀█ ░█─▄▀ ▀█▀ ─█▀▀█ ░█▀▀█ ░█─── ── ░█▀▀█ 
─▀▀▀▄▄ ░█▀▄─ ░█─ ░█▄▄█ ░█─▄▄ ░█─── ▀▀ ░█▄▄▀ 
░█▄▄▄█ ░█─░█ ▄█▄ ░█─░█ ░█▄▄█ ░█▄▄█ ── ░█─░█"
ui_print ""
sleep 0.5
printf " adjusts rendering for smoother performance."
sleep 0.2
ui_print ""
print_line
printf "- Name            : ${NAME}"
sleep 0.2
printf "- Version         : ${VERSION}"
sleep 0.2
printf "- Android Version : ${ANDROIDVERSION:-Unknown}"
sleep 0.2
printf "- Current Date    : ${DATE}"
sleep 0.2
print_line
printf "- Devices         : ${DEVICES:-Unknown}"
sleep 0.2
printf "- Manufacturer    : ${MANUFACTURER:-Unknown}"
sleep 0.2
print_line
printf "- Trimming up Partitions"
printf "- Deleting Cache and Trash"
sleep 2

# Set permissions
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/system/bin 0 0 0755 0755


# ----------------- OPTIMIZATION SECTIONS -----------------
  setprop debug.hwui.renderer skiagl
  setprop debug.renderengine.vulkan false
  setprop debug.renderengine.backend skiaglthreaded
  setprop debug.renderengine.capture_skia_ms 0
  setprop debug.renderengine.skia_atrace_enabled false
  setprop debug.hwui.skia_use_perfetto_track_events false
  setprop debug.hwui.skia_tracing_enabled false
  setprop debug.tracing.ctl.hwui.skia_tracing_enabled false
  setprop debug.tracing.ctl.hwui.skia_use_perfetto_track_events false
  setprop debug.tracing.ctl.renderengine.skia_tracing_enabled false
  setprop debug.tracing.ctl.renderengine.skia_use_perfetto_track_events false  
  setprop debug.renderengine.skia_tracing_enabled false
  setprop debug.renderengine.skia_use_perfetto_track_events false
  
 
sleep 0.2
print_line
printf "Successfully Applied"