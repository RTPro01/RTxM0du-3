sleep 1
echo ""
echo " 
░█▀▀█ ─█▀▀█ ░█▀▄▀█ ▀█▀ ░█▄─░█ ░█▀▀█ 
░█─▄▄ ░█▄▄█ ░█░█░█ ░█─ ░█░█░█ ░█─▄▄ 
░█▄▄█ ░█─░█ ░█──░█ ▄█▄ ░█──▀█ ░█▄▄█ 

░█──░█ ▀█▀ ░█▀▀█ 
─░█░█─ ░█─ ░█▄▄█ 
──▀▄▀─ ▄█▄ ░█─── "
sleep 1
echo ""
sleep 1
echo " Developer     :     RC Modz "
sleep 0.1
echo " Version       :     Stable NR "
sleep 0.1
echo " Tools         :     Brevent "
sleep 0.1
echo " Module Mode :     VIP 1.0 "
sleep 1
echo ""
echo " ************************************************************************ "
echo " CHECKING DEVICE INFORMATION "
sleep 1
echo ""
echo "CPU      : $(getprop ro.board.platform)"
echo "GPU      : $(getprop ro.hardware)"
echo "Android  : $(getprop ro.build.version.release)"
echo "Kernel   : $(uname -r)"
echo "Build    : $(getprop ro.build.display.id)"
echo "Root     : $(if [ $(id -u) -eq 0 ]; then echo 'Yes'; else echo 'No'; fi)"
echo "SELinux  : $(getenforce)"
sleep 3
echo ""
echo " ************************************************************************ "
echo " - Trimming up Partitions "
sleep 3
echo " - Deleting Cache and Trash "
sleep 5
echo " - Finalizing Props "
sleep 2
echo " - Module Flashed Successfully "
sleep 1
echo ""
echo " - RC Modz "

#!/system/bin/sh

# Touch & Display Animation Tweaks
(
settings put global window_animation_scale 0.25
settings put global transition_animation_scale 0.25
settings put global animator_duration_scale 0.25
settings put secure display_density_forced 520
settings put system tap_duration 20
settings put system view.scroll_friction 3
settings put secure pointer_speed 10
input gamepad swipe 200 500 600 500 30
input touchpad swipe 200 500 300 500 70
input touchscreen swipe 100 100 500 500 150
input swipe 500 1000 900 1000 30
input gamepad tap 250 450
input touchpad tap 350 650
input touchscreen tap 130 180
input tap 750 1150
) > /dev/null 2>&1

# Touch Sampling & Response Boost
(
settings put system devices_virtual_input_input1_polling_rate 240
settings put global touch_sampling_rate 240
settings put global input.sampling_rate 1000
settings put system persist.sys.touch.sampling_boost 1
settings put global input.delay 0
settings put global input.resampling 1
settings put global input.gesture_prediction 0
settings put global input.touch_boost 1
settings put global min.touch.major 0
settings put global min.touch.minor 0
settings put system touch.boost true
settings put system touch.responsive 1
) > /dev/null 2>&1

# System UI & Latency Optimizations
(
settings put global touch.pressure.scale 0.1
settings put global touch.size.scale 0.1
settings put global settings_enable_monitor_phantom_procs false
settings put system pointer_speed 5
settings put global surface_flinger.set_idle_timer_ms 0
settings put global surface_flinger.set_touch_timer_ms 0
settings put global surface_flinger.set_display_power_timer_ms 0
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.disable_backpressure 1
setprop debug.sf.multithreaded_present true
settings put global surface_flinger.use_context_priority 1
) > /dev/null 2>&1

# Game Mode Touch Optimization
(
settings put system touch_sampling_rate 120
settings put system touch_size_calibration geometric
settings put system touch_stats {"min":1,"max":1}
settings put system touchX_debuggable 1
settings put system touch_boost_threshold 5
settings put system touch_feature_gamemode_enable 1
settings put system touch_input_sensitivity 1
settings put system touch_rate_control 0
settings put system touch_response_rate 1
settings put system touch_sampling_rate_override 1
settings put system touch_sensitivity 1_2
settings put system touch_slop 8
settings put system touch_switch_set_touchscreen 14005
settings put system touch_tap_sensitivity 1
settings put system touchpanel_game_switch_enable 1
) > /dev/null 2>&1

# SurfaceFlinger & Rendering Tweaks
(
settings put global surface_flinger.start_graphics_allocator_service true
settings put global surface_flinger.running_without_sync_framework true
setprop debug.sf.luma_sampling 0
setprop debug.sf.disable_client_composition_cache 1
setprop debug.sf.disable_backpressure 1
setprop debug.sf.enable_gl_backpressure 0
setprop debug.sf.enable_layer_caching 0
setprop debug.sf.enable_gl_backpressure false
setprop debug.sf.enable_hwc_vds 0
setprop debug.sf.hw 0
setprop debug.sf.predict_hwc_composition_strategy 0
setprop debug.sf.use_phase_offsets_as_durations 1
) > /dev/null 2>&1

# Advanced Touch Tuning & System Performance
(
setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.late.sf.duration 10500000
setprop debug.sf.late.app.duration 16600000
setprop debug.sf.treat_170m_as_sRGB 1
setprop debug.sf.earlyGl.app.duration 16600000
setprop debug.sf.frame_rate_multiple_threshold 120
setprop debug.boot.fps 20
setprop debug.performance.tuning 1
settings put global windowsmgr.support_low_latency_touch true
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.disable_vsync true
settings put system haptic_feedback_intensity 50
settings put global tactile_feedback_enabled 1
settings put global touch.onscreen_present true
settings put global touch_vsync_offset_ns 0
settings put global touch_phase_offset_ns 0
settings put global touchpanel_boost 1
settings put global touch_event_filtering_level 0
settings put global touch_response_boost_level 3
settings put global touch_tracking_config optimized
settings put system multitouch_data_resolution 240
settings put system multitouch.min_distance 0
settings put system multitouch_tap_interval 20
settings put system multitouch_hold_interval 50
settings put system multitouch_slop 4
settings put system multitouch_max_events_per_sec 1000
settings put global tap_interval 10
settings put global tap_timeout 50
settings put system long_press_timeout 300
settings put global double_tap_timeout 200
settings put system double_tap_to_wake 1
settings put global quick_tap_enabled 1
settings put global dev_settings 1
settings put global development_settings_enabled 1
settings put system show_touches 0
settings put system pointer_location 0
settings put global show_cpu_usage 0
settings put global show_hw_layers_updates 0
settings put global show_layout_bounds 0
settings put system disable_show_touch_visuals 1
settings put global pointer_speed 7
settings put secure pointer_speed 7
settings put global user_rotation 0
settings put system accelerometer_rotation 0
settings put system user_rotation 0
settings put global auto_rotate 0
settings put system auto_rotate 0
settings put system screen_off_timeout 300000
settings put global stay_on_while_plugged_in 3
settings put global power_saving_mode 0
settings put global device_idle_constants inactive_to=60000,sensing_to=60000,locating_to=60000
settings put global sleep_timeout 300000
settings put global battery_saver_constants vibration_disabled=false
settings put global low_power 0
settings put global display_power_saving 0
settings put global animation_cache_enabled false
) > /dev/null 2>&1

# New Tweak FPS Lock Settings (144Hz)
settings put system user_refresh_rate 144
settings put system fps_limit 144
settings put system max_refresh_rate_for_ui 144
settings put system hwui_refresh_rate 144
settings put system display_refresh_rate 144
settings put system max_refresh_rate_for_gaming 144

# FPS Margin Settings
settings put system fstb_target_fps_margin_high_fps 20
settings put system fstb_target_fps_margin_low_fps 20
settings put system gcc_fps_margin 10

# Remove Low Battery Refresh Rate Support
settings put system tran_low_battery_60hz_refresh_rate.support 0

# Lock Refresh Rate to 144 Hz
settings put system vendor.display.refresh_rate 144
settings put system user_refresh_rate 1
settings put system sf.refresh_rate 144
settings put secure user_refresh_rate 1
settings put secure miui_refresh_rate 144

# Frame Rate Settings
settings put system min_frame_rate 144
settings put system max_frame_rate 144

# Transition and Refresh Mode Settings
settings put system tran_refresh_mode 144
settings put system last_tran_refresh_mode_in_refresh_setting 144
settings put system tran_need_recovery_refresh_mode 144

# Global FPS Settings
settings put global min_fps 144
settings put global max_fps 144

# Additional Display Refresh Settings
settings put system display_min_refresh_rate 144
settings put system min_refresh_rate 144
settings put system max_refresh_rate 144
settings put system peak_refresh_rate 144
settings put secure refresh_rate_mode 144
settings put system thermal_limit_refresh_rate 144

# FPS Limit Settings
settings put system NV_FPSLIMIT 144
settings put system fps.limit.is.now locked
settings put system thermal_limit_refresh_rate 144

# Run the settings in the background
) > /dev/null 2>&1 &

# Scheduling and CPU related settings
settings put system sched_migration_cost_ns 500000            # Set the migration cost for tasks to 500,000 ns
settings put system sched_latency_ns 1000000                  # Set the scheduler latency to 1,000,000 ns
settings put system sched_min_granularity_ns 200000          # Set the minimum granularity for scheduling to 200,000 ns
settings put system sched_wakeup_granularity_ns 750000       # Set wakeup granularity to 750,000 ns
settings put system sched_nr_migrate 2                       # Set the number of task migration attempts to 2
settings put system perf_cpu_time_max_percent 5              # Set maximum CPU time percentage to 5%
settings put system sched_autogroup_enabled 1                # Enable scheduling autogrouping
settings put system sched_child_runs_first 1                 # Child tasks will run first in scheduling
settings put system sched_cstate_aware 1                     # Enable CPU core C-state awareness
settings put system sched_energy_aware 0                     # Disable energy awareness for the scheduler
settings put system sched_rr_timeslice_ms 10                 # Set round-robin timeslice to 10 ms
settings put system sched_rt_period_us 1000000               # Set real-time period to 1,000,000 µs (1 second)
settings put system sched_rt_runtime_us 950000               # Set real-time runtime to 950,000 µs
settings put system sched_sync_hint_enable 1                 # Enable synchronization hints for the scheduler
settings put system sched_tunable_scaling 1                  # Enable tunable scaling for scheduler

# Performance tuning settings
settings put global game_auto_temperature_control 0         # Disable automatic temperature control for gaming
settings put global cached_apps_freezer enabled             # Enable cached apps freezer for memory efficiency
setprop debug.restricted_device_performance 0.0            # Set performance tuning to default
settings put system cpu_boost_dynamic_stune_boost 20        # Set dynamic CPU boost with a stune value of 20
settings put system cpu_boost_dynamic_stune_boost_ms 500    # Set dynamic stune boost duration to 500 ms
settings put system cpu_boost_input_boost_ms 88             # Set input boost duration to 88 ms
settings put system cpu_boost_powerkey_input_boost_ms 400   # Set power key input boost duration to 400 ms
settings put system cpu_boost_input_boost_enabled 1         # Enable input boost
settings put system cpu_boost_sched_boost_on_powerkey_input 1  # Boost on powerkey input
settings put system cpu_boost_sched_boost_on_input 0        # Disable boost on any other input

# Mali and CPU performance tuning
settings put system mali_idler_parameters_mali_idler_active 0   # Disable Mali GPU idler
settings put system lazyplug_parameters_nr_possible_cores 8       # Set maximum number of cores to 8
setprop debug.performance.tuning 1                                 # Enable performance tuning
cmd power set-adaptive-power-saver-enabled false                   # Disable adaptive power saver
cmd power set-fixed-performance-mode-enabled true                  # Enable fixed performance mode
cmd thermalservice override-status 0                                # Disable thermal override

# Memory, graphics, and hardware tuning
settings put global dropbox:dumpsys:procstats 0                    # Disable process stats in Dropbox
settings put global dropbox:dumpsys:usagestats 0                   # Disable usage stats in Dropbox
settings put global surface_flinger.max_frame_buffer_acquired_buffers 3  # Set max acquired buffers for surface flinger to 3
settings put global surface_flinger.running_without_sync_framework false # Disable sync framework for surface flinger
setprop debug.cpurend.vsync false                                  # Disable CPU VSYNC debugging
setprop debug.hwui.app_memory_policy aggresive                     # Set aggressive memory policy for HWUI
setprop debug.hwui.optimized_texture_upload true                    # Enable texture upload optimization for HWUI

# GPU and CPU frequency scaling
settings put system kernel_fpsgo_common_fpsgo_enable 1            # Enable FPSGO for better gaming performance
settings put system cpu_boost_parameters_boost 0                  # Disable CPU boost parameters
setprop debug.thermal_parameters_enable_throttle 0                # Disable thermal throttling
setprop debug.thermal_parameters_thermal_enable 0                 # Disable thermal control

# Display settings
settings put system peak_refresh_rate 120                         # Set peak refresh rate to 120Hz
settings put system minimum_refresh_rate 120                      # Set minimum refresh rate to 120Hz

# Performance tuning for system responsiveness
settings put system sem_enhanced_cpu_responsiveness 1             # Enable enhanced CPU responsiveness
settings put system sem_performance_mode 4                        # Set performance mode to 4 (high performance)
settings put system sem_turbo_mode 1                              # Enable turbo mode for CPU

# Game-specific settings
settings put system fod_animation_type 4                          # Set FOD (Fingerprint On Display) animation type to 4
settings put system force_vulkan_acceleration true                 # Force Vulkan acceleration for better graphics performance
settings put system fps_limit 120                                 # Set FPS limit to 120
settings put system game_accelerate_hw 1                          # Enable hardware acceleration for gaming
settings put system game_lag_fix smoothly                         # Enable smooth lag fix for games
settings put system game_access_com_dts_freefireth enable        # Enable game access for FreeFireTH
settings put system game_character_movement 243                   # Set game character movement mode
settings put system game_no_interruption 0                        # Disable game interruption
settings put system gaming_processor_priority true                # Enable gaming processor priority

# CPU frequency and core speed settings
settings put global cpu.core_speeds.cluster0 2800000              # Set CPU core speed for cluster 0 to 2.8 GHz
settings put global cpu.core_speeds.cluster1 3200000              # Set CPU core speed for cluster 1 to 3.2 GHz

# Display, graphics, and UI settings
settings put system display_use_color_profiles 1                  # Enable color profiles for display
settings put system purgeable_assets 1                            # Enable purgeable assets for memory efficiency
settings put system scrollingcache 3                              # Set scrolling cache to 3
settings put system shutdown_mode hibernate                       # Set shutdown mode to hibernate
settings put system sys_ui_hw 1                                    # Enable hardware UI support
settings put system sys_use_dithering 1                            # Enable dithering for smoother UI transitions
settings put system config_hw_fast_dormancy 1                     # Enable hardware fast dormancy
settings put system config_hw_quickpoweron true                    # Enable quick power on for hardware
settings put system config_nocheckin 1                            # Disable check-in configuration
settings put system ril_disable_power_collapse 1                  # Disable power collapse for RIL
settings put system ril_hsxpa 2                                   # Set RIL HSXPA to 2 (high speed)

# System and network-related settings
settings put system fw_bg_apps_limit 32                           # Set background apps limit to 32
settings put system vendor_qti_sys_fw_b_bg_apps_limit 20          # Set QTI background apps limit to 20
settings put system vendor_qti_wifi_ssr_bw 2                      # Set QTI Wi-Fi SSR bandwidth to 2
settings put system wifi_supplicant_scan_interval 180             # Set Wi-Fi supplicant scan interval to 180 seconds

# CPU frequency tuning and stune settings
settings put system stune_background_schedtune.boost 0            # Disable background schedtune boost
settings put system stune_background_schedtune.colocate 0         # Disable background schedtune colocation
settings put system stune_background_schedtune.prefer_idle 0      # Disable background schedtune idle preference
settings put system stune_background_schedtune.sched_boost 0      # Disable background schedtune boost
settings put system stune_background_schedtune.sched_boost_no_override 1  # Allow no override for background boost
settings put system stune_background_schedtune.prefer_perf 0      # Disable background schedtune performance preference
settings put system stune_background_schedtune.util_est_en 0     # Disable background schedtune utilization estimation
settings put system stune_background_schedtune.ontime_en 0       # Disable background schedtune on-time enable

settings put system stune_foreground_schedtune.boost 0            # Disable foreground schedtune boost
settings put system stune_foreground_schedtune.colocate 0         # Disable foreground schedtune colocation
settings put system stune_foreground_schedtune.prefer_idle 1      # Enable foreground schedtune idle preference
settings put system stune_foreground_schedtune.sched_boost 0      # Disable foreground schedtune boost
settings put system stune_foreground_schedtune.sched_boost_no_override 1  # Allow no override for foreground boost
settings put system stune_foreground_schedtune.prefer_perf 0      # Disable foreground schedtune performance preference

# CPU core set configurations
settings put system cpu_set_effective_cpus 7                     # Set effective CPUs for the system
settings put system cpu_set_background_cpus 1                    # Set background CPUs
settings put system cpu_set_background_effective_cpus 1          # Set effective background CPUs
settings put system cpu_set_system-background_cpus 2             # Set system background CPUs
settings put system cpu_set_system-background_effective_cpus 2   # Set effective system background CPUs
settings put system cpu_set_foreground_cpus 6                    # Set foreground CPUs
settings put system cpu_set_foreground_effective_cpus 6          # Set effective foreground CPUs
settings put system cpu_set_top-app_cpus 7                       # Set top app CPUs
settings put system cpu_set_top-app_effective_cpus 7             # Set effective top app CPUs
settings put system cpu_set_restricted_cpus 3                    # Set restricted CPUs
settings put system cpu_set_restricted_effective_cpus 3          # Set effective restricted CPUs
#############################################
# High Touch Polling & Sampling Rate Tweaks
#############################################
(
settings put system devices_virtual_input_input1_polling_rate 240
settings put global touch_sampling_rate 240
settings put global input.sampling_rate 1000
settings put system persist.sys.touch.sampling_boost 1
settings put global input.delay 0
settings put global input.resampling 1
settings put global input.gesture_prediction 0
settings put global input.touch_boost 1
settings put global min.touch.major 0
settings put global min.touch.minor 0
settings put system touch.boost true
settings put system touch.responsive 1
) > /dev/null 2>&1

#############################################
# Visual & SurfaceFlinger Optimizations
#############################################
(
settings put global touch.pressure.scale 0.1
settings put global touch.size.scale 0.1
settings put global transition_animation_scale 0
settings put global window_animation_scale 0
settings put global settings_enable_monitor_phantom_procs false
settings put system pointer_speed 5
settings put global surface_flinger.set_idle_timer_ms 0
settings put global surface_flinger.set_touch_timer_ms 0
settings put global surface_flinger.set_display_power_timer_ms 0
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.disable_backpressure 1
setprop debug.sf.multithreaded_present true
settings put global surface_flinger.use_context_priority 1
) > /dev/null 2>&1

#############################################
# Touch Sensitivity and Input Boost
#############################################
(
settings put system touch_sampling_rate 120
settings put system touch_size_calibration geometric
settings put system touch_stats '{"min":1,"max":1}'
settings put system touchX_debuggable 1
settings put system touch_boost_threshold 5
settings put system touch_feature_gamemode_enable 1
settings put system touch_input_sensitivity 1
settings put system touch_rate_control 0
settings put system touch_response_rate 1
settings put system touch_sampling_rate_override 1
settings put system touch_sensitivity 1_2
settings put system touch_slop 8
settings put system touch_switch_set_touchscreen 14005
settings put system touch_tap_sensitivity 1
settings put system touchpanel_game_switch_enable 1
) > /dev/null 2>&1

#############################################
# Deep SurfaceFlinger & Frame Control
#############################################
(
settings put global surface_flinger.start_graphics_allocator_service true
settings put global surface_flinger.running_without_sync_framework true
setprop debug.sf.luma_sampling 0
setprop debug.sf.disable_client_composition_cache 1
setprop debug.sf.disable_backpressure 1
setprop debug.sf.enable_gl_backpressure 0
setprop debug.sf.enable_layer_caching 0
setprop debug.sf.enable_gl_backpressure false
setprop debug.sf.enable_hwc_vds 0
setprop debug.sf.hw 0
setprop debug.sf.predict_hwc_composition_strategy 0
setprop debug.sf.use_phase_offsets_as_durations 1
) > /dev/null 2>&1

#############################################
# Touch Duration and Prediction Controls
#############################################
(
setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.late.sf.duration 10500000
setprop debug.sf.late.app.duration 16600000
setprop debug.sf.treat_170m_as_sRGB 1
setprop debug.sf.earlyGl.app.duration 16600000
setprop debug.sf.frame_rate_multiple_threshold 120
setprop debug.boot.fps 20
) > /dev/null 2>&1

#############################################
# System Performance & Input Enhancements
#############################################
(
# Enable performance tuning
setprop debug.performance.tuning 1
settings put system view.scroll_friction 0
settings put global windowsmgr.support_low_latency_touch true
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.disable_vsync true

# Haptic and feedback tweaks
settings put system haptic_feedback_intensity 50
settings put global tactile_feedback_enabled 1

# Fine-tune multitouch, gestures, and tap behavior
setprop debug.MultitouchSettleInterval 0.01ms
setprop debyg.MultitouchMinDistance 0.01px
setprop debug.TapInterval 0.1ms

# Background service limits and memory optimizations
settings put global fw.bservice_enable true
settings put global fw.bg_apps_limit 4
settings put global fw.bservice_limit 4
settings put global fw.bservice_age 10000

# Touch pressure and size behavior
setprop debug.touch.pressure.scale 0.001
setprop debug.touch_move_opt 1
setprop debug.touch_vsync_opt 1
setprop debug.touch.size.bias 0

# System event limits and rendering tweaks
settings put global windowsmgr.max_events_per_sec 180
settings put global min_pointer_dur 8
settings put global product.multi_touch_enabled true
settings put global securestorage.knox false

# Disable unneeded services and security checks
setprop debug.security.mdpp none
setprop debug.security.mdpp.result none
settings put system af.resampler.quality 255
settings put system scrollingcache 3
setprop debug.service.lgospd.enable 0
setprop debug.service.pcsync.enable 0

# Device and UI performance tweaks
setprop debug.touch.deviceTypetouchScreen
cmd device_config put input default_key_press_repeat_rate 33
cmd device_config put input filtered_accel_event_rate_hz 240
cmd device_config put input touch_screen_sample_interval_ms 8
cmd device_config put systemui cg_frame_interval_millis 4
cmd device_config put systemui low_power_refresh_rate_millis 0
cmd device_config put systemui cg_max_frame_skip 8

# Advanced touch calibration
settings put system touch_switch_set_touchscreen 14005
settings put system touchpanel_game_switch_enable 1
settings put system touchpanel_oppo_tp_direction 1
settings put system touchpanel_oppo_tp_limit_enable 0
settings put system touchpanel_oplus_tp_limit_enable 0
settings put system use_dithering false
settings put system qti.inputopts.enable true
settings put system qti.inputopts.movetouchslop 0.1
settings put global DragMinSwitchSpeed 99999.0px/s
settings put global SwipeMaxWidthRatio 1

# UI responsiveness and animation bypassing
settings put system r.setframepace 120
settings put system touchfeature.gamemode.enable true
settings put system PressureForID 0.01
settings put system APP_SWITCH_DELAY_TIME false
settings put system AbsoluteXForID SpeedForID
settings put system AccelerationX true
settings put system AccelerationY true
settings put system DoubleTouch OEM
settings put system PowerbuttonTapping 0
settings put system touch.assistant.enabled 0
settings put system type.touch_speed true
settings put system accuracy.control 100
settings put system view_scroll_friction 10
settings put global KeyRepeatDelay 0
settings put global KeyRepeatTimeout 0
settings put global LOSS_OF_FOCUS_BY_MOUSE_MOVEMENT DISABLED
settings put global MOUSEX_AIM_LEVEL 95%
) > /dev/null 2>&1