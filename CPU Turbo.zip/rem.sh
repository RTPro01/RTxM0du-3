setprop debug.rs.default-CPU-driver 0
setprop debug.rs.rsov 0
setprop debug.rs.max-threads ""
setprop debug.rs.script ""
setprop debug.rs.profile 0
setprop debug.rs.shader 0
setprop debug.rs.shader.attributes 0
setprop debug.rs.shader.uniforms 0
setprop debug.rs.visual 0
setprop debug.rs.reduce 0
setprop debug.rs.reduce-split-accum 0
setprop debug.rs.reduce-accum 0
setprop debug.rs.forcerecompile 0
setprop debug.rs.debug 0
setprop debug.rs.precision ""
setprop debug.bcc.nocache 0
setprop debug.rs.qcom.verbose 0
setprop debug.rs.qcom.dump_setup 0
setprop debug.rs.qcom.dump_bitcode 0
setprop debug.rs.qcom.noprofile 0
setprop debug.rs.qcom.nointrinsicblur 0
setprop debug.rs.qcom.nointrinsicblas 0
setprop debug.rs.qcom.blurimpl ""
setprop debug.rs.qcom.notextures 0
setprop debug.rs.qcom.noobjcache 0
setprop debug.rs.qcom.noperfhint 0
setprop debug.rs.qcom.force_finish 0
setprop debug.rs.qcom.disable_expand 0
setprop debug.rs.qcom.use_fast_math 0

echo " - MODULE EXECUTED SUCCESSFULLY! "

echo " Reboot once "