echo " 
█▀▀ █▀█ █░█   ▀█▀ █░█ █▀█ █▄▄ █▀█
█▄▄ █▀▀ █▄█   ░█░ █▄█ █▀▄ █▄█ █▄█ "
sleep 1
echo ""
echo " - Developer: K3NSHiiiN "
sleep 0.1
echo " - Version: 1.0 "
sleep 0.1
echo " - Status: Shell Script "
sleep 1
echo ""
echo " --------------------------------------------------------- "
echo ""
echo " CHECKING DEVICE INFORMATION: "
echo ""
echo " - CPU      : $(getprop ro.board.platform)"
echo " - GPU      : $(getprop ro.hardware)"
echo " - Android  : $(getprop ro.build.version.release)"
echo " - Kernel   : $(uname -r)"
echo " - Build    : $(getprop ro.build.display.id)"
echo " - Model    : $(getprop ro.product.model)"
echo " - Build Date : $(getprop ro.build.date)"
echo " - Script Used At : $(date '+%Y-%m-%d %H:%M:%S')"
sleep 1
echo ""
echo " --------------------------------------------------------- "
sleep 1
echo ""
echo " - Flashing Module "
sleep 3
echo " - Executing Props "
sleep 1
echo " - Placing Props "
sleep 2
echo " - Finalizing Module, Please Wait "
sleep 5
echo ""
echo " - MODULE EXECUTED SUCCESSFULLY! "

# Props I Used

setprop debug.rs.default-CPU-driver 1
setprop debug.rs.rsov 1
setprop debug.rs.max-threads 8
setprop debug.rs.script 0
setprop debug.rs.profile 0
setprop debug.rs.shader 0
setprop debug.rs.shader.attributes 0
setprop debug.rs.shader.uniforms 0
setprop debug.rs.visual 0
setprop debug.rs.reduce 1
setprop debug.rs.reduce-split-accum 1
setprop debug.rs.reduce-accum 1
setprop debug.rs.forcerecompile 0
setprop debug.rs.debug 0
setprop debug.rs.precision rs_fp_imprecise
setprop debug.bcc.nocache 1
setprop debug.rs.qcom.verbose 0
setprop debug.rs.qcom.dump_setup 0
setprop debug.rs.qcom.dump_bitcode 0
setprop debug.rs.qcom.noprofile 1
setprop debug.rs.qcom.nointrinsicblur 1
setprop debug.rs.qcom.nointrinsicblas 1
setprop debug.rs.qcom.blurimpl gpu
setprop debug.rs.qcom.notextures 1
setprop debug.rs.qcom.noobjcache 1
setprop debug.rs.qcom.noperfhint 1
setprop debug.rs.qcom.force_finish 1
setprop debug.rs.qcom.disable_expand 1
setprop debug.rs.qcom.use_fast_math 1