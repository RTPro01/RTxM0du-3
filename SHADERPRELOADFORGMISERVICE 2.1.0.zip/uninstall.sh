#!/system/bin/sh
#

# LowTex Shader Preload SERVICE v2.1.0
# RESET / UNINSTALL SCRIPT
# Developer: @yih855

echo() {
  echo "[LowTex Shader Reset] $1"
}

echo "Restoring system defaults..."





settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1





setprop debug.hwui.renderer ""
setprop debug.hwui.force_gpu_rendering false
setprop debug.hwui.disable_vsync false
setprop debug.hwui.render_thread true
setprop debug.hwui.use_buffer_age true

setprop debug.hwui.texture_cache_size ""
setprop debug.hwui.texture_cache_flush 0
setprop debug.hwui.filter_quality high
setprop debug.hwui.texture_quality high
setprop debug.hwui.disable_textures false

setprop debug.hwui.drop_shadow_cache false
setprop debug.hwui.disable_layers_cache false
setprop debug.hwui.disable_profile_rendering false
setprop debug.hwui.render_dirty_regions true
setprop debug.hwui.disable_scissor false
setprop debug.hwui.overdraw 1





setprop debug.egl.max_texture_size ""
setprop debug.egl.disable_texture_compression 0
setprop debug.egl.swapinterval 1
setprop debug.egl.sync 1

setprop debug.gr.swapinterval 1





setprop debug.sf.hw 1
setprop debug.sf.disable_backpressure 0
setprop debug.sf.enable_gl_backpressure 0
setprop debug.sf.disable_client_composition 0
setprop debug.sf.use_client_composition true





setprop persist.sys.gpu.profiler true

echo "Shader Preload settings reset complete."
echo "System will use default renderer and GPU behavior."