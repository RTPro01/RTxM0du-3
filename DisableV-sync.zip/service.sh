#!/system/bin/sh

NAME="Disable V-sync"
VERSION="1.0.0 | DisableVsync"
ANDROIDVERSION=$(getprop ro.build.version.release)
DEVICE=$(getprop ro.product.device)
MANUFACTURER=$(getprop ro.product.manufacturer)
DATE=$(date)

sleep 2
echo "
░█▀▀▄ ▀█▀ ░█▀▀▀█ ─█▀▀█ ░█▀▀█ ░█─── ░█▀▀▀ 
░█─░█ ░█─ ─▀▀▀▄▄ ░█▄▄█ ░█▀▀▄ ░█─── ░█▀▀▀ 
░█▄▄▀ ▄█▄ ░█▄▄▄█ ░█─░█ ░█▄▄█ ░█▄▄█ ░█▄▄▄"
echo ""
echo "
░█──░█ ── ░█▀▀▀█ ░█──░█ ░█▄─░█ ░█▀▀█ 
─░█░█─ ▀▀ ─▀▀▀▄▄ ░█▄▄▄█ ░█░█░█ ░█─── 
──▀▄▀─ ── ░█▄▄▄█ ──░█── ░█──▀█ ░█▄▄█"
echo ""
sleep 2

echo "==============================="
echo "   $NAME"
echo "   Version : $VERSION"
echo "   Android : ${ANDROIDVERSION:-Unknown}"
echo "   Device  : ${DEVICE:-Unknown}"
echo "   Maker   : ${MANUFACTURER:-Unknown}"
echo "   Date    : $DATE"
echo "==============================="

setprop debug.gr.swapinterval 0
setprop debug.sf.swapinterval 0
setprop debug.egl.swapinterval 0
setprop debug.gl.swapinterval 0
setprop debug.hwui.disable_vsync true
setprop debug.hwc.force_gpu_vsync 0
setprop debug.sf.no_hw_vsync 1
setprop debug.hwc.fakevsync 0
setprop debug.logvsync 0
setprop debug.choreographer.vsync false
setprop debug.cpurend.vsync false

echo "[$NAME] Optimization⚡."
cmd notification post -S bigtext -t 'Disable V-sync' '⚡' " Tweaks Running"