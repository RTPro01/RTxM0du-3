#!/system/bin/sh


#  LOWTEX V6.4/6.5 reset


LOGFILE="/data/local/tmp/free_lowtex_reset.log"

log() {
    echo "[FREE-LOWTEX RESET] $1"
    echo "[FREE-LOWTEX RESET] $1" >> $LOGFILE
}

run_cmd() {
    DESC="$1"
    CMD="$2"
    log "Running: $DESC"
    sh -c "$CMD" >> $LOGFILE 2>&1
    if [ $? -eq 0 ]; then
        log "SUCCESS: $DESC"
    else
        log "FAILED: $DESC"
    fi
}

log "Starting  reset..."




run_cmd "Enable Adaptive Battery" "cmd power set-adaptive-power-saver-enabled true"
run_cmd "Disable Fixed Performance Mode" "cmd power set-fixed-performance-mode-enabled false"
run_cmd "Reset Power Mode" "cmd power set-mode 1"
run_cmd "Reset Thermal Overrides" "cmd thermalservice override-status -1"
run_cmd "Reset System Usage Boost" "cmd activity boost-system-usage false"



run_cmd "Reset HWUI & EGL" "
setprop debug.egl.hw 0
setprop debug.sf.hw 0
setprop debug.gr.swapinterval 1
setprop debug.hwui.use_hint_manager false
setprop debug.sf.gpu_freq_index 0
setprop debug.hwui.render_thread false
setprop debug.hwui.texture_cache_size 0
setprop debug.hwui.layer_cache_size 0
setprop debug.hwui.r_buffer_cache_size 0
setprop debug.hwui.vsync false
setprop debug.egl.force_msaa false
setprop debug.egl.swapinterval 1
setprop debug.egl.trace 0
setprop debug.sf.disable_backpressure 0
setprop debug.hwui.overdraw_check false
setprop debug.hwui.profile_rendering false
setprop debug.hwui.overdraw_composition false
settings put global debug.hwui.renderer null
settings put system persist.sys.hwui.renderer null
settings put global activity_manager_constants max_cached_processes=8
settings put system background_power_saving_enable 1
settings put global low_power 0
setprop debug.hwui.threaded_rendering false
setprop debug.hwui.texture_upload_thread false
"




run_cmd "Reset Vulkan & OpenGL" "
setprop debug.vulkan.precompile_shaders 0
setprop debug.vulkan.async_compute 0
setprop debug.vulkan.pipeline_cache 0
setprop debug.vulkan.multi_thread 0
setprop debug.vulkan.frame_pacing 0
setprop debug.egl.debug_layers 0
setprop debug.egl.force_msaa 0
setprop debug.egl.hw 0
"




run_cmd "Reset SurfaceFlinger" "
setprop debug.sf.disable_hw_cursors 0
setprop debug.sf.hw 0
setprop debug.sf.vsync_event_phase_offset 0
setprop debug.sf.render_latency 0
setprop debug.sf.defer_surface_update 0
setprop debug.sf.enable_triple_buffering 0
setprop debug.sf.high_res_fences 0
setprop debug.sf.force_hwc_gpu 0
setprop debug.sf.render_threaded_composition 0
"


# RESET MO HAHA
run_cmd "Reset Memory & Dalvik" "
setprop dalvik.vm.extra-opts ''
setprop debug.hwui.high_priority_threads false
setprop debug.hwui.render_queue_size 0
setprop debug.hwui.preload_fonts false
"


#WHAHAHAH WLA KANA MAISIP? 

GAMES=$(cmd package list packages --user 0 | cut -f2 -d:)

for app in $GAMES; do
    [ -z "$app" ] && continue  

    if dumpsys game | grep -q "$app"; then  
        log "Resetting downscale & FPS for: $app"  
        cmd game reset "$app" 2>/dev/null
    fi
done


#PAKYU KA HAHA

run_cmd "Disable DND" "cmd notification set_dnd off"
run_cmd "Allow Sleep" "cmd power stayon false"

log "LowTex reset completed successfully."