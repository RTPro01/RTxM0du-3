#!/system/bin/sh


# FREE LOWTEX V6.4 (FREE VERSION) 
#NEW TEMPLATE DONT COPY 

LOGFILE="/data/local/tmp/freee_lowtex_v6.4-6.5.log"
TEMP_LIMIT=42
DOWN_SCALE=0.50369273826
FPS_OVERRIDE=120

ANDROID_VER=$(getprop ro.build.version.sdk)

log() {
    echo "[FREE-LOWTEX V6.4-6.5] $1"
    echo "[FREE-LOWTEX V6.4-6.5] $1" >> "$LOGFILE"
}

run_cmd() {
    DESC="$1"
    CMD="$2"
    log "Running: $DESC"
    sh -c "$CMD" >> "$LOGFILE" 2>&1
    if [ $? -eq 0 ]; then
        log "SUCCESS: $DESC"
    else
        log "FAILED: $DESC"
    fi
}

get_battery_temp() {
    cat /sys/class/power_supply/battery/temp 2>/dev/null
}


# WAIT FOR YOU KUMAG HAGA

log "Waiting for boot..."
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done
sleep 5
log "Boot complete."


# POWER OF POGI HAHA 

run_cmd "Disable Adaptive Battery" "cmd power set-adaptive-power-saver-enabled false"
run_cmd "Enable Fixed Performance Mode" "cmd power set-fixed-performance-mode-enabled true"
run_cmd "Force Active Power Mode" "cmd power set-mode 0"
run_cmd "Override Thermal Throttling" "cmd thermalservice override-status 0"
run_cmd "Force Idle Maintenance" "cmd activity idle-maintenance"


#WAG MUNA EH EDIT KUMAG HAHA

run_cmd "HWUI + EGL" "
setprop debug.egl.hw 1
setprop debug.sf.hw 1
setprop debug.gr.swapinterval 0
setprop debug.hwui.use_hint_manager true
setprop debug.sf.gpu_freq_index 5
setprop debug.hwui.render_thread true
setprop debug.stagefright.ccodec 4
setprop debug.hwui.texture_cache_size 256
setprop debug.hwui.layer_cache_size 128
setprop debug.hwui.r_buffer_cache_size 16
setprop debug.hwui.vsync true
setprop debug.egl.swapinterval 1
setprop debug.egl.trace 0
setprop debug.sf.disable_backpressure 1
setprop debug.hwui.overdraw_check false
setprop debug.hwui.profile_rendering true
setprop debug.hwui.overdraw_composition false
settings put global debug.hwui.renderer opengl
settings put system persist.sys.hwui.renderer opengl
settings put global activity_manager_constants 32
settings put system background_power_saving_enable 0
settings put global low_power 0
settings put system force_high_perf_gpu 1
"


#HALA SI IDOL OH HAHA

run_cmd "Vulkan Boost" "
setprop debug.vulkan.precompile_shaders 1
setprop debug.vulkan.async_compute 1
setprop debug.vulkan.pipeline_cache 1
setprop debug.vulkan.multi_thread 1
setprop debug.vulkan.frame_pacing 1
setprop debug.egl.hw 1
setprop debug.egl.swapinterval 1
setprop debug.egl.debug_layers 0
"




run_cmd "Memory Optimize" "
setprop dalvik.vm.extra-opts '-Xmx2048m -Xms1024m'
setprop debug.hwui.render_priority 1
setprop debug.sf.composition_thread_priority 1
setprop debug.sf.render_thread_priority 1
setprop debug.hwui.texture_upload_thread true
setprop debug.hwui.threaded_rendering true
setprop debug.hwui.preload_fonts true
"




run_cmd "SurfaceFlinger Optimize" "
setprop debug.sf.disable_hw_cursors 1
setprop debug.sf.hw 1
setprop debug.sf.vsync_event_phase_offset 0
setprop debug.sf.render_latency 0
setprop debug.sf.defer_surface_update 0
"




CURRENT_APP=$(dumpsys window | grep mCurrentFocus | awk '{print $3}' | cut -d/ -f1)

if [ -n "$CURRENT_APP" ] && pm list packages | grep -q "$CURRENT_APP"; then
    if dumpsys package "$CURRENT_APP" | grep -q "category=GAME"; then

        GAME="$CURRENT_APP"
        log "Game detected: $GAME"

        run_cmd "Game ACTIVE" \
        "cmd usage stats set-app-standby-bucket $GAME active"

        run_cmd "Doze Whitelist" \
        "cmd deviceidle whitelist +$GAME"

        run_cmd "Enable DND" \
        "cmd notification set_dnd on"

        run_cmd "Stay Awake" \
        "cmd power stayon true"

        TEMP_RAW=$(get_battery_temp)
        TEMP_C=$((TEMP_RAW / 10))

        log "Battery Temp: ${TEMP_C}C"

        if [ "$TEMP_C" -ge "$TEMP_LIMIT" ]; then
            run_cmd "Thermal Protection OFF Boost" \
            "cmd power set-fixed-performance-mode-enabled false"
        else
            run_cmd "Performance Mode ON" \
            "cmd power set-fixed-performance-mode-enabled true"
        fi
    fi
fi


#HI POGI ??? HAHA

GAMES=$(cmd package list packages --user 0 | cut -f2 -d:)

for app in $GAMES; do
    [ -z "$app" ] && continue

    if dumpsys game | grep -q "$app"; then
        log "Applying scale to $app"

        if [ "$ANDROID_VER" -ge 12 ]; then
            cmd game set --mode 2 \
            --downscale "$DOWN_SCALE" \
            --fps "$FPS_OVERRIDE" "$app"
        fi
    fi
done

log "FREE LOWTEX V6.4 /6.5 SUCCESS"