#!/system/bin/sh

# LowTexYíH Dynamic v3.1 - SkiaGL Performance Edition
# Full Reset / Uninstall Script
# Developer: LowTexYíH @yih855

echo() {
  echo "[LowTexYíH v3.1 | SkiaGL Reset] $1"
}

echo "Starting full module reset... Restoring all default settings..."






settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1
echo "Animations restored to default."






cmd display set-match-content-frame-rate-pref 0 2>/dev/null
cmd display set-user-disabled-hdr-types 0 2>/dev/null
echo "Display & HDR settings restored."






cmd activity memory-factor set 1 2>/dev/null
settings put global settings_enable_monitor_phantom_procs true
settings put global app_standby_enabled 1
settings put global fstrim_mandatory_interval 0
cmd deviceidle enable
echo "Memory & device idle settings restored."






[ -e /sys/module/msm_performance/parameters/touchboost ] && echo 0 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null
[ -e /sys/power/pnpmgr/touch_boost ] && echo 0 > /sys/power/pnpmgr/touch_boost 2>/dev/null
settings put secure long_press_timeout 500
settings put secure multi_press_timeout 300
echo "Touch boost disabled and defaults restored."






setprop debug.hwui.renderer gpu
setprop debug.hwui.render_thread false
setprop debug.hwui.use_hint_manager false
setprop debug.hwui.max_frame_lag 0
setprop debug.hwui.frame_deadline_ms 0
setprop debug.hwui.swap_with_damage false

setprop debug.sf.disable_backpressure 0
setprop debug.sf.enable_hwc_vds 0
setprop debug.hwui.target_cpu_time_percent 0
setprop debug.hwui.target_gpu_time_percent 0

echo "HWUI / SkiaGL renderer reset to default."




 
settings put global game_driver_all_apps 0


for pkg in $(cmd package list packages -3 | cut -f2 -d:); do
    device_config delete game_overlay "$pkg"
    cmd game reset "$pkg" 2>/dev/null
    echo "Reset game settings for: $pkg"
done


ANDROID_VER=$(getprop ro.build.version.release)
if [ "$ANDROID_VER" -ge 14 ]; then
    cmd device_config override game android.os.adpf_prefer_power_efficiency true 2>/dev/null
    cmd device_config override game android.os.adpf_hwui_gpu false 2>/dev/null
    echo "Android 11-15+ game flags restored to default."
fi





echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
echo "System caches cleared."


echo "Full LowTexYíH Dynamic v3.1 reset complete. All module tweaks removed. Device restored to default behavior."