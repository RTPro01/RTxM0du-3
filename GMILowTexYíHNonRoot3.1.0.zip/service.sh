#!/system/bin/sh

# LowTexYíH Dynamic v3.1 - SkiaGL Performance Edition
# Developer: LowTexYíH @yih855

echo() {
  echo "[LowTexYíH Dynamic v3.1 | SkiaGL] $1"
}


while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

echo "Boot completed. Starting AUTO-GAME optimization..."


FPS=$(settings get system peak_refresh_rate 2>/dev/null || \
      settings get system user_refresh_rate 2>/dev/null || echo 90)

echo "Detected max refresh rate: $FPS"


RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 1500000)
ANDROID_VER=$(getprop ro.build.version.release)

echo "RAM: $RAM_KB KB | CPU: $CPU_MAX_FREQ | Android: $ANDROID_VER"


if [ "$RAM_KB" -ge 8000000 ] && [ "$CPU_MAX_FREQ" -ge 2600000 ]; then
  DOWNSCALE=0.53
  CLASS="HIGH-END"
elif [ "$RAM_KB" -ge 6000000 ]; then
  DOWNSCALE=0.50
  CLASS="UPPER-MID"
elif [ "$RAM_KB" -ge 4000000 ]; then
  DOWNSCALE=0.47
  CLASS="MID"
else
  DOWNSCALE=0.45
  CLASS="LOW-END"
fi

echo "Device class: $CLASS | downscaleFactor=$DOWNSCALE"



settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0



cmd display set-match-content-frame-rate-pref 1 2>/dev/null
cmd display set-user-disabled-hdr-types 1 2 3 4 2>/dev/null



cmd activity memory-factor set 0 2>/dev/null
settings put global settings_enable_monitor_phantom_procs false
settings put global app_standby_enabled 0



settings put secure long_press_timeout 180
settings put secure multi_press_timeout 200

[ -e /sys/module/msm_performance/parameters/touchboost ] && echo 1 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null
[ -e /sys/power/pnpmgr/touch_boost ] && echo 1 > /sys/power/pnpmgr/touch_boost 2>/dev/null



cmd deviceidle disable


echo "Applying SkiaGL renderer tweaks..."


setprop debug.hwui.renderer skiagl
setprop debug.hwui.render_thread true
setprop debug.hwui.use_hint_manager true


setprop debug.hwui.max_frame_lag 1
setprop debug.hwui.frame_deadline_ms 8
setprop debug.hwui.swap_with_damage true


setprop debug.sf.disable_backpressure 1
setprop debug.sf.enable_hwc_vds 1



settings put global game_driver_all_apps 1


echo "Applying performance mode to installed games..."

for pkg in $(cmd package list packages -3 | cut -f2 -d:); do

  device_config put game_overlay "$pkg" \
  mode=2,downscaleFactor=$DOWNSCALE,fps=$FPS

  cmd game mode performance "$pkg"

  pid=$(pidof "$pkg")
  if [ -n "$pid" ]; then
    renice -n -1 -p "$pid" 2>/dev/null
  fi

  echo "Applied: $pkg | scale=$DOWNSCALE | fps=$FPS"
done


if [ "$ANDROID_VER" -ge 14 ]; then
  echo "Applying Android 14+ game flags..."
  cmd device_config override game android.os.adpf_prefer_power_efficiency false 2>/dev/null
fi



echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

echo "LowTexYíH Dynamic v3.1 SkiaGL applied successfully."