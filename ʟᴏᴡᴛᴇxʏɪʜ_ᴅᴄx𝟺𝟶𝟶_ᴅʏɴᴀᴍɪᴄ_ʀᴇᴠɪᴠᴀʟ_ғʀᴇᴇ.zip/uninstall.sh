#!/system/bin/sh
#https://t.me/+EAway-gwqOlmNGE9
#Developer @yih855 thanks for helping @Dcx400

LOG="/sdcard/lotexyih_dynamic_revival_reset.log"
ts() { date '+%Y-%m-%d %H:%M:%S'; }
log_info() { echo "[ $(ts) ] \033[1;34m[RESTORE]\033[0m $1" | tee -a "$LOG"; }


log_info "Waiting for device boot..."
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 5; done
sleep 10
log_info "Boot completed. Restoring original values..."

#lowtexcode@yih855 https://t.me/+EAway-gwqOlmNGE9
restore_dc() {
    ns="$1"; key="$2"; val="$3"
    if command -v cmd >/dev/null 2>&1; then
        cmd device_config put "$ns" "$key" "$val" 2>/dev/null
        log_info "Restored device_config [$ns] $key = $val"
    else
        log_info "cmd not found, skipping $key"
    fi
}

#lowtexcode@yih855 https://t.me/+EAway-gwqOlmNGE9
restore_dc game com.android.server.power.hint.adpf_session_tag false
restore_dc game android.os.adpf_measure_during_input_event_boost false
restore_dc game android.os.adpf_obtainview_boost false
restore_dc game.android.os.adpf_hwui_gpu false
log_info "ADPF restored âœ…"

#lowtexcode@yih855 https://t.me/+EAway-gwqOlmNGE9
restore_dc core_graphics android.view.flags.set_frame_rate_callback false
restore_dc core_graphics com.android.graphics.surfaceflinger.flags.use_known_refresh_rate_for_fps_consistency false
restore_dc core_graphics com.android.graphics.surfaceflinger.flags.frame_rate_category_mrr false

#lowtexcode@yih855 https://t.me/+EAway-gwqOlmNGE9
restore_dc toolkit android.view.flags.toolkit_set_frame_rate false
restore_dc toolkit android.view.flags.toolkit_metrics_for_frame_rate_decision false

#lowtexcode@yih855 https://t.me/+EAway-gwqOlmNGE9
restore_dc interaction_jank_monitor trace_threshold_frame_time_millis 0
restore_dc interaction_jank_monitor trace_threshold_missed_frames 0

#lowtexcode@yih855 https://t.me/+EAway-gwqOlmNGE9
restore_dc window_surfaces com.android.window.flags.explicit_refresh_rate_hints false
restore_dc window_surfaces com.android.window.flags.enable_buffer_transform_hint_from_display false

#lowtexcode@yih855 https://t.me/+EAway-gwqOlmNGE9
restore_dc display_manager com.android.server.display.feature.flags.ignore_app_preferred_refresh_rate_request true
restore_dc display_manager com.android.server.display.feature.flags.enable_user_preferred_mode_vote false
restore_dc display_manager com.android.server.display.feature.flags.enable_displays_refresh_rates_synchronization false
restore_dc display_manager com.android.server.display.feature.flags.enable_vsync_low_light_vote true
restore_dc display_manager com.android.server.display.feature.flags.enable_vsync_low_power_vote true
#lowtexcode@yih855 https://t.me/+EAway-gwqOlmNGE9
cmd game reset com.mobile.legends
cmd game reset com.miHoYo.GenshinImpact
cmd game reset com.garena.game.codm
cmd game reset com.roblox.client
cmd game reset com.tencent.ig
cmd game reset com.netease.newspike
cmd game reset com.dts.freefire
cmd game reset com.dts.freefiremax 
success "All game overlays removed"
log_info "Per-app FPS restored…"

#lowtexcode@yih855 https://t.me/+EAway-gwqOlmNGE9
settings put global app_standby_enabled 1
cmd activity memory-factor set 1
log_info "Memory & background behavior restored…"
#lowtexcode@yih855 https://t.me/+EAway-gwqOlmNGE9
log_info "settings restored to original values.."
echo "Done. Check $LOG for full details."