#!/system/bin/sh
#Developer:  @yih855 thanks for helping @Dcx400
#lowtexcode@yih855 https://t.me/+EAway-gwqOlmNGE9
LOG="/sdcard/lotexyih_dynamic.log"

#lowtexcode@yih855 https://t.me/+EAway-gwqOlmNGE9
ts() { date '+%Y-%m-%d %H:%M:%S'; }
log_info() { echo -e "[ $(ts) ] \033[1;32m[INFO]\033[0m $1" | tee -a "$LOG"; }
log_warn() { echo -e "[ $(ts) ] \033[1;33m[WARN]\033[0m $1" | tee -a "$LOG"; }
#lowtexcode@yih855 https://t.me/+EAway-gwqOlmNGE9
apply_dc() {
    ns="$1"; key="$2"; val="$3"
    if command -v cmd >/dev/null 2>&1; then
        cmd device_config put "$ns" "$key" "$val" 2>/dev/null
        log_info "DeviceConfig [$ns] $key = $val"
    else
        log_warn "cmd not found, skipping $key"
    fi
}

#lowtexcode@yih855 https://t.me/+EAway-gwqOlmNGE9
log_info "Waiting for device boot..."
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 5; done
sleep 1
log_info "Boot completed. Applying optimizations..."

#lowtexcode@yih855 https://t.me/+EAway-gwqOlmNGE9
log_info "Applying ADPF Core optimizations..."
apply_dc game com.android.server.power.hint.adpf_session_tag true
apply_dc game android.os.adpf_measure_during_input_event_boost true
apply_dc game android.os.adpf_obtainview_boost true
apply_dc game game android.os.adpf_hwui_gpu true
log_info "HWUI GPU bridge enabled"

#Developer @yih855 thanks for helping @Dcx400
log_info "SurfaceFlinger / Frame Pacing..."
apply_dc core_graphics android.view.flags.set_frame_rate_callback true
apply_dc core_graphics com.android.graphics.surfaceflinger.flags.use_known_refresh_rate_for_fps_consistency true
apply_dc core_graphics com.android.graphics.surfaceflinger.flags.frame_rate_category_mrr true

#Developer @yih855 thanks for helping @Dcx400
log_info "Toolkit Frame-Rate Engine..."
apply_dc toolkit android.view.flags.toolkit_set_frame_rate true
apply_dc toolkit android.view.flags.toolkit_metrics_for_frame_rate_decision true

#Developer @yih855 thanks for helping @Dcx400
log_info "Jank Monitor configuration..."
apply_dc interaction_jank_monitor trace_threshold_frame_time_millis -1
apply_dc interaction_jank_monitor trace_threshold_missed_frames -1

#Developer @yih855 thanks for helping @Dcx400
log_info "Window / Refresh hints..."
apply_dc window_surfaces com.android.window.flags.explicit_refresh_rate_hints true
apply_dc window_surfaces com.android.window.flags.enable_buffer_transform_hint_from_display true

#Developer @yih855 thanks for helping @Dcx400
log_info "DisplayManager refresh-rate optimizations..."
apply_dc display_manager com.android.server.display.feature.flags.ignore_app_preferred_refresh_rate_request false
apply_dc display_manager com.android.server.display.feature.flags.enable_user_preferred_mode_vote true
apply_dc display_manager com.android.server.display.feature.flags.enable_displays_refresh_rates_synchronization true
apply_dc display_manager com.android.server.display.feature.flags.enable_vsync_low_light_vote false
apply_dc display_manager com.android.server.display.feature.flags.enable_vsync_low_power_vote false

#Developer @yih855 thanks for helping @Dcx400
log_info "Memory & background optimizations..."
settings put global app_standby_enabled 0
cmd activity memory-factor set 1
log_info "Background limits relaxed & memory optimizations applied "

#Developer @yih855 thanks for helping @Dcx400
log_info " Dynamic Game Mode applied successfully!"
echo "Done. Check $LOG for full details."