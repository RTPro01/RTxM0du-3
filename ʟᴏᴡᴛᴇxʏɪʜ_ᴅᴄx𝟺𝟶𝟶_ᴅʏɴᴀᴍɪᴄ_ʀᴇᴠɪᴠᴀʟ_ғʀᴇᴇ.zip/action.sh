#!/system/bin/sh
#Developer @yih855 thanks for helping@Dcx400 for this 
LOG="/sdcard/lowtex_dynamic_revival.log"
ts(){ date '+%Y-%m-%d %H:%M:%S'; }
log(){ echo "[ $(ts) ] \033[1;32m[FREE]\033[0m $1" | tee -a "$LOG"; }

while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 1; done
sleep 1

#thanks for helping@Dcx400 for removing this (cmd display get-active-config)
HZ=$(settings get system peak_refresh_rate 2>/dev/null | cut -d. -f1)
[ -z "$HZ" ] && HZ=$(settings get system min_refresh_rate | cut -d. -f1)
[ -z "$HZ" ] && HZ=60

#Developer @yih855 thanks for helping@Dcx400 for this 
RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 1500000)

log "RAM=$RAM_KB | CPU=$CPU_MAX_FREQ | HZ=$HZ"

#idea yih855
pick_fps() {
    hz=$1
    [ -z "$hz" ] && echo 60 || echo "$hz"
}

FPS=$(pick_fps "$HZ")

#idea yih855
get_ds_range() {
    case "$1" in
        com.mobile.legends) echo "0.55 0.6 0.65 0.66" ;;
        com.miHoYo.GenshinImpact) echo "0.5 0.52 0.55 0.6" ;;
        com.garena.game.codm) echo "0.5 0.52 0.55 0.57" ;;
        com.roblox.client) echo "0.55 0.6 0.65" ;;
        com.tencent.ig) echo "0.5 0.55 0.6 0.65" ;;
        com.netease.newspike) echo "0.56 0.58 0.65 0.66" ;;
        com.dts.freefire) echo "0.55 0.6 0.65 0.66" ;;
        com.dts.freefiremax) echo "0.55 0.6 0.65 0.66" ;;
    esac
}


pick_ds() {
    values="$1"
    set -- $values
    n=$#


    if [ "$CPU_MAX_FREQ" -le 1600000 ]; then
        tier=1
    elif [ "$CPU_MAX_FREQ" -le 2000000 ]; then
        tier=2
    elif [ "$CPU_MAX_FREQ" -le 2600000 ]; then
        tier=3
    else
        tier=4
    fi

    case "$tier" in
        1) pos=1 ;;
        2) pos=$((n/3+1)) ;;
        3) pos=$((n/2+1)) ;;
        4) pos=$n ;;
    esac

    [ "$pos" -gt "$n" ] && pos=$n

    DS_SELECTED=""
    i=1
    for v in $values; do
        if [ "$i" -eq "$pos" ]; then
            DS_SELECTED=$(awk -v ds="$v" 'BEGIN{
                if (ds < 0.40) ds=0.40;
                if (ds > 0.70) ds=0.70;
                printf "%.2f", ds
            }')
            break
        fi
        i=$((i+1))
    done


    if [ -z "$DS_SELECTED" ] || ! echo "$DS_SELECTED" | grep -Eq '^[0-9]+\.[0-9]+$'; then
        DS_SELECTED="0.50"
    fi

    echo "$DS_SELECTED"
}

#idea yih855
GAMES="
com.mobile.legends
com.miHoYo.GenshinImpact
com.garena.game.codm
com.roblox.client
com.tencent.ig
com.netease.newspike
com.dts.freefire
com.dts.freefiremax
"

#idea yih855 thanks for helping@Dcx400 for this 
for pkg in $GAMES; do
    DS_RANGE=$(get_ds_range "$pkg")
    DS=$(pick_ds "$DS_RANGE")

    cmd game set --mode 2 --fps "$FPS" --downscale "$DS" "$pkg"
    cmd game mode 2 "$pkg"

    log "$pkg → FPS=$FPS | DS=$DS applied"
done

log "Dynamic revival finished successfully "