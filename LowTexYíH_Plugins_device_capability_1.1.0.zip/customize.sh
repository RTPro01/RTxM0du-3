#!/system/bin/sh


echo "╔═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╗"
echo "╚═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╝"
echo "   Sᴛᴀʀᴛɪɴɢ LᴏᴡTᴇxYɪ́H Pʟᴜɢɪɴ Iɴsᴛᴀʟʟᴀᴛɪᴏɴ"
echo "╔═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╗"
echo "╚═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╝"
echo "   Developer : @yih855"
echo "   Module Version : LowTexYíH Plugins v1.1.0"
echo "╔═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╗"
echo "╚═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╝"
echo ""


echo " [-] Installing LowTexYíH Plugin..."
sleep 2
echo "   › Configuring system optimizations..."
sleep 1
echo "   › Applying dynamic device detection..."
sleep 1
echo "   › Tuning display & FPS for ultra-smooth gaming..."
sleep 1
echo "   › Enabling touch response boost..."
sleep 1
echo " [-] Installation Successful!"


echo "╔═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╗"
echo "╚═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╝"
echo "   LᴏᴡTᴇxYɪ́H Pʟᴜɢɪɴ Iɴsᴛᴀʟʟᴀᴛɪᴏɴ Cᴏᴍᴘᴌᴇᴛᴇ"
sleep 2
echo " [YES] Installation Done! Enjoy optimized gaming performance."

sleep 1
echo "   For uninstallation or updates, simply run uninstall.sh"