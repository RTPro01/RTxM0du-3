echo "******* DEVICE INFO *******"
sleep 0.5


echo "Brand: $(getprop ro.product.brand)"
echo "Model: $(getprop ro.product.model)"
echo "Device Name: $(getprop ro.product.device)"
echo "Android Version: $(getprop ro.build.version.release)"
echo "Kernel: $(uname -r)"


FPS=$(settings get system peak_refresh_rate 2>/dev/null)
[ -z "$FPS" ] && FPS="Unknown"
echo "Max Refresh Rate: ${FPS}Hz"


CURFPS=$(dumpsys display 2>/dev/null | grep -Eo 'fps=[0-9]+' | cut -d= -f2 | tail -n1)
[ -z "$CURFPS" ] && CURFPS="Unknown"
echo "Current FPS: $CURFPS"


RENDERER=$(getprop debug.hwui.renderer)
[ -z "$RENDERER" ] && RENDERER="Default"
echo "Renderer: $RENDERER"


GPU=$(getprop ro.hardware.egl)
[ -z "$GPU" ] && GPU="Unknown"
echo "GPU: $GPU"


CPU=$(getprop ro.hardware)
CORES=$(nproc)
echo "CPU Hardware: $CPU"
echo "CPU Cores: $CORES"


CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null)
[ -z "$CPU_MAX_FREQ" ] && CPU_MAX_FREQ="Unknown"
echo "Max CPU Frequency: $CPU_MAX_FREQ KHz"


RAM_KB=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
RAM_GB=$(awk "BEGIN {printf \"%.2f\", $RAM_KB/1024/1024}")
echo "Total RAM: ${RAM_GB} GB"


RAM_FREE=$(awk '/MemAvailable/ {print $2}' /proc/meminfo)
RAM_FREE_GB=$(awk "BEGIN {printf \"%.2f\", $RAM_FREE/1024/1024}")
echo "Available RAM: ${RAM_FREE_GB} GB"


THERM=$(dumpsys thermalservice 2>/dev/null | grep -i status | head -1)
[ -z "$THERM" ] && THERM="Unknown"
echo "Thermal Status: $THERM"

echo "**************************"