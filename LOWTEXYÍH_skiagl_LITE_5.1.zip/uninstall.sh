#!/system/bin/sh
#hmmm anooo ?


for a in $(dumpsys game | grep -o "$(cmd package list packages | cut -f2 -d:)"); do
    cmd game reset "$a"
    cmd device_config delete game_overlay "$a"
done



setprop debug.hwui.renderer opengl
setprop debug.hwui.use_hint_manager false
setprop debug.hwui.render_dirty_regions true
setprop debug.hwui.max_texture_allocation 16777216
setprop debug.hwui.texture_cache_size 32
setprop debug.hwui.layer_cache_size 32

setprop debug.hwui.vsync false
setprop debug.egl.swapinterval 1
setprop debug.egl.force_msaa true


setprop debug.sf.use_frame_rate_priority 0
setprop debug.sf.early_phase_offset_ns 0
setprop debug.sf.late_phase_offset_ns 0


settings put system background_power_saving_enable 1
settings put global low_power 1
cmd set adaptive_power_saver enable true 2>/dev/null
setprop debug.thermal.config thermal-conf-default
cmd deviceidle enable


am kill-all

cmd notification cancel-all


cmd notification post \
    -S bigtext \
    -t "LowTex LITE RESET" \
    "All settings restored to default." \
    "Module Deactivated"

echo "[LowTex LITE RESET] All settings restored to default "