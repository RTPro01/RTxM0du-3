#!/system/bin/sh
#hmmmmmmmmm ano?

RES="$(wm size | grep -oE '[0-9]+x[0-9]+' | head -n1)"
WIDTH=$(echo "$RES" | cut -d'x' -f1)


fps="$(dumpsys display | grep -Eo 'fps=[0-9]+' | cut -d= -f2 | sort -n | tail -n1)"
[ -z "$fps" ] && fps=90
[ "$fps" -gt 120 ] && fps=120


if [ "$WIDTH" -le 720 ]; then
    downscale=0.46
elif [ "$WIDTH" -le 1080 ]; then
    downscale=0.45
else
    downscale=0.45
fi


for a in $(dumpsys game | grep -o "$(cmd package list packages | cut -f2 -d:)"); do
    cmd device_config put game_overlay "$a" \
        mode=2,downscaleFactor="$downscale",useAngle=false,fps="$fps",loadingBoost=1

    ver="$(getprop ro.build.version.release | cut -d. -f1)"
    if [ "$ver" -ge 13 ]; then
        cmd game set --mode 2 --downscale "$downscale" --fps "$fps" "$a"
    elif [ "$ver" -ge 12 ]; then
        cmd game set --mode 2 --downscale "$downscale" --fps "$fps" "$a"
    fi
done

am kill-all
setprop debug.hwui.vsync true
setprop debug.egl.swapinterval 1
setprop debug.egl.force_msaa false
setprop debug.sf.use_frame_rate_priority 0
setprop debug.hwui.renderer skiagl
settings put global low_power 0
cmd deviceidle disable
cmd set adaptive_power_saver enable false 2>/dev/null
cmd looper_stats disable  

    PACKAGES="
com.facebook.services
com.android.chrome
com.google.android.calendar
com.google.android.gm
com.android.hotwordenrollment.xgoogle
com.google.android.gms.location.history
com.google.android.apps.maps
com.google.android.youtube
com.google.android.googlequicksearchbox
"
    for pkg in $PACKAGES; do
        am force-stop "$pkg" 2>/dev/null
    done

    cmd set adaptive_power_saver enable false 2>/dev/null
    setprop debug.thermal.config thermal-conf-disabled
    setprop debug.stagefright.ccodec 4
    setprop debug.sf.early_phase_offset_ns 500000
    setprop debug.sf.late_phase_offset_ns 1500000    
    setprop debug.hwui.max_texture_allocation 33554432

cmd notification post \
    -S bigtext \
    -t "LowTex LITE SUCCESS" \
    "Screen: $RES | FPS: $fps | Downscale: $downscale" \
    "Activated"

echo "[LowTex LITE] RES=$RES FPS=$fps Downscale=$downscale"