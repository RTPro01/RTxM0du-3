#!/system/bin/sh

# Developer: LowTexYíH @yih855

echo() {
  echo "[LowTexYíH Dynamic Uninstaller v1.1.0] $1"
}


while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

echo "Boot completed. Reverting to default settings..."


echo "Reverting animations..."
settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1


echo "Reverting display settings..."
cmd display set-match-content-frame-rate-pref 0 2>/dev/null
cmd display set-user-disabled-hdr-types 0 2>/dev/null


echo "Reverting memory settings..."
cmd activity memory-factor set 1 2>/dev/null
settings put global settings_enable_monitor_phantom_procs true
settings put global app_standby_enabled 1
settings put global fstrim_mandatory_interval 0


echo "Reverting touch boost..."
settings put secure long_press_timeout 500
settings put secure multi_press_timeout 500
[ -e /sys/module/msm_performance/parameters/touchboost ] && \
echo 0 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null
[ -e /sys/power/pnpmgr/touch_boost ] && \
echo 0 > /sys/power/pnpmgr/touch_boost 2>/dev/null


echo "Reverting thermal settings..."
setprop debug.thermal.throttle.support yes 2>/dev/null


echo "Reverting game optimizations..."
for pkg in $(cmd package list packages -3 | cut -f2 -d:); do
  device_config put game_overlay "$pkg" \
  mode=0,fps=60
  cmd game mode normal "$pkg"
  echo "Reverted to default for: $pkg"
done


if [ "$ANDROID_VER" -ge 14 ]; then
  echo "Reverting Android 14+ game flags..."
  cmd device_config override game android.os.adpf_prefer_power_efficiency true 2>/dev/null
  cmd device_config override game android.os.adpf_hwui_gpu false 2>/dev/null
fi


echo 0 > /proc/sys/vm/drop_caches 2>/dev/null

echo "LowTexYíH Dynamic V1.1.0 uninstalled and settings reverted."


echo "Reverting background app optimizations..."
for a in $(cmd package list packages google | cut -f2 -d: | grep -v ia.mo); do
  cmd appops reset "$a"
  cmd appops set "$a" FOREGROUND_SERVICE_SPECIAL_USE allow
  cmd appops set "$a" INSTANT_APP_START_FOREGROUND allow
  cmd appops set "$a" RUN_ANY_IN_BACKGROUND allow
  cmd appops set "$a" RUN_IN_BACKGROUND allow
  cmd package revoke --all-permissions "$a"
done


cmd package revoke com.google.android.gms android.permission.READ_CONTACTS
cmd package revoke com.google.android.gms android.permission.WRITE_CONTACTS

echo "Background apps reverted and permissions removed."

echo "Uninstallation complete. All settings reverted to default."