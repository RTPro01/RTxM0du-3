#!/system/bin/sh

# Developer: LowTexYíH @yih855

echo() {
  echo "[LowTexYíH Dynamic v1.1.0] $1"
}

echo "▒█▀▀█ ▒█▀▀▀█ ▒█▀▀█ ▀█▀"   
echo "▒█▄▄█ ▒█░░▒█ ▒█░▄▄ ▒█░"  
echo "▒█░░░ ▒█▄▄▄█ ▒█▄▄█ ▄█▄"  
echo ""  

echo " HI GUYS IM LowTexYíH — my first basic plugins!"
echo " Please support my channel — thank you!"
echo ""

echo "[LowTexYíH Plugins - Dynamic Gaming Optimizer]"
echo "Version: 1.1.0"
echo "Purpose: Auto performance tuning for smoother gaming"
echo ""

echo "Core Features:"
echo " • Smart device detection"
echo " • Display & FPS tuning"
echo " • Game performance mode"
echo " • Touch boost"
echo " • Memory optimization"
echo ""

echo "All features are automatic — plug & play!"
echo "Safe to uninstall anytime using uninstall.sh"
echo ""


while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

echo "Boot completed. LowTexYíH Dynamic V1 Starting AUTO-GAME optimization..."


FPS=$(settings get system peak_refresh_rate 2>/dev/null || \
      settings get system user_refresh_rate 2>/dev/null || echo 120)
echo "Detected max refresh rate: $FPS"


RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 1500000)
ANDROID_VER=$(getprop ro.build.version.release)
echo "RAM: $RAM_KB KB | CPU: $CPU_MAX_FREQ | Android: $ANDROID_VER"


if [ "$RAM_KB" -ge 8000000 ] && [ "$CPU_MAX_FREQ" -ge 2600000 ]; then
  CLASS="HIGH-END"
elif [ "$RAM_KB" -ge 6000000 ]; then
  CLASS="UPPER-MID"
elif [ "$RAM_KB" -ge 4000000 ]; then
  CLASS="MID"
else
  CLASS="LOW-END"
fi

echo "Device class: $CLASS"
echo "Ultra-smooth performance mode enabled with no scaling."


echo "Disabling animations..."
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0


echo "Optimizing display..."
cmd display set-match-content-frame-rate-pref 1 2>/dev/null
cmd display set-user-disabled-hdr-types 1 2 3 4 2>/dev/null


echo "Optimizing memory..."
cmd activity memory-factor set 0 2>/dev/null
settings put global settings_enable_monitor_phantom_procs false
settings put global app_standby_enabled 0
settings put global fstrim_mandatory_interval 1


echo "Enabling touch boost..."
settings put secure long_press_timeout 180
settings put secure multi_press_timeout 200
[ -e /sys/module/msm_performance/parameters/touchboost ] && \
echo 1 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null
[ -e /sys/power/pnpmgr/touch_boost ] && \
echo 1 > /sys/power/pnpmgr/touch_boost 2>/dev/null


echo "Reducing thermal limits..."
setprop debug.thermal.throttle.support no 2>/dev/null


echo "Applying ultra-smooth performance mode to all installed games..."
for pkg in $(cmd package list packages -3 | cut -f2 -d:); do
  device_config put game_overlay "$pkg" \
  mode=2,fps=$FPS
  cmd game mode performance "$pkg"
  echo "Applied to: $pkg | FPS=$FPS"
done


if [ "$ANDROID_VER" -ge 14 ]; then
  echo "Applying Android 14+ game flags..."
  cmd device_config override game android.os.adpf_prefer_power_efficiency false 2>/dev/null
  cmd device_config override game android.os.adpf_hwui_gpu true 2>/dev/null
fi


echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

echo "LowTexYíH Dynamic V1.1.0applied successfully."


echo "Optimizing background apps..."
for a in $(cmd package list packages google | cut -f2 -d: | grep -v ia.mo); do
  cmd appops reset "$a"
  cmd appops set "$a" FOREGROUND_SERVICE_SPECIAL_USE ignore
  cmd appops set "$a" INSTANT_APP_START_FOREGROUND ignore
  cmd appops set "$a" RUN_ANY_IN_BACKGROUND ignore
  cmd appops set "$a" RUN_IN_BACKGROUND ignore
  cmd package revoke --all-permissions "$a"
done


cmd package grant com.google.android.gms android.permission.READ_CONTACTS
cmd package grant com.google.android.gms android.permission.WRITE_CONTACTS

echo "Background apps optimized and permissions granted successfully."