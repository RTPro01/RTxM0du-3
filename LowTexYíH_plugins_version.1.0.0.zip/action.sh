#!/system/bin/sh

echo "▒█▀▀█ ▒█▀▀▀█ ▒█▀▀█ ▀█▀" 
echo "▒█▄▄█ ▒█░░▒█ ▒█░▄▄ ▒█░"
echo "▒█░░░ ▒█▄▄▄█ ▒█▄▄█ ▄█▄"
echo ""

echo " HI GUYS IM LowTexYíH this is my first time to create basic plugin"
echo " Please support my channel — thank you!"

echo ""
echo "[LowTexYíH Plugins - Dynamic Gaming Optimizer]"
echo "Version: 1.0"
echo "Purpose: Automatic performance tuning based on your device capability"
echo ""

echo "Features included in this module:"
echo ""

echo "NOTE:"
echo "Some devices may restrict or block certain system commands."
echo "Due to manufacturer limits (Xiaomi, Samsung, Oppo, Vivo, Realme, Huawei, etc.),"
echo "this module may work fully, partially, or not at all."
echo "Results depend on device model and Android version."
echo "Use this module at your own risk."
echo ""

echo "1) Dynamic Device Detection"
echo "   • Reads RAM, CPU speed, and Android version"
echo "   • Auto-classifies your device (High / Upper-Mid / Mid / Low)"
echo "   • Automatically selects best downscaleFactor for performance"

echo ""
echo "2) Display & FPS Optimization"
echo "   • Disables animations for faster UI"
echo "   • Forces match-content frame rate"
echo "   • Disables HDR types that cause stutter"

echo ""
echo "3) Game & ADPF Enhancements"
echo "   • Enables performance game mode per app"
echo "   • Applies Android 14+ game performance flags"
echo "   • Uses Game Overlay downscaling for smoother FPS"

echo ""
echo "4) Touch Boost"
echo "   • Faster touch response"
echo "   • Enables Qualcomm touchboost when available"

echo ""
echo "5) Memory & Cache Tuning"
echo "   • Reduces background process load"
echo "   • Improves RAM management"
echo "   • Forces periodic storage trim"

echo ""
echo "All features run automatically — plug & play!"
echo "Safe to uninstall anytime using uninstall.sh"
echo ""