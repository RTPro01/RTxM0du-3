#!/system/bin/sh



# This is my first time to create basic plugins 
#Developer: LowTexYíH @yih855

log() {
  echo "[LowTexYíH Dynamic v1] $1"
}


while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

log "Boot completed. LowTexYíH Dynamic V1 Starting AUTO-GAME optimization..."




FPS=$(settings get system peak_refresh_rate 2>/dev/null || \
      settings get system user_refresh_rate 2>/dev/null || echo 120)

log "Detected max refresh rate: $FPS"




RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 1500000)
ANDROID_VER=$(getprop ro.build.version.release)

log "RAM: $RAM_KB KB | CPU: $CPU_MAX_FREQ | Android: $ANDROID_VER"


if [ "$RAM_KB" -ge 8000000 ] && [ "$CPU_MAX_FREQ" -ge 2600000 ]; then
  DOWNSCALE=0.6
  CLASS="HIGH-END"
elif [ "$RAM_KB" -ge 6000000 ]; then
  DOWNSCALE=0.55
  CLASS="UPPER-MID"
elif [ "$RAM_KB" -ge 4000000 ]; then
  DOWNSCALE=0.50
  CLASS="MID"
else
  DOWNSCALE=0.47
  CLASS="LOW-END"
fi

log "Device class: $CLASS"
log "Auto-selected downscaleFactor = $DOWNSCALE"




log "Disabling animations..."
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0




log "Optimizing display..."
cmd display set-match-content-frame-rate-pref 1 2>/dev/null
cmd display set-user-disabled-hdr-types 1 2 3 4 2>/dev/null




log "Optimizing memory..."
cmd activity memory-factor set 0 2>/dev/null
settings put global settings_enable_monitor_phantom_procs false
settings put global app_standby_enabled 0
settings put global fstrim_mandatory_interval 1




log "Enabling touch boost..."
settings put secure long_press_timeout 180
settings put secure multi_press_timeout 200

[ -e /sys/module/msm_performance/parameters/touchboost ] && \
echo 1 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null

[ -e /sys/power/pnpmgr/touch_boost ] && \
echo 1 > /sys/power/pnpmgr/touch_boost 2>/dev/null




log "Reducing thermal limits..."
setprop debug.thermal.throttle.support no 2>/dev/null





log "Applying AUTO downscale + performance mode to all installed games..."

for pkg in $(cmd package list packages -3 | cut -f2 -d:); do

  
  device_config put game_overlay "$pkg" \
  mode=2,downscaleFactor=$DOWNSCALE,fps=$FPS

  cmd game mode performance "$pkg"

  log "Applied to: $pkg | scale=$DOWNSCALE"
done




if [ "$ANDROID_VER" -ge 14 ]; then
  log "Applying Android 14+ game flags..."

  cmd device_config override game android.os.adpf_prefer_power_efficiency false 2>/dev/null
  cmd device_config override game android.os.adpf_hwui_gpu true 2>/dev/null
fi




echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

log "LowTexYíH Dynamic V1 applied successfully."
