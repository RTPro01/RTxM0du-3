#!/system/bin/sh

CYAN="\033[36m"
YELLOW="\033[33m"
RESET="\033[0m"


echo -e "${CYAN}==============================================${RESET}"
echo -e "${CYAN}[LowTexYíHPlugins-GMIDynamicServiceOptimizerForGaming]${RESET}"
echo -e "${CYAN}Version: 3.0${RESET}"
echo -e "${CYAN}==============================================${RESET}"
echo ""


echo -e "${YELLOW}NOTE:${RESET}"
echo -e "${YELLOW}Some devices may restrict or block certain system commands.${RESET}"
echo -e "${YELLOW}Due to manufacturer limits (Xiaomi, Samsung, Oppo, Vivo, Realme, Huawei, etc.),${RESET}"
echo -e "${YELLOW}this module may work fully, partially, or not at all.${RESET}"
echo -e "${YELLOW}Results depend on device model and Android version.${RESET}"
echo -e "${YELLOW}Use this module at your own risk.${RESET}"
echo ""


echo -e "${CYAN}Hi guys! I’m LowTexYíH — First Time Basic Plugin${RESET}"
echo -e "${CYAN}Please support my channel — Thank you!${RESET}"
echo ""


echo -e "${CYAN}Features included in this module:${RESET}"

echo -e "${CYAN} 1) Dynamic Device Detection${RESET}"
echo -e "${CYAN}    • Reads RAM, CPU speed, and Android version${RESET}"
echo -e "${CYAN}    • Auto-classifies device (High / Upper-Mid / Mid / Low)${RESET}"
echo -e "${CYAN}    • Automatically selects best downscaleFactor${RESET}"
echo ""

echo -e "${CYAN} 2) Display & FPS Optimization${RESET}"
echo -e "${CYAN}    • Disables animations for faster UI${RESET}"
echo -e "${CYAN}    • Forces match-content frame rate${RESET}"
echo -e "${CYAN}    • Disables HDR types that cause stutter${RESET}"
echo ""

echo -e "${CYAN} 3) Game & ADPF Enhancements${RESET}"
echo -e "${CYAN}    • Enables performance game mode per app${RESET}"
echo -e "${CYAN}    • Applies Android 11+ game performance flags${RESET}"
echo -e "${CYAN}    • Uses Game Overlay downscaling for smoother FPS${RESET}"
echo ""

echo -e "${CYAN} 4) Touch Boost${RESET}"
echo -e "${CYAN}    • Faster touch response${RESET}"
echo -e "${CYAN}    • Enables Qualcomm touchboost when available${RESET}"
echo ""

echo -e "${CYAN} 5) Memory & Cache Tuning${RESET}"
echo -e "${CYAN}    • Reduces background process load${RESET}"
echo -e "${CYAN}    • Improves RAM management${RESET}"
echo -e "${CYAN}    • Forces periodic storage trim${RESET}"
echo ""

echo -e "${CYAN}All features run automatically — plug & play!${RESET}"
echo -e "${CYAN}Safe to uninstall anytime using uninstall.sh${RESET}"
echo ""