#!/bin/sh
echo "[ 𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻🔥 ] "
echo "▶ Developer : @nzd_official "
echo "▶ Version : 1.0 "
echo "▶ Status : No Root "
sleep 2
echo "
░█▀▀▀█ ░█──░█ ░█▀▀▀ ░█▀▀█
░█──░█ ─░█░█─ ░█▀▀▀ ░█▄▄▀
░█▄▄▄█ ──▀▄▀─ ░█▄▄▄ ░█─░█

░█▀▀█ ░█─── ░█▀▀▀█ ░█▀▀█ ░█─▄▀
░█─── ░█─── ░█──░█ ░█─── ░█▀▄─
░█▄▄█ ░█▄▄█ ░█▄▄▄█ ░█▄▄█ ░█─░█"
echo ""
sleep 2
echo "▎𝗗𝗲𝘃𝗶𝗰𝗲 𝗜𝗻𝗳𝗼📱 "
sleep 0.5
echo "▎DEVICE=$(getprop ro.product.model) "
sleep 1
echo "▎BRAND=$(getprop ro.product.system.brand) "
sleep 1
echo "▎MODEL=$(getprop ro.build.product) "
sleep 1
echo "▎KERNEL=$(uname -r) "
sleep 1
echo "▎GPU INFO=$(getprop ro.hardware.egl) "
sleep 1
echo "▎CPU INFO=$(getprop ro.hardware) "
sleep 1
echo "▎ ANDROID VERSION : $(getprop ro.build.version.release) "
sleep 2
echo ""
echo " ▶ PROCES.........  "
echo ""
sleep 2
echo " ▶ WAIT.....  "
echo ""
sleep 5
echo "[■□□□□□□□□□]  "
sleep 1
echo "[■■□□□□□□□□]  "
sleep 1
echo "[■■■□□□□□□□]  "
sleep 1
echo "[■■■■□□□□□□]  "
sleep 1
echo "[■■■■■□□□□□]  "
sleep 1
echo "[■■■■■■□□□□]  "
sleep 1
echo "[■■■■■■■□□□]  "
sleep 1
echo "[■■■■■■■■□□]  "
sleep 1
echo "[■■■■■■■■■□]  "
sleep 1
echo "[■■■■■■■■■■]  "
sleep 0.5
echo ""
sleep 1

{

settings delete system peak_refresh_rate 
settings delete system user_refresh_rate 
settings delete system min_refresh_rate 
settings delete system max_refresh_rate 
settings delete system thermal_limit_refresh_rate 
settings delete system miui_refresh_rate 
settings delete secure user_refresh_rate 
settings delete secure miui_refresh_rate 
settings delete system tran_refresh_mode 
settings delete system tran_need_recovery_refresh_mode 
settings delete system refresh_rate 
settings delete system refresh_rate_policy 
settings delete system preferred_refresh_rate 
settings delete system max_render_frame_rate 
settings delete system target_fps 
settings delete global min_fps 
settings delete global max_fps 
settings delete global transition_animation_scale 
settings delete global window_animation_scale 
settings delete global animator_duration_scale 

# Enable performance mode (Xiaomi devices)

settings delete system POWER_PERFORMANCE_MODE_OPEN 

# Enable high performance

settings delete system high_performance_mode_on 

# Enable speed mode (Xiaomi devices)

settings delete secure speed_mode_enable 

# Performance focus

settings delete system power_save_mode 
settings delete global miui_performance_mode 
settings delete global performance_profile 

# Disable sleep mode

settings delete global device_idle_constants 
settings delete global low_power 

# Boost Game and Graphic

settings delete global GdeleteUNER_SWITCH 
settings delete global FPSTUNER_SWITCH 
settings delete global PERFORMANCE_BOOST_MODE 

}

echo ""
echo "▶ Module succesfully overclocked.... "
sleep 1
echo ""
cmd notification post -S bigtext -t ' 🚀 Performance Overclock ' 'Tag' 'DELETED!!' > /dev/null 2>&1
echo " SUBSCRIBE | LIKE 👍 | SHARE | COMMENT "
echo ""
echo " Done....... "
