#!/system/bin/sh
# ============================================================
# POWER BY SASUKEFILES
# ============================================================

echo " "
echo "══════════════════════════════════════════════════════════"
echo "     OPTIMIZATION STARTING         "
echo "══════════════════════════════════════════════════════════"
echo " "

# ============================================================
# FORCE BRUTE PERFORMANCE MODE (ANDROID SYSTEM)
# ============================================================
echo "[🚀] BOOST PERFORMANCE.."

# Force the device into maximum performance mode (if supported)
cmd power set-mode 1
settings put global performance_mode_enabled 1

# Disable Battery Saver completely
settings put global battery_saver_mode_enabled 0
settings put global low_power_mode 0
settings put global battery_saver_constants ""
settings put global battery_saver_device_specific_constants ""
settings put global thermal_disabled 1
settings put global game_thermal_control_enabled 0
settings put global game_thermal_mode 2

# ============================================================
# FORCE GPU RENDERING
# ============================================================
echo "[✅] BOOST GPU..."

settings put system smooth_movement 1
settings put global force_gpu_rendering 1
settings put global hardware_acceleration_enabled 1
settings put global disable_overlays 0

# ============================================================
# ULTRA SMOOTH ANIMATION & FRAME PACING
# ============================================================
echo "[✅] BOOST FRAME PACING..."

# Instant Animations
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

# Reduce System Latency
settings put global app_standby_enabled 0
settings put global adaptive_battery_management_enabled 0
am kill-all
cmd game_mode set com.garena.game.codm 2
cmd activity unfreeze com.garena.game.codm
am set-standby-bucket com.garena.game.codm active
dumpsys deviceidle whitelist +com.garena.game.codm
cmd appops set com.garena.game.codm RUN_IN_BACKGROUND allow
cmd appops set com.garena.game.codm RUN_ANY_IN_BACKGROUND allow
am set-standby-bucket com.garena.game.codm exempted

# ============================================================
# FINAL STATUS
# ============================================================
echo " "
echo "══════════════════════════════════════════════════════════"
echo "      [✅] NON-ROOT BOOST COMPLETE [✅]            "
echo "══════════════════════════════════════════════════════════"