#!/system/bin/sh

sleep 2

# Target path used in your script
DEST="/storage/emulated/0/Android/data/com.garena.game.codm/files/Config/"

# Files to remove
FILE1="$DEST/Codm90fps.xml"
FILE2="$DEST/cpugpu.so"
FILE3="$DEST/codm_setting"

# Remove XML
if [ -f "$FILE1" ]; then
rm -f "$FILE1"
echo "  ✓ Removed Codm90fps.xml"
else
echo "  - Codm90fps.xml not found"
fi

# Remove CPU/GPU library
if [ -f "$FILE2" ]; then
rm -f "$FILE2"
echo "  ✓ Removed cpugpu.so"
else
echo "  - cpugpu.so not found"
fi

# Remove settings
if [ -f "$FILE3" ]; then
rm -rf "$FILE3"
echo "  ✓ Removed codm_setting"
else
echo "  - codm_setting not found"
fi


PACKAGE="com.garena.game.codm"

sleep 2

echo "[1/4] Removing game_overlay device_config..."

device_config delete game_overlay $PACKAGE

echo "✓ device_config cleaned"

sleep 1

echo "✓ debug props reset"

sleep 1

echo "[3/4] Restoring Android settings..."

settings delete global com.garena.game.codm.fps_target
settings delete global com.garena.game.codm.fps_lock
settings delete global com.garena.game.codm.frame_rate_control
settings delete global com.garena.game.codm.graphics_quality
settings delete global com.garena.game.codm.performance_mode
settings delete global com.garena.game.codm.cpu_boost
settings delete global com.garena.game.codm.gpu_boost
settings delete global com.garena.game.codm.low_latency_mode
settings delete global com.garena.game.codm.ultra_low_latency

settings delete system pointer_speed
settings delete system touch_pressure_scale

echo "✓ settings restored"

sleep 1

echo "[4/4] Clearing content provider entries..."

content delete --uri content://settings/global --where "name LIKE 'com.garena.game.codm.%'"

echo "✓ CODM config removed"