#!/system/bin/sh
echo 
echo "
⠀⠀⠀⠀⠀⠀⡠⢲⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢀⠃⠸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⠐⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⣠⠖⢈⣹⣀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⡜⢘⡔⢁⣀⠀⠳⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⢧⡿⣒⡽⠎⠁⠀⡜⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢹⠁⠘⢂⢀⣤⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⢱⣶⣾⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⣠⢂⠀⠀⢀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣿⣿⣿⣿⣿⡀⠀⠀⠀⠀⠀⡜⣶⢻⢔⡜⠝⠒⠒⢓⣲⡤⣠⢄⡀⠀⠀⠀
⠀⠀⠀⠀⢹⣿⣿⣿⣿⡇⠀⠀⣀⣀⢸⠿⢹⢈⠘⢁⢞⢟⡴⠻⢇⣀⣙⢏⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣿⣿⣿⣿⣇⠀⢚⠩⠴⢢⡆⠸⠘⡔⠁⡲⠕⠞⠉⡡⠔⡁⠒⣑⠦⠀⠀
⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⠴⠧⢀⣾⣿⣿⣿⣿⣿⣾⣔⡒⢈⠡⠊⢤⠢⢾⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⡆⢀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⠀⠀⠉⠁⢲⡞⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⡿⠊⠈⠋⠛⠛⢿⣿⣿⣿⣿⣿⣿⣷⣀⠐⢬⠘⡇⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⡇⠀⡀⠀⠀⠀⠀⠈⢿⣿⣿⣿⣿⣿⣯⡗⢔⡀⠑⠰⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⣧⠀⢹⣦⣀⡀⠀⠀⠀⠀⡩⢿⢿⣿⠿⢗⡪⡧⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠈⣿⣿⣿⣧⠘⢧⣉⣿⠀⠀⠀⠀⢠⢯⣸⠋⠀⢢⣥⠁⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⣿⣿⣮⣋⡉⠀⠀⣠⣼⣿⣿⣿⠀⠀⠈⠇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⣿⣿⣿⣄⠀⠈⠠⠗⣾⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣏⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⡀⠀⠀⠀"⠀⠀⠀⠀
echo
echo
echo " ➤ ᴀᴜᴛʜᴏʀ : @ɴᴇʀᴜ" 
echo " ➤ ꜱʜᴇʟʟ   : ᴄᴏᴅᴍ" 
echo " ➤ ʀᴇʟᴇᴀꜱᴇ : 17 - ᴍᴀʀ - 2026"
echo
echo "  -------------------------------------"
echo "  [-] ᴀᴄᴛɪᴠᴇ ᴀʟʟ ꜰᴇᴀᴛᴜʀᴇ ᴛʜɪꜱ ᴍᴏᴅᴜʟᴇ..."
echo
sleep 4
echo "[1] FPS LOCK & FRAME STABILITY"
echo "- Locks Call of Duty Mobile to stable 90 FPS"
echo "- Frame pacing and scheduler optimized"
echo "- Frame drop prevention and jitter reduction"
echo "- Ultra frame stability and smooth gameplay"
echo ""

echo "[2] GPU RENDERING OPTIMIZATION"
echo "- Forces Vulkan rendering pipeline"
echo "- GPU pipeline parallelization"
echo "- Shader cache and texture streaming optimization"
echo "- Low latency GPU frame rendering"
echo "- GPU command pipeline and render fast path"
echo ""

echo "[3] CPU PERFORMANCE BOOST"
echo "- Prioritizes big CPU cores for gaming"
echo "- Gaming scheduler optimization"
echo "- Render thread and logic thread priority boost"
echo "- Reduced context switching and latency"
echo "- CPU pipeline and frame computation optimization"
echo ""

echo "[4] RAM & MEMORY OPTIMIZATION"
echo "- High RAM priority for the game"
echo "- Texture and asset caching improvements"
echo "- ZRAM boost and aggressive memory allocation"
echo "- Faster asset loading and frame caching"
echo "- Memory pipeline optimized for gaming"
echo ""

echo "[5] RENDER PIPELINE & GRAPHICS"
echo "- Fast render pipeline with parallel processing"
echo "- Reduced rendering latency"
echo "- Multi-core rendering enabled"
echo "- Low graphics overhead for higher FPS"
echo "- Optimized shader compilation and command buffers"
echo ""

echo "[6] INPUT & TOUCH LATENCY REDUCTION"
echo "- High touch sampling rate"
echo "- Reduced input latency and delay"
echo "- High priority input processing"
echo "- Faster gesture and control response"
echo ""

echo "[7] THERMAL & POWER CONTROL"
echo "- Thermal frame limit removed"
echo "- Performance mode enabled"
echo "- CPU and GPU boost mode active"
echo "- Prevents aggressive power saving interference"
echo ""

echo "[8] NETWORK & LATENCY OPTIMIZATION"
echo "- Low ping mode enabled"
echo "- Network priority increased"
echo "- Packet optimization and bandwidth priority"
echo "- Reduced network latency for online gameplay"
echo ""

echo "[9] SYSTEM UI & ANDROID RENDERING"
echo "- Vulkan HWUI rendering enabled"
echo "- SurfaceFlinger low latency configuration"
echo "- Reduced animation delays"
echo "- Faster renderthread scheduling"
echo ""

echo "[10] GAME GRAPHICS SETTINGS OPTIMIZATION"
echo "- Low graphics overhead for maximum FPS"
echo "- Disabled heavy visual effects"
echo "- Lower shadow, particle, and texture load"
echo "- Optimized resolution scaling"
echo ""

echo "[11] GAME STABILITY SYSTEM"
echo "- Frame stabilizer enabled"
echo "- Stutter reduction system"
echo "- Anti-lag protection"
echo "- Drop frame prevention system"
echo ""

echo "[12] BACKGROUND PROCESS CONTROL"
echo "- Increased cached process limit"
echo "- Reduced background app interference"
echo "- Optimized activity manager settings"
# Source files
SRC1="/storage/emulated/0/CODM/Files/cpugpu.so"
SRC2="/storage/emulated/0/CODM/Files/cpugpuperf.so"
SRC3="/storage/emulated/0/CODM/Files/Codm90fps.xml"
SRC4="/storage/emulated/0/CODM/Files/codm_setting"

# Destination
DEST="/storage/emulated/0/Android/data/com.garena.game.codm/files/Config"

sleep 5

echo "📦 Copying CODM optimization files..."

# Copy cpugpu.so
if [ -f "$SRC1" ]; then
  cp "$SRC1" "$DEST" && echo "  ✔ cpugpu.so copied" || echo "  ❌ Failed to copy cpugpu.so"
else
  echo "  ❌ File not found: cpugpu.so"
fi

# Copy cpugpuperf.so
if [ -f "$SRC2" ]; then
  cp "$SRC2" "$DEST" && echo "  ✔ cpugpuperf.so copied" || echo "  ❌ Failed to copy cpugpuperf.so"
else
  echo "  ❌ File not found: cpugpuperf.so"
fi

# Copy Codm90fps.xml
if [ -f "$SRC3" ]; then
  cp "$SRC3" "$DEST" && echo "  ✔ Codm90fps.xml copied" || echo "  ❌ Failed to copy Codm90fps.xml"
else
  echo "  ❌ File not found: Codm90fps.xml"
fi

# Copy codm_setting
if [ -f "$SRC4" ]; then
  cp "$SRC4" "$DEST" && echo "  ✔ codm_setting copied" || echo "  ❌ Failed to copy codm_setting"
else
  echo "  ❌ File not found: codm_setting"
fi

sleep 3

echo
echo "-------------------------------------"
echo "📁 Target Directory:"
echo "   $DEST"
echo
echo "⚠ If failed, use ZArchiver or RS File Manager"
echo "due to Android 11+ storage restrictions."
echo
echo "-------------------------------------"
echo "[✔] CODM ACTIVE 90FPS"
echo "-------------------------------------"
device_config put game_overlay com.garena.game.codm \
"mode=performance,fps=90,fps_lock=90,fps_min=90,fps_max=90,\
downscale=1.0,use_angle=false,\
frame_pacing=ultra,frame_prediction=1,\
frame_render_ahead=2,frame_pipeline_parallel=1,\
frame_pipeline_cache=1,frame_time_stabilizer=1,\
frame_drop_protection=1,frame_latency_reduction=1,\
frame_stability_boost=1,\
gpu_mode=performance,gpu_pipeline=parallel,\
gpu_shader_cache=1,gpu_shader_precompile=1,\
gpu_async_compile=1,gpu_render_ahead=2,\
gpu_pipeline_cache=1,gpu_overdraw_optimize=1,\
gpu_tile_cache=1,gpu_thread_priority=1,\
cpu_mode=performance,cpu_game_priority=1,\
cpu_thread_boost=1,cpu_core_isolation=1,\
cpu_scheduler_boost=1,cpu_render_thread_priority=1,\
cpu_frame_sync=1,cpu_task_prefetch=1,\
ram_prefetch=1,ram_cache_boost=1,ram_texture_cache=1,\
ram_shader_cache=1,ram_frame_buffer=1,ram_background_limit=0,\
zram_boost=256GB,\
thermal_limit=85,thermal_throttle_reduction=1,thermal_cooling_boost=1,\
system_draw_optimize=1,system_cache_optimize=1,\
system_frame_predictor=1,system_touch_boost=1,\
network_latency_reduction=1,network_packet_priority=1,\
network_game_mode=1,network_jitter_reduction=1"
setprop debug.redroid.fps 90
setprop debug.sf.fps 90
setprop debug.refresh_rate.min_fps 90
setprop debug.cpurend.vsync false
setprop debug.gpurend.vsync false
setprop debug.gr.swapinterval 0
setprop debug.sf.disable_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.high_fps_early_phase_offset_ns 100000
setprop debug.sf.high_fps_late_app_phase_offset_ns 100000
setprop debug.sf.early_app_phase_offset_ns 100000
setprop debug.sf.early_gl_app_phase_offset_ns 100000
setprop debug.hwui.renderer vulkan
setprop debug.renderengine.backend skiaglthreaded
setprop debug.hwui.disable_draw_defer false
setprop debug.hwui.disable_draw_reorder false
setprop debug.hwui.skip_empty_damage true
setprop debug.hwui.use_hint_manager true
setprop debug.hwui.target_cpu_time_percent 100
setprop debug.hwui.target_gpu_time_percent 100
setprop debug.hwui.target_power_time_percent 100
setprop debug.cpuprio 7
setprop debug.gpuprio 7
setprop debug.ioprio 7
setprop debug.renderthread.reduceopstasksplitting true
setprop debug.heat_suppression 0
setprop debug.dev.ssrm.turbo true
settings put system pointer_speed 7
settings put system touch_pressure_scale 0.001
settings put secure multi_press_timeout 50
settings put secure long_press_timeout 70
settings put system view.scroll_friction 10
settings put global low_power 0
settings put global low_power_sticky 0
settings put global app_standby_enabled 0
settings put global forced_app_standby_enabled 0
# Keep screen on during gaming (optional)
# settings put system screen_off_timeout 2147483647
# Aggressive process caching
settings put global activity_manager_constants max_cached_processes 64
settings put global max_phantom_processes 2147483647
# Disable background restrictions
settings put global background_limit 0
settings put global app_standby_bucket 10
settings put global windowmgr_transition_animation_scale 0.0
settings put global animator_duration_scale 0.0
settings put global transition_animation_scale 0.0
setprop debug.sf.showfps 0
setprop debug.hwui.show_dirty_regions false
setprop debug.hwui.fps_divisor 1
setprop debug.sf.enable_hwc_vds 0
setprop debug.hwc.disabletonemapping true
setprop debug.sf.enable_gl_backpressure 0
setprop debug.game_driver_performance 1
setprop debug.rs.default-CPU-buffer 262144
setprop debug.gralloc.gfx_ubwc_disable false
setprop debug.gr.swapinterval 0
setprop debug.hwui.renderer vulkan
setprop debug.sf.disable_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.performance.tuning 1
setprop debug.egl.swapinterval 0
setprop debug.egl.hw 1
setprop debug.sf.hw 1
setprop debug.composition.type gpu
setprop debug.overlayui.enable 0
setprop debug.mdpcomp.maxlayer 0
setprop debug.qc.hardware true
setprop debug.enable.sglscale 1
setprop debug.qctwa.preservebuf 1
setprop debug.cpurend.vsync false
setprop debug.gpurend.vsync false
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.fps_target --bind value:s:90
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.fps_lock --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.fps_cap --bind value:s:90
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.lock_fps --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.frame_rate_control --bind value:s:strict
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.vsync_mode --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.frame_pacing --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.graphics_quality --bind value:s:Low
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.resolution_scale --bind value:s:0.8
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.render_scale --bind value:s:0.8
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.shadow_quality --bind value:s:Off
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.shadow_resolution --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.texture_quality --bind value:s:Low
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.texture_filtering --bind value:s:Low
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.effect_quality --bind value:s:Low
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.particle_quality --bind value:s:Low
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.model_quality --bind value:s:Low
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.anti_aliasing --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.anisotropic_filtering --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.bloom_effect --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.motion_blur --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.depth_of_field --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.chromatic_aberration --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.lens_flare --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.ragdoll --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.decal_quality --bind value:s:Low
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.multi_core_rendering --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.gpu_accelerated --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.hardware_accelerated --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.render_thread_priority --bind value:s:high
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.gpu_priority --bind value:s:high
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.dynamic_resolution --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.adaptive_resolution --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.resolution_scaling --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.auto_adjust_quality --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.scaling_mode --bind value:s:performance
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.triple_buffering --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.buffer_count --bind value:s:2
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.prediction_enabled --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.async_loading --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.low_latency_mode --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.ultra_low_latency --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.touch_boost --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.touch_response --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.input_latency --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.input_delay --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.high_priority_input --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.input_thread_priority --bind value:s:realtime
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.touch_sampling_rate --bind value:s:high
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.gyroscope_latency --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.pointer_speed --bind value:s:fast
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.memory_optimize --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.aggressive_memory --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.cache_clear_on_launch --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.cache_clear_interval --bind value:s:60
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.aggressive_gc --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.gc_interval --bind value:s:30
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.cpu_affinity --bind value:s:performance_cores
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.cpu_governor --bind value:s:performance
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.thread_priority --bind value:s:high
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.process_priority --bind value:s:high
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.background_limit --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.memory_compaction --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.thermal_throttle --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.thermal_limit --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.power_save_mode --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.battery_saver --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.high_performance_mode --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.performance_mode --bind value:s:maximum
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.boost_mode --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.sustained_performance --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.cpu_boost --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.gpu_boost --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.net_optimize --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.low_ping_mode --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.network_priority --bind value:s:high
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.netcode_optimization --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.latency_compensation --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.packet_optimization --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.bandwidth_priority --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.audio_quality --bind value:s:Low
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.audio_buffer_size --bind value:s:low
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.spatial_audio --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.3d_audio --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.audio_effects --bind value:s:0
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.audio_thread_priority --bind value:s:low
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.stability_mode --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.anti_lag --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.smooth_frame --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.frame_stabilizer --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.jitter_reduction --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.stutter_fix --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.fps_stabilizer --bind value:s:1
content insert --uri content://settings/global --bind name:s:com.garena.game.codm.drop_frame_prevention --bind value:s:1
cmd notification post -I /sdcard/CODM/banner.png -S bigtext -t '🤖 CODM' 'Tag' "Active" > /dev/null 2>&1