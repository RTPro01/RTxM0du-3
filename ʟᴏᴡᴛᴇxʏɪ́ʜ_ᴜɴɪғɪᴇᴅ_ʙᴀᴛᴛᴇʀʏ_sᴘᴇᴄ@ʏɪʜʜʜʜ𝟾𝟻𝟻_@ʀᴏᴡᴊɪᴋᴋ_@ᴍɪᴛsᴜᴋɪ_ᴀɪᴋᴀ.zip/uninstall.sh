#!/system/bin/sh
# LowTexYiH Unified Battery_Spec Module Increase Battery health endurance Stability
# Combines system, accessibility, network, display, battery, thermal, and game overlay tweaks
# Developer #@Yihhhh855 @rowjikk @mitsuki.aika_ // https://t.me/+UrKw18bS1tNkZjZl
# Module Creator: @Yihhhh855 
# Developer Code Source: @rowjikk @mitsuki.aika_ ty guyss ⊂⁠(⁠◉⁠‿⁠◉⁠)⁠つ

LOG="/sdcard/LowTexYiH_Unified_Battery_Spec-reset.log"

timestamp() { date '+%Y-%m-%d %H:%M:%S'; }
log() { echo "[ $(timestamp) ] [INFO] $1" | tee -a "$LOG"; }
info() { echo "[ $(timestamp) ] [INFO] $1" | tee -a "$LOG"; }   # <-- added
success() { echo "[ $(timestamp) ] [SUCCESS] $1" | tee -a "$LOG"; }

#@Yihh855 @rowjikk @mitsuki.aika_ / https://t.me/+UrKw18bS1tNkZjZl
section() {
  echo ""
  echo "────────────────────────────────────────" | tee -a "$LOG"
  echo "--- $1 ---" | tee -a "$LOG"
  echo "────────────────────────────────────────" | tee -a "$LOG"
}

#@Yihh855 @rowjikk @mitsuki.aika_ / https://t.me/+UrKw18bS1tNkZjZl
section "Remove Game Overlay"
GAMES=$(cmd package list packages -3 | cut -f2 -d:)
for app in $GAMES; do
  [ -z "$app" ] && continue
  if dumpsys game | grep -q "$app"; then
      info "Removing overlay from $app"
      cmd game reset "$app"
  fi
done
success "All game overlays removed"

#@Yihh855 @rowjikk @mitsuki.aika_ / https://t.me/+UrKw18bS1tNkZjZl
section "Reset Accessibility / Input Services"
cmd accessibility start-trace
cmd input_method tracing start
cmd voiceinteraction set-debug-hotword-logging true
am set-stop-user-on-switch false
success "Accessibility / Input reset applied"

#@Yihh855 @rowjikk @mitsuki.aika_ / https://t.me/+UrKw18bS1tNkZjZl
section "Reset Wi-Fi / Connectivity"
cmd wifi set-scan-always-available enabled
cmd wifi set-verbose-logging disable
cmd connectivity set-chain3-enabled true
success "Wi-Fi / Connectivity reset applied"

#@Yihh855 @rowjikk @mitsuki.aika_ / https://t.me/+UrKw18bS1tNkZjZl
section "Reset Display / Graphics"
cmd display set-user-disabled-hdr-types 0
cmd display ab-logging-enable
cmd display dmd-logging-enable
cmd display dwb-logging-enable
success "Display / Graphics reset applied"

#@Yihh855 @rowjikk @mitsuki.aika_ / https://t.me/+UrKw18bS1tNkZjZl
section "Reset Battery / Idle Settings"
settings delete global device_idle_constants
device_config delete device_idle inactive_to
device_config delete device_idle sensing_to
device_config delete device_idle locating_to
device_config delete device_idle location_accuracy
device_config delete device_idle motion_inactive_to
device_config delete device_idle idle_after_inactive_to
device_config delete device_idle idle_pending_to
device_config delete device_idle max_idle_pending_to
device_config delete device_idle idle_pending_factor
device_config delete device_idle idle_to
device_config delete device_idle max_idle_to
device_config delete device_idle idle_factor
device_config delete device_idle min_time_to_alarm
device_config delete device_idle max_temp_app_whitelist_duration
device_config delete device_idle wait_for_unlock
#@Yihh855 @rowjikk @mitsuki.aika_ / https://t.me/+UrKw18bS1tNkZjZl
device_config delete alarm_manager save_battery_on_idle
device_config delete alarm_manager power_check_interval
device_config delete alarm_manager min_futurity
#@Yihh855 @rowjikk @mitsuki.aika_ / https://t.me/+UrKw18bS1tNkZjZl
dumpsys batterystats --reset
dumpsys batterystats --reset-all
dumpsys batterystats enable full-history
dumpsys batterystats enable no-auto-reset
dumpsys batterystats disable pretend-screen-off
success "Battery / Idle reset applied"

#@Yihh855 @rowjikk @mitsuki.aika_ / https://t.me/+UrKw18bS1tNkZjZl
section "Reset Activity / Background / Power Constants"
settings delete global activity_manager_constants
settings delete global cached_apps_freezer
device_config delete activity_manager use_compaction
device_config delete activity_manager_native_boot use_freezer
success "Activity / Background / Power reset applied"

#@Yihh855 @rowjikk @mitsuki.aika_ / https://t.me/+UrKw18bS1tNkZjZl
section "Reset Logging / Stats"
settings delete global binder_calls_stats
settings delete global looper_stats
device_config delete settings_ui event_logging_enabled
device_config delete media media_metrics_mode
success "Logging / Stats reset applied"

#@Yihh855 @rowjikk @mitsuki.aika_ / https://t.me/+UrKw18bS1tNkZjZl
section "Reset Network / Wi-Fi tweaks"
settings delete global wifi_scan_always_enabled
settings delete global mobile_data_always_on
device_config delete tethering netstats_store_files_in_apexdata
device_config delete tethering netstats_import_legacy_target_attempts
success "Network / Wi-Fi reset applied"

#@Yihh855 @rowjikk @mitsuki.aika_ / https://t.me/+UrKw18bS1tNkZjZl
section "Reset Thermal"
cmd thermalservice override-status 1
success "Thermal reset applied"

#@Yihh855 @rowjikk @mitsuki.aika_ / https://t.me/+UrKw18bS1tNkZjZl
section "Reset I/O / App Launch optimization"
device_config delete runtime_native_boot iorap_readahead_enable
device_config delete runtime_native_boot iorap_perfetto_enable
device_config delete runtime_native use_app_image_startup_cache
success "I/O / App Launch reset applied"

#@Yihh855 @rowjikk @mitsuki.aika_ / https://t.me/+UrKw18bS1tNkZjZl
section "FINAL STATUS"
success "LowTexYiH Unified battery_spec reset"
echo "Reset script complete"