#!/system/bin/sh
# LowTexYiH Unified Battery_Spec Module Increase Battery health endurance Stability
# Combines system, accessibility, network, display, battery, thermal, and game overlay tweaks
# Developer #@Yihhhh855 @rowjikk @mitsuki.aika_ // https://t.me/+UrKw18bS1tNkZjZl
# Module Creator: @Yihhhh855 
# Developer Code Source: @rowjikk @mitsuki.aika_ ty guyss ⊂⁠(⁠◉⁠‿⁠◉⁠)⁠つ
LOG="/sdcard/LowTexYiH-Unified_Battery_Spec.log"

#@Yihhhh855 / https://t.me/+UrKw18bS1tNkZjZl
timestamp() { date '+%Y-%m-%d %H:%M:%S'; }
info()    { echo "[ $(timestamp) ] [INFO] $1" | tee -a "$LOG"; }
success() { echo "[ $(timestamp) ] [SUCCESS] $1" | tee -a "$LOG"; }
section() {
    echo ""
    echo "────────────────────────────────────────" | tee -a "$LOG"
    echo "[-- $1 --]" | tee -a "$LOG"
    echo "────────────────────────────────────────" | tee -a "$LOG"
}

#@Yihhhh855 / https://t.me/+UrKw18bS1tNkZjZl
section "DEVICE PROFILE"

RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 1500000)
ANDROID_VER=$(getprop ro.build.version.release)
ANDROID_VER_INT=$(echo "$ANDROID_VER" | cut -d. -f1)

#@Yihhhh855 / https://t.me/+UrKw18bS1tNkZjZl
if [ "$RAM_KB" -ge 8000000 ] && [ "$CPU_MAX_FREQ" -ge 2600000 ]; then
    DOWNSCALE="0.55"
elif [ "$RAM_KB" -ge 6000000 ]; then
    DOWNSCALE="0.51"
elif [ "$RAM_KB" -ge 4000000 ]; then
    DOWNSCALE="0.46"
else
    DOWNSCALE="0.44"
fi

FPS_SET=90
info "Balanced Mode | RAM: $RAM_KB KB | CPU: $CPU_MAX_FREQ Hz | Downscale=$DOWNSCALE | FPS=$FPS_SET"

#@Yihhhh855 / https://t.me/+UrKw18bS1tNkZjZl
section "APPLY GAME OVERLAY TO INSTALLED APPS"
GAMES=$(cmd package list packages --user 0 | cut -f2 -d:)
for app in $GAMES; do
    [ -z "$app" ] && continue
    if dumpsys game | grep -q "$app"; then
        info "Applying overlay to $app [ + ]"
        if [ "$ANDROID_VER_INT" -ge 12 ]; then
            cmd game set --mode 1 --downscale $DOWNSCALE --fps $FPS_SET "$app"
            cmd game mode 1 "$app"
        fi
    fi
done

#code source @rowjikk @mitsuki.aika_
section "Accessibility / Input Services"
cmd accessibility stop-trace
cmd stats clear-puller-cache
am set-stop-user-on-switch true
am clear-watch-heap all
am untrack-associations
cmd input_method tracing stop
cmd voiceinteraction set-debug-hotword-logging false
success "Accessibility / Input tweaks applied"

#code source @rowjikk @mitsuki.aika_
section "Wi-Fi / Connectivity"
cmd wifi set-scan-always-available disabled
cmd wifi set-verbose-logging disabled
cmd connectivity set-chain3-enabled false
success "Wi-Fi / Connectivity tweaks applied"

#code source @rowjikk @mitsuki.aika_
section "Display / Graphics"
cmd display set-user-disabled-hdr-types 1 2 3 4
cmd display ab-logging-disable
cmd display dmd-logging-disable
cmd display dwb-logging-disable
success "Display / Graphics tweaks applied"

#code source @rowjikk @mitsuki.aika_
section "Device Idle Constants"
settings put global device_idle_constants "inactive_to=5000,sensing_to=0,locating_to=0,location_accuracy=0,motion_inactive_to=0,idle_after_inactive_to=0,idle_pending_to=60000,max_idle_pending_to=120000,idle_pending_factor=2,idle_to=900000,max_idle_to=86400000,idle_factor=2,min_time_to_alarm=600000,max_temp_app_whitelist_duration=10000,wait_for_unlock=false"
success "Global device_idle_constants applied"
#code source @rowjikk @mitsuki.aika_
section "Device Idle - inactive_to"
device_config put device_idle inactive_to 5000
success "device_idle inactive_to applied"
#code source @rowjikk @mitsuki.aika_
section "Device Idle - sensing_to"
device_config put device_idle sensing_to 0
success "device_idle sensing_to applied"
#code source @rowjikk @mitsuki.aika_
section "Device Idle - locating_to"
device_config put device_idle locating_to 0
success "device_idle locating_to applied"
#code source @rowjikk @mitsuki.aika_
section "Device Idle - location_accuracy"
device_config put device_idle location_accuracy 0
success "device_idle location_accuracy applied"
#code source @rowjikk @mitsuki.aika_
section "Device Idle - motion_inactive_to"
device_config put device_idle motion_inactive_to 0
success "device_idle motion_inactive_to applied"
#code source @rowjikk @mitsuki.aika_
section "Device Idle - idle_after_inactive_to"
device_config put device_idle idle_after_inactive_to 0
success "device_idle idle_after_inactive_to applied"
#code source @rowjikk @mitsuki.aika_
section "Device Idle - idle_pending_to"
device_config put device_idle idle_pending_to 60000
success "device_idle idle_pending_to applied"
#code source @rowjikk @mitsuki.aika_
section "Device Idle - max_idle_pending_to"
device_config put device_idle max_idle_pending_to 120000
success "device_idle max_idle_pending_to applied"
#code source @rowjikk @mitsuki.aika_
section "Device Idle - idle_pending_factor"
device_config put device_idle idle_pending_factor 2
success "device_idle idle_pending_factor applied"
#code source @rowjikk @mitsuki.aika_
section "Device Idle - idle_to"
device_config put device_idle idle_to 900000
success "device_idle idle_to applied"
#code source @rowjikk @mitsuki.aika_
section "Device Idle - max_idle_to"
device_config put device_idle max_idle_to 86400000
success "device_idle max_idle_to applied"
#code source @rowjikk @mitsuki.aika_
section "Device Idle - idle_factor"
device_config put device_idle idle_factor 2
success "device_idle idle_factor applied"
#code source @rowjikk @mitsuki.aika_
section "Device Idle - min_time_to_alarm"
device_config put device_idle min_time_to_alarm 600000
success "device_idle min_time_to_alarm applied"
#code source @rowjikk @mitsuki.aika_
section "Device Idle - max_temp_app_whitelist_duration"
device_config put device_idle max_temp_app_whitelist_duration 10000
success "device_idle max_temp_app_whitelist_duration applied"
#code source @rowjikk @mitsuki.aika_
section "Device Idle - wait_for_unlock"
device_config put device_idle wait_for_unlock false
success "device_idle wait_for_unlock applied"
#code source @rowjikk @mitsuki.aika_
#code source @rowjikk @mitsuki.aika_
section "Alarm Manager - save_battery_on_idle"
device_config put alarm_manager save_battery_on_idle true
success "Alarm manager save_battery_on_idle applied"
#code source @rowjikk @mitsuki.aika_
section "Alarm Manager - power_check_interval"
device_config put alarm_manager power_check_interval 300000
success "Alarm manager power_check_interval applied"
#code source @rowjikk @mitsuki.aika_
section "Alarm Manager - min_futurity"
device_config put alarm_manager min_futurity 1000
success "Alarm manager min_futurity applied"
#code source @rowjikk @mitsuki.aika_
#code source @rowjikk @mitsuki.aika_
section "Activity / Background / Power Constants"
settings put global activity_manager_constants "power_check_max_cpu_1=0,power_check_max_cpu_2=0,power_check_max_cpu_3=0,power_check_max_cpu_4=0,full_pss_min_interval=216000000,full_pss_lowered_interval=216000000,kill_bg_restricted_cached_idle=true,low_swap_threshold_percent=60,proactive_kills_enabled=true,system_exempt_power_restrictions_enabled=true,kill_bg_restricted_cached_idle_settle_time=10000"
settings put global cached_apps_freezer 1
device_config put activity_manager use_compaction true
device_config put activity_manager_native_boot use_freezer true
success "Activity / Background / Power tweaks applied"

#code source @rowjikk @mitsuki.aika_
section "Logging / Stats"
settings put global binder_calls_stats "sampling_interval=600000000,detailed_tracking=disable,enabled=false,upload_data=false"
settings put global looper_stats 0
device_config put settings_ui event_logging_enabled false
device_config put media media_metrics_mode 0
success "Logging / Stats tweaks applied"

#code source @rowjikk @mitsuki.aika_
section "Network / Wi-Fi tweaks"
settings put global wifi_scan_always_enabled 0
settings put global mobile_data_always_on 0
device_config put tethering netstats_store_files_in_apexdata false
device_config put tethering netstats_import_legacy_target_attempts 0
success "Network / Wi-Fi tweaks applied"

#code source @rowjikk @mitsuki.aika_
section "Thermal tweaks"
cmd thermalservice override-status 0
success "Thermal tweaks applied"

#code source @rowjikk @mitsuki.aika_
section "I/O / App Launch optimization"
device_config put runtime_native_boot iorap_readahead_enable true
device_config put runtime_native_boot iorap_perfetto_enable false
device_config put runtime_native use_app_image_startup_cache true
success "I/O / App Launch optimization applied"

#code source @rowjikk @mitsuki.aika_
section "MODULE DEVELOPER @Yihhhh855"
section "DEVELOPER S_CODE  @rowjikk @mitsuki.aika_"
success "LowTexYiH battery_spec applied successfully"
echo "Unified service script complete"