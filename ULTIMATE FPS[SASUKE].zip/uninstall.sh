#!/system/bin/sh
# ============================================================
# POWER BY SASUKETWEAKS
# NON-ROOT OPTIMIZATION UNINSTALLER / REVERT SCRIPT
# ============================================================

echo " "
echo "══════════════════════════════════════════════════════════"
echo "      [🔄] REVERTING NON-ROOT OPTIMIZATIONS [🔄]          "
echo "══════════════════════════════════════════════════════════"
echo " "

# ============================================================
# RESTORE DISPLAY STABILITY
# ============================================================
echo "[🔄] RESTORING DISPLAY SETTINGS..."

# Restore Refresh Rate to Default (Auto)
settings put system peak_refresh_rate 120.0
settings put system min_refresh_rate 0.0
settings put system user_refresh_rate 0.0

# Re-enable Seamless Refresh Rate Switching
settings put global seamless_refresh_rate_switching 1

# Restore Default Refresh Rate Setting
settings delete global force_refresh_rate 2>/dev/null

# Restore Display Power Save
settings put global display_auto_brightness_stable_threshold 0.0

# ============================================================
# RESTORE ANIMATION LAG
# ============================================================
echo "[🔄] RESTORING UI ANIMATIONS..."

# Restore Animation Scale to Default (1.0x)
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0

# Restore Transition Animation Default
settings put global window_animation_scale_default 1.0

# ============================================================
# RESTORE PERFORMANCE MODE (DEFAULT)
# ============================================================
echo "[🔄] RESTORING SYSTEM POWER SETTINGS..."

# Disable Game Mode Features
settings put global game_mode_enabled 0
settings put global game_mode_stats_enabled 0

# Restore Balanced/Battery Mode
settings put global performance_mode_enabled 0
settings delete global battery_saver_mode_enabled 2>/dev/null
settings delete global low_power_mode 2>/dev/null

# Re-enable Adaptive Battery
settings put global adaptive_battery_management_enabled 1
settings put global app_standby_enabled 1

# Disable Forced GPU Rendering
settings put global force_gpu_rendering 0
settings put global hardware_acceleration_enabled 1

# ============================================================
# RESTORE NETWORK SETTINGS
# ============================================================
echo "[🔄] RESTORING NETWORK SETTINGS..."

# Reset Private DNS to Off or Automatic
settings put global private_dns_mode off
settings delete global private_dns_specifier 2>/dev/null

# Reset Network Preference
settings delete global network_preference 2>/dev/null

# ============================================================
# RESTORE BACKGROUND APP SETTINGS
# ============================================================
echo "[🔄] RESTORING BACKGROUND APP BEHAVIOR..."

# Restore Show Updates
settings put global show_non_rect_clip true
settings put global show_updates 1

# ============================================================
# RESTORE CODM APP SETTINGS
# ============================================================
echo "[🔄] RESTORING CODM APP DEFAULTS..."

# Set Game Mode to Default/Standard
cmd game_mode set com.garena.game.codm 0

# Reset Background Permissions
cmd appops set com.garena.game.codm RUN_IN_BACKGROUND ignore
cmd appops set com.garena.game.codm RUN_ANY_IN_BACKGROUND ignore

# Re-freeze/Reset Standby Bucket
am set-standby-bucket com.garena.game.codm rare

# Remove from Battery Whitelist
dumpsys deviceidle whitelist -com.garena.game.codm

# ============================================================
# RESTORE SCREEN FREEZE FIXES
# ============================================================
echo "[🔄] RESTORING DISPLAY RENDERING..."

# Re-enable Overlays
settings put global disable_overlays 0

# Re-enable Window Blurs
settings put system window_blurs_enabled 1

# Re-enable Screen Saver
settings put secure screensaver_enabled 1

# ============================================================
# FINAL CLEANUP
# ============================================================
echo " "
echo "══════════════════════════════════════════════════════════"
echo "      [✅] UNINSTALL COMPLETE [✅]                        "
echo "      [🔄] SYSTEM RESTORED TO DEFAULT                     "
echo "══════════════════════════════════════════════════════════"
echo " "