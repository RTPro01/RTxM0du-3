#!/system/bin/sh
# ============================================================
# POWER BY SASUKETWEAKS
# ALL-IN-ONE NON-ROOT RISKY OPTIMIZER + SKIAGL BOOST
# ============================================================

echo " "
echo "══════════════════════════════════════════════════════════"
echo "      [☢️] ALL-IN-ONE BOOST STARTED [☢️]                  "
echo "══════════════════════════════════════════════════════════"
echo " "

# ============================================================
# FORCE DISPLAY STABILITY
# ============================================================
echo "[✅] FORCING DISPLAY STABILITY..."

# Force Peak Refresh Rate (Keeps screen at high Hz)
settings put system peak_refresh_rate 60.0
settings put system min_refresh_rate 60.0
settings put system user_refresh_rate 60.0

# Disable Seamless Refresh Rate Switching
settings put global seamless_refresh_rate_switching 0

# Force Default Refresh Rate in Global Settings
settings put global force_refresh_rate 60

# Disable Power Save for Display
settings put global display_auto_brightness_stable_threshold 1.0

# ============================================================
# REMOVE ANIMATION LAG
# ============================================================
echo "[✅] REMOVING UI ANIMATION DELAY..."

# Set Animation Scale to 0 (Instant Transition)
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

# Disable Transition Animation
settings put global window_animation_scale_default 0

# ============================================================
# SUPER PERFORMANCE MODE (NON-ROOT)
# ============================================================
echo "[✅] ENABLING PERFORMANCE MODE..."

# Enable Game Mode Features (Android 12+)
settings put global game_mode_enabled 1
settings put global game_mode_stats_enabled 1

# Force Performance Mode via Settings
settings put global performance_mode_enabled 1
settings put global battery_saver_mode_enabled 0
settings put global low_power_mode 0

# Disable Adaptive Battery (Prevents app throttling)
settings put global adaptive_battery_management_enabled 0
settings put global app_standby_enabled 0

# Force GPU Rendering for UI (Reduces CPU load)
settings put global force_gpu_rendering 1
settings put global hardware_acceleration_enabled 1

# ============================================================
# NETWORK & PING OPTIMIZATION
# ============================================================
echo "[✅] OPTIMIZING NETWORK..."

# Enable Private DNS (Often helps with lag spikes if set to a fast DNS)
# (User can set this manually, but we try to force the setting)
settings put global private_dns_mode hostname
settings put global private_dns_specifier dns.google

# Disable Network Throttling
settings put global network_preference 4

# ============================================================
# 5. STOP BACKGROUND LAG SOURCES (NON-ROOT)
# ============================================================
echo "[✅] CLEARING BACKGROUND LAG..."

# Kill Background Services (Standard ADB command)
am kill-all

# Clear Cached Data (Attempt)
rm -rf /data/local/tmp/*.tmp 2>/dev/null

# Disable Show updates (Prevents overlay lag)
settings put global show_non_rect_clip false
settings put global show_updates 0

# ============================================================
# CODM FPS STABILIZER
# ============================================================
echo "[✅] STABLE FPS..."

# Set Game Mode to "Performance"
cmd game_mode set com.garena.game.codm 2

# Allow Game to run unrestricted
cmd appops set com.garena.game.codm RUN_IN_BACKGROUND allow
cmd appops set com.garena.game.codm RUN_ANY_IN_BACKGROUND allow
cmd appops set com.garena.game.codm COARSE_LOCATION allow

# Unfreeze App
cmd activity unfreeze com.garena.game.codm
am set-standby-bucket com.garena.game.codm active
dumpsys deviceidle whitelist +com.garena.game.codm

# ============================================================
# FIX SCREEN FREEZE
# ============================================================
echo "[✅]PREVENTING SCREEN FREEZE..."

settings put global disable_overlays 1
settings put system window_blurs_enabled 0
settings put secure screensaver_enabled 0

# ============================================================
# SKIAGL BOOST & STABILITY (NEW ADDITION)
# ============================================================
echo "[🧪] BOOSTING SKIAGL ENGINE..."

# Force SkiaGL Rendering Engine (Smoother UI & Game Rendering)
setprop persist.sys.ui.hw 1
setprop debug.hwui.renderer skiagl
setprop persist.vendor.sys.hwui.renderer skiagl
setprop debug.hwui.level 1
setprop debug.hwui.show_dirty_regions false
setprop debug.hwui.show_non_rect_clip false

# SkiaGL Thread Priority Boost
setprop debug.hwui.thread_prio 1
setprop debug.renderthread.priority RT:1

# Use Partial Updates for smoother scrolling
setprop debug.hwui.use_partial_updates true
setprop debug.hwui.disable_draw_defer false

# ============================================================
# AGGRESSIVE DEBLOAT (REMOVE LAG SOURCES)
# ============================================================
echo "[✔️] DISABLING BLOATWARE & LAG SERVICES..."

# Disable common System Bloat that runs in background
pm disable-user --user 0 com.google.android.apps.wellbeing 2>/dev/null # Digital Wellbeing (Laggy)
pm disable-user --user 0 com.google.android.apps.nbu.files 2>/dev/null # Google Files
pm disable-user --user 0 com.google.android.apps.tachyon 2>/dev/null # Google Duo
pm disable-user --user 0 com.google.android.videos 2>/dev/null
pm disable-user --user 0 com.google.android.music 2>/dev/null
pm disable-user --user 0 com.google.android.apps.magazines 2>/dev/null
pm disable-user --user 0 com.google.android.apps.photos 2>/dev/null # Photos (Heavy RAM)
# YouTube and Chrome KEPT as requested
pm disable-user --user 0 com.android.stk 2>/dev/null # Sim Toolkit
pm disable-user --user 0 com.android.providers.userdictionary 2>/dev/null
pm disable-user --user 0 com.android.wallpaperbackup 2>/dev/null
pm disable-user --user 0 com.android.wallpapercropper 2>/dev/null
pm disable-user --user 0 com.android.printspooler 2>/dev/null
pm disable-user --user 0 com.android.bluetoothmidiservice 2>/dev/null
pm disable-user --user 0 com.android.bookmarkprovider 2>/dev/null
pm disable-user --user 0 com.android.dreams.basic 2>/dev/null # Screensaver
pm disable-user --user 0 com.android.dreams.phototable 2>/dev/null # Screensaver
pm disable-user --user 0 com.android.managedprovisioning 2>/dev/null
pm disable-user --user 0 com.android.statementservice 2>/dev/null
pm disable-user --user 0 com.android.storagemanager 2>/dev/null

# Xiaomi/MIUI/HyperOS Specific Bloat
pm disable-user --user 0 com.miui.msa.global 2>/dev/null # Ads/Analytics
pm disable-user --user 0 com.miui.daemon 2>/dev/null # Data Collection
pm disable-user --user 0 com.xiaomi.mipicks 2>/dev/null
pm disable-user --user 0 com.miui.bugreport 2>/dev/null
pm disable-user --user 0 com.xiaomi.discover 2>/dev/null
pm disable-user --user 0 com.miui.video 2>/dev/null
pm disable-user --user 0 com.miui.player 2>/dev/null
pm disable-user --user 0 com.miui.screenrecorder 2>/dev/null
pm disable-user --user 0 com.xiaomi.midrop 2>/dev/null
pm disable-user --user 0 com.xiaomi.scanner 2>/dev/null
pm disable-user --user 0 com.miui.cloudservice 2>/dev/null
pm disable-user --user 0 com.miui.cloudbackup 2>/dev/null

# Samsung Specific Bloat
pm disable-user --user 0 com.samsung.android.app.spage 2>/dev/null # Bixby Home
pm disable-user --user 0 com.samsung.android.bixby.wakeup 2>/dev/null
pm disable-user --user 0 com.samsung.android.bixby.service 2>/dev/null
pm disable-user --user 0 com.sec.android.app.sbrowser 2>/dev/null
pm disable-user --user 0 com.samsung.android.mobileservice 2>/dev/null
pm disable-user --user 0 com.samsung.android.themestore 2>/dev/null
pm disable-user --user 0 com.samsung.android.mateagent 2>/dev/null
pm disable-user --user 0 com.samsung.klmsagent 2>/dev/null
pm disable-user --user 0 com.sec.android.widgetapp.samsungapps 2>/dev/null

# Generic Ads/Analytics
pm disable-user --user 0 com.facebook.appmanager 2>/dev/null
pm disable-user --user 0 com.facebook.services 2>/dev/null
pm disable-user --user 0 com.facebook.system 2>/dev/null
pm disable-user --user 0 com.oppo.market 2>/dev/null
pm disable-user --user 0 com.heytap.market 2>/dev/null

# ============================================================
# RISKY PERFORMANCE MODE (OVERHEAT ALLOWED)
# ============================================================
echo "[✔️] ENABLING PERFORMANCE MODE..."

# Force Power Mode
cmd power set-mode 0
settings put global performance_mode_enabled 1
settings put global game_mode_enabled 1
settings put global battery_saver_mode_enabled 0
settings put global low_power_mode 0
settings put global adaptive_battery_management_enabled 0
settings put global app_standby_enabled 0
settings put global battery_saver_constants ""
settings put global force_gpu_rendering 1
settings put global hardware_acceleration_enabled 1
settings put global disable_overlays 0
settings put global thermal_disabled 1
settings put global game_thermal_control_enabled 0
settings put global game_thermal_mode 2
settings put global seamless_refresh_rate_switching 0
settings put system smooth_movement 1
settings put global display_auto_brightness_stable_threshold 1.0

# ============================================================
# EXTREME FPS BOOSTER (NEW ADDITION)
# ============================================================
echo "[🚀] APPLYING EXTREME FPS BOOST..."

# System Frame Boost
setprop debug.sf.hw 1
setprop debug.egl.hw 1
setprop video.accelerate.hw 1
setprop debug.performance.tuning 1
setprop persist.sys.ui.hw 1

# Frame Pacing Stability
setprop debug.sf.latch_unsignaled 0
setprop debug.gr.num_buffers 4
setprop debug.gr.swapinterval 0
setprop persist.sys.sf.skip_frame_count 0

# Force 120Hz Refresh
settings put system user_refresh_rate 60
settings put system min_refresh_rate 60
settings put system peak_refresh_rate 60

# ============================================================
# SUPER SMOOTH UI (ZERO LAG)
# ============================================================
echo "[✔️] SMOOTHING INTERFACE..."

# Zero Animations
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0
settings put system window_blurs_enabled 0
settings put secure screensaver_enabled 0
settings put global show_non_rect_clip false
settings put global show_updates 0

# ============================================================
# CODM SPECIFIC TUNING
# ============================================================
echo "[✔️] TUNING CODM..."

# Kill everything before game starts
am kill-all

# High Priority for Game
cmd game_mode set com.garena.game.codm 2
cmd activity unfreeze com.garena.game.codm
am set-standby-bucket com.garena.game.codm exempted
cmd appops set com.garena.game.codm RUN_IN_BACKGROUND allow
cmd appops set com.garena.game.codm RUN_ANY_IN_BACKGROUND allow
dumpsys deviceidle whitelist +com.garena.game.codm
cmd game set --downscale 0.45 com.garena.game.codm
cmd game mode 1 com.garena.game.codm

# ============================================================
# RAM & CACHE CLEANER (NEW ADDITION)
# ============================================================
echo "[🧹] CLEANING RAM AND CACHE..."

# Clear System Cache
rm -rf /data/local/tmp/*.tmp 2>/dev/null
rm -rf /data/log 2>/dev/null
rm -rf /data/tombstones 2>/dev/null
rm -rf /data/anr 2>/dev/null
rm -rf /sdcard/.trash 2>/dev/null

# Clear App Caches (Non-Critical)
pm trim-caches 1G 2>/dev/null

# Aggressive RAM Cleaning
am kill-all
sync
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

# ============================================================
# SUPER EXTREME GAMING FLAGSHIP BOOST FPS 100% (RISKY)
# ============================================================
echo "[🔥] APPLYING SUPER EXTREME GAMING FLAGSHIP BOOST..."

# Disable Thermal Engine (CRITICAL RISK: Overheat)
setprop vendor.power.pasr.enabled false
setprop debug.thermal.enable 0
settings put global thermal_disabled 1

# Kernel & Scheduler Optimization (Flagship Tuning)
setprop debug.cpumeasurement.enable true
setprop persist.sys.kernel.scheduler performance
setprop debug.sched.group top-app
setprop sys.kill_bg_app_on_launch 1

# GPU Overclock/Boost Toggles (If supported by HAL)
setprop vendor.gpu.enable 1
setprop debug.composition.type gpu
setprop persist.sys.composition.type gpu
setprop debug.hwui.use_gpu_pixel_buffers true

# I/O Scheduler Optimization (Max Throughput)
setprop sys.io.scheduler deadline
setprop vendor.io.scheduler deadline

# Force High Performance GPU Frequency (Adreno/Mali)
echo "performance" > /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null
echo "performance" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor 2>/dev/null
echo "performance" > /sys/devices/system/cpu/cpufreq/policy4/scaling_governor 2>/dev/null
echo "performance" > /sys/devices/platform/soc/soc:qcom,cpu-boost/boost 2>/dev/null

# Disable HW VSYNC (Frees up resources, can cause tear)
setprop debug.hwui.disable_vsync true

# Aggressive LMK (Low Memory Killer) Tuning (Free RAM for Game)
setprop ro.lmk.kill_heaviest_task true
setprop ro.lmk.kill_timeout_ms 100
setprop ro.lmk.use_minfree_levels true

# Virtual Memory Optimization
setprop persist.sys.purgeable_assets 1
setprop persist.sys.use_dithering 0

# Priority Boost for Render Thread
setprop sys.gameThreadPriority -10

# ============================================================
# PERFORMANCE MAINTAINER (WORKS ALL THE TIME)
# ============================================================
echo "[🔄] STARTING PERFORMANCE MAINTAINER..."

# Loop to keep performance high (Runs in background)
(
    while true; do
        # Keep dropping cache every 5 minutes to prevent buildup
        sleep 300
        sync
        echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
        
        # Ensure game stays in high priority bucket
        am set-standby-bucket com.garena.game.codm exempted 2>/dev/null
        
        # Re-apply power mode if system resets it
        cmd power set-mode 1 2>/dev/null
    done
) &

# ============================================================
# FINAL OUTPUT
# ============================================================
echo " "
echo "══════════════════════════════════════════════════════════"
echo "      [✅] ALL-IN-ONE COMPLETE [✅]                       "
echo "      [🧪] SKIAGL BOOST ACTIVE                            "
echo "      [🔥] EXTREME FLAGSHIP BOOST ACTIVE                  "
echo "══════════════════════════════════════════════════════════"
echo " "