#!/system/bin/sh
# ===========================================================================
# CREATOR: t.me/SASUKEFILES
# ADMIN: @abujingjingkojing
# ===========================================================================

clear
echo "**********************************************************"
echo "*        ENABLE VULKAN RENDERING UNLOCK 120FPS         *"
echo "**********************************************************"
echo ""

# --------------------------------------------------------------------------
# AGGRESSIVE CACHE CLEANER
# --------------------------------------------------------------------------

# Set CODM to 'active' bucket
cmd appops set com.garena.game.codm RUN_IN_BACKGROUND allow
cmd appops set com.garena.game.codm RUN_ANY_IN_BACKGROUND allow
am set-standby-bucket com.garena.game.codm active

# Set Mobile Legends to 'Active' bucket
cmd appops set com.mobile.legends RUN_IN_BACKGROUND allow
cmd appops set com.mobile.legends RUN_ANY_IN_BACKGROUND allow
am set-standby-bucket com.mobile.legends active

echo [✅] AGGRESSIVE CACHE CLEANER..."
# Drop all filesystem caches to ensure fresh RAM
sync; sync; sync
sysctl -w vm.drop_caches 3

# Attempt to clean temporary system files
rm -rf /data/local/tmp/*.log 2>/dev/null
rm -rf /data/local/tmp/*.tmp 2>/dev/null
rm -rf /sdcard/Android/data/*.cache 2>/dev/null
rm -rf /sdcard/Android/obj 2>/dev/null

# Trim memory for all running processes immediately
am send-trim-memory 1 RUNNING_CRITICAL

# --------------------------------------------------------------------------
# SYSTEM KERNEL & VIRTUAL MEMORY TUNING
# --------------------------------------------------------------------------
echo "[✅] ENABLE VIRTUAL MEMORY TUNING..."

# Force immediate writeback of dirty pages to free up RAM
sync
sysctl -w vm.dirty_ratio 5
sysctl -w vm.dirty_background_ratio 3
sysctl -w vm.vfs_cache_pressure 50
sysctl -w vm.swappiness 10

# Attempt to drop clean caches (PageCache, dentries, inodes)
# This frees up RAM for game textures immediately
sysctl -w vm.drop_caches 3

# Compact memory to reduce fragmentation (improves stability)
sysctl -w vm.compact_memory 1

# Additional Kernel Tuning for Latency
sysctl -w kernel.sched_rt_runtime_us -1
sysctl -w kernel.sched_min_granularity_ns 10000000
sysctl -w kernel.sched_wakeup_granularity_ns 15000000

# --------------------------------------------------------------------------
# GPU & RENDERING PIPELINE OPTIMIZATION
# --------------------------------------------------------------------------
echo "[✅] BOOST PIPELINE RENDERING..."

# Disable standard Android UI lags
settings put global window_animation_scale 0.0
settings put global transition_animation_scale 0.0
settings put global animator_duration_scale 0.0

# Force GPU composition and VSYNC tuning
setprop debug.composition.type gpu
setprop debug.hwc.force_gpu_vsync 1
setprop debug.hwc.winupdate 1
setprop debug.performance.tune 1
setprop persist.sys.ui.hw 1

# Disable hardware overlays
setprop debug.hwc.overlay 0

# Vulkan Optimization Hints
setprop debug.vulkan.layers ""
setprop debug.vulkan.validation "false"

# Flagship Rendering Unlock
setprop debug.hwui.renderer vulkan
setprop debug.hwui.level 1
setprop debug.hwui.show_dirty_regions false
setprop debug.hwui.use_partial_updates false
setprop debug.egl.hw 1
setprop debug.egl.profiler 1
setprop debug.enabletr true
setprop persist.sys.ui.use_extensions 1
setprop video.accelerate.hw 1
setprop persist.sys.use_dithering 0
setprop persist.sys.purgeable_assets 1

# --------------------------------------------------------------------------
# VULKAN RENDERING & 120 FPS STABILITY (UPDATED)
# --------------------------------------------------------------------------
echo "[✅] ENABLE VULKAN RENDERING..."

# Force Vulkan usage where supported
setprop debug.vulkan.force_gpu 1
setprop persist.sys.vulkan_30fps 0
setprop persist.sys.vulkan.multiwindow 0
setprop debug.graphics.vulkan.layers ""

# Frame Pacing
setprop debug.hwui.frame_rate 120
setprop debug.hwui.filter_test_overhead 0
setprop debug.framebuffer.force_early_flush 1

# Fix FPS Drops caused by driver overhead
setprop debug.egl.hw 1
setprop debug.egl.profiler 1
setprop debug.egl.traceGpuCompletion 1
setprop debug.enabletr 1
setprop video.accelerate.hw 1

# Enable High Precision Graphics
setprop persist.sys.polygon_mode 1
setprop persist.ssa.native_games_support 1

# Reduce GPU Bottlenecks
# UPDATED: Allow max frame rate up to 120
setprop debug.hwc.max_framerate 120
setprop persist.sys.hwc.gpu_fencing 1

# Extra Vulkan Stability
setprop ro.hwui.vulkan_mode 1
setprop debug.vulkan.robustness 1

# --------------------------------------------------------------------------
# BOOSTING PERFORMANCE
# --------------------------------------------------------------------------
echo "[✅] OPTIMIZE PERFORMANCE..."

# Set performance mode hints (System specific, but safe to try)
setprop sys.game.mode 1
setprop vendor.power.pwrmode 1
setprop debug.performance 1

# Disable powersuspend (if kernel supports it)
echo "0" > /sys/kernel/debug/suspend/enabled 2>/dev/null

# Force Performance Governor Attempt
for cpu_path in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo "performance" > "$cpu_path" 2>/dev/null
done

# Disable Power Savings
setprop sys.sampling.profiler 1
setprop debug.enabletr 1
setprop persist.adb.trace 0
setprop ro.config.hw_quickpoweron true
setprop ro.config.hw_power_saving true
setprop power.saving.mode 0
setprop persist.power.smart 0

# --------------------------------------------------------------------------
# STABLE NETWORK
# --------------------------------------------------------------------------
echo "[✅] STABILITY NETWORK..."

# Enable TCP Low Latency mode
sysctl -w net.ipv4.tcp_low_latency 1
sysctl -w net.core.somaxconn 512

# Increase network buffer sizes for smoother throughput
sysctl -w net.core.rmem_max 262144
sysctl -w net.core.wmem_max 262144
sysctl -w net.core.rmem_default 65536
sysctl -w net.core.wmem_default 65536
sysctl -w net.ipv4.tcp_rmem '4096 87380 2097152'
sysctl -w net.ipv4.tcp_wmem '4096 65536 2097152'

# Disable TCP timestamps to reduce header overhead
sysctl -w net.ipv4.tcp_timestamps 0
sysctl -w net.ipv4.tcp_sack 1

# Additional Network Stability
sysctl -w net.ipv4.tcp_fack 1
sysctl -w net.ipv4.tcp_tw_reuse 1
sysctl -w net.ipv4.tcp_moderate_rcvbuf 1
sysctl -w net.core.netdev_max_backlog 5000
sysctl -w net.ipv4.tcp_no_metrics_save 1
sysctl -w net.ipv4.tcp_syncookies 1
sysctl -w net.ipv4.tcp_max_syn_backlog 2048

# --------------------------------------------------------------------------
# PROCESS PRIORITY & THREAD BOOSTING
# --------------------------------------------------------------------------
echo "[✅] BOOSTING CODM AND MLBB..."

# Set Call of Duty Mobile to 'Active' bucket (Highest priority)
cmd appops set com.garena.game.codm RUN_IN_BACKGROUND allow
cmd appops set com.garena.game.codm RUN_ANY_IN_BACKGROUND allow
am set-standby-bucket com.garena.game.codm active

# Set Mobile Legends to 'Active' bucket
cmd appops set com.mobile.legends RUN_IN_BACKGROUND allow
cmd appops set com.mobile.legends RUN_ANY_IN_BACKGROUND allow
am set-standby-bucket com.mobile.legends active

# --------------------------------------------------------------------------
# BACKGROUND CLEANER
# --------------------------------------------------------------------------
echo "[✅] CLEANING BACKGROUND..."

# Force stop resource-heavy background apps to reclaim RAM
am force-stop com.google.android.youtube
am force-stop com.google.android.apps.youtube.music
am force-stop com.spotify.music
am force-stop com.facebook.katana
am force-stop com.instagram.android
am force-stop com.snapchat.android
am force-stop com.whatsapp
am force-stop com.zhiliaoapp.musically
am force-stop com.ss.android.ugc.trill
am force-stop com.google.android.apps.maps
am force-stop com.android.chrome
am force-stop com.google.android.gm
am force-stop com.google.android.apps.photos
am force-stop com.google.android.tts
am force-stop com.google.android.googlequicksearchbox

# Trim memory for all running applications
am send-trim-memory 1 RUNNING_CRITICAL

# --------------------------------------------------------------------------
# SYSTEM INSTANT OPTIMIZATION
# --------------------------------------------------------------------------
echo "[✅] OPTIMIZING SYSTEM.."

# Broadcast a sticky intent that some game boosters listen for
am broadcast -a com.android.server.action.CPU_BOOST_START --es pkg com.garena.game.codm --ei duration 999999

# System Responsiveness
settings put global ro_kernel_android_checkjni 0
settings put global ro_kernel_checkjni 0
settings put global debug_checkjni 0
settings put global persist_android_strictmode 0
settings put global dalvik_vm_checkjni 0
settings put global dalvik_vm_execution_mode int:fast

# --------------------------------------------------------------------------
# FLAGSHIP GAMING UNLOCK
# --------------------------------------------------------------------------
echo "[✅] ENABLE FLAGSHIP ON SOME DEVICE.."

# Force High Performance Audio
setprop af.fast_track_multiplier 1
setprop af.resampler.quality 4
settings put system audio_offload_video_enabled 1

# Improve Touch Latency
settings put global input_latency_debug 0
settings put global input_device_mode 1

# Increase UI Rendering Priority
settings put global force_gpu_rendering 1

# Enable Hard Acceleration
setprop video.accelerate.hw 1
settings put global hardware_acceleration_enabled 1

# --------------------------------------------------------------------------
# 120 FPS STABILIZER (UPDATED)
# --------------------------------------------------------------------------
echo "[✅] STABLE FPS IN CODM AND MLBB..."

# Force 120Hz refresh rate
setprop debug.frame_rate 120
setprop persist.sys.frame_rate 120
setprop qemu.hw.mainkeys 0

# Enable OpenGL Clean Up
setprop debug.egl.cleanUpPendingBuffers 1

echo ""
echo "**********************************************************"
echo "*         OPTIMIZATION SUCCESSFULLY APPLIED              *"
echo "**********************************************************"