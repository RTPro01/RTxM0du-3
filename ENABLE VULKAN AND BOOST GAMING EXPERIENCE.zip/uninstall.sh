#!/system/bin/sh
# ===========================================================================
# SYSTEM REVERT & RESTORE SCRIPT
# Purpose: Undo all optimizations and restore default Android settings.
# Use this if you experience instability or want to return to normal mode.
# ===========================================================================

clear
echo "**********************************************************"
echo "*            SYSTEM RESTORATION INITIALIZED               *"
echo "*          REVERTING ALL PERFORMANCE TWEAKS               *"
echo "**********************************************************"
echo ""

# --------------------------------------------------------------------------
# SECTION 1: RESTORE KERNEL & MEMORY SETTINGS
# Goal: Return memory management to standard Android behavior.
# --------------------------------------------------------------------------
echo "[1/5] Restoring Kernel & Memory Settings..."

# Reset Swappiness to default (usually 60 or default device value)
sysctl -w vm.swappiness=60

# Reset Virtual File System Cache Pressure
sysctl -w vm.vfs_cache_pressure=100

# Reset Dirty Ratios
sysctl -w vm.dirty_ratio=20
sysctl -w vm.dirty_background_ratio=10

# Reset Kernel Scheduler Latency
sysctl -w kernel.sched_rt_runtime_us=950000
sysctl -w kernel.sched_min_granularity_ns=750000
sysctl -w kernel.sched_wakeup_granularity_ns=1000000

# --------------------------------------------------------------------------
# SECTION 2: RESTORE SYSTEM ANIMATIONS
# Goal: Bring back standard UI transitions and speeds.
# --------------------------------------------------------------------------
echo "[2/5] Restoring System Animations..."

# Set standard animation scales (1.0x or 0.5x depending on preference)
# Using 1.0 ensures standard behavior.
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0

# --------------------------------------------------------------------------
# SECTION 3: RESET NETWORK BUFFERS
# Goal: Restore standard TCP/IP stack configuration.
# --------------------------------------------------------------------------
echo "[3/5] Resetting Network Configuration..."

# Disable Forced Low Latency
sysctl -w net.ipv4.tcp_low_latency=0

# Reset Buffer Sizes to Standard
sysctl -w net.core.rmem_max=131071
sysctl -w net.core.wmem_max=131071
sysctl -w net.core.rmem_default=65535
sysctl -w net.core.wmem_default=65535
sysctl -w net.ipv4.tcp_rmem='4096 87380 174760'
sysctl -w net.ipv4.tcp_wmem='4096 16384 131072'

# Reset TCP Timestamps
sysctl -w net.ipv4.tcp_timestamps=1

# Reset Backlog
sysctl -w net.core.netdev_max_backlog=1000

# --------------------------------------------------------------------------
# SECTION 4: RESET SYSTEM PROPERTIES (FLAGS)
# Goal: Remove forced GPU/Performance flags.
# --------------------------------------------------------------------------
echo "[4/5] Clearing Performance Properties..."

# Reset GPU/Rendering Flags
setprop debug.composition.type ""
setprop debug.hwc.force_gpu_vsync 0
setprop debug.performance.tune 0
setprop persist.sys.ui.hw 0
setprop debug.hwui.renderer ""
setprop debug.hwui.level 0
setprop debug.egl.hw 0
setprop video.accelerate.hw 0

# Reset Vulkan Flags
setprop debug.vulkan.force_gpu 0
setprop debug.vulkan.layers ""
setprop debug.vulkan.validation ""

# Reset FPS Flags
setprop debug.hwui.frame_rate 0
setprop debug.hwc.max_framerate 0
setprop debug.frame_rate 0
setprop persist.sys.frame_rate 0

# Reset Power Modes
setprop sys.game.mode 0
setprop vendor.power.pwrmode 0
setprop power.saving.mode 1
setprop persist.power.smart 1

# Reset Input/Audio
setprop debug.input_latency 1
setprop af.fast_track_multiplier 0
setprop af.resampler.quality 0

# Reset CPU Governor (Attempt to restore to default 'schedutil' or 'interactive')
for cpu_path in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo "interactive" > "$cpu_path" 2>/dev/null
done

# --------------------------------------------------------------------------
# SECTION 5: CLEANUP & STABILIZE
# Goal: Final system sweep.
# --------------------------------------------------------------------------
echo "[5/5] Finalizing Restoration..."

# Kill any lingering CPU Boost broadcasts
am broadcast -a com.android.server.action.CPU_BOOST_STOP

# Release Pinned Apps (if supported)
am unpin com.garena.game.codm 2>/dev/null
am unpin com.mobile.legends 2>/dev/null

# Clear Caches to ensure a clean slate
sync
sysctl -w vm.drop_caches=3

echo ""
echo "**********************************************************"
echo "*           SYSTEM SUCCESSFULLY RESTORED                 *"
echo "**********************************************************"
echo "Your device has been reverted to default settings."
echo "Performance optimizations have been removed."
echo ""