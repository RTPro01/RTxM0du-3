#!/system/bin/sh
# LowTexYíH 6.2G
# #ano ?? nakaw naman haha naku dika kikita dyan boyyyy?!

log() {
    echo "[LowTexYíH 6.2G] $1"
}


while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

log "Boot complete. Applying LowTexYíH 6.2 tweaks..."

FPS=$(settings get system peak_refresh_rate 2>/dev/null || echo 120)
RAM_KB=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
CPU_CORES=$(nproc)
ANDROID_VER=$(getprop ro.build.version.release | cut -d. -f1)

log "RAM=${RAM_KB}KB | CORES=${CPU_CORES} | Android=${ANDROID_VER} | FPS=${FPS}"


setprop debug.hwui.use_fence_wait false
setprop debug.hwui.force_gpu_overdraw false
setprop debug.hwui.accelerated_linear false
setprop debug.hwui.defer_rendering true
setprop debug.sf.disable_hwc_vsync 1
setprop debug.sf.present_time_offset_us 1500

log "Graphics flags applied"


settings put global background_process_limit 3
settings put global low_ram_mode 1
settings put global activity_manager_constants "max_cached_processes=3,max_phantom_processes=5,background_settle_time=20000,force_bg_check_on_restricted=false"

log "System memory flags applied"


settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0
settings put system pointer_speed 7

log "Thermal & performance flags applied"


GAME_PACKAGE="com.garena.game.codm"

cmd appops set "$GAME_PACKAGE" RUN_ANY_IN_BACKGROUND allow
cmd appops set "$GAME_PACKAGE" RUN_IN_BACKGROUND allow
cmd appops set "$GAME_PACKAGE" WAKE_LOCK allow
cmd appops set "$GAME_PACKAGE" SYSTEM_ALERT_WINDOW allow
dumpsys deviceidle whitelist +"$GAME_PACKAGE"

downscale=0.5
fps_override=120


if [ "$ANDROID_VER" -ge 12 ]; then
    cmd game set --mode 2 --downscale "$downscale" --fps "$fps_override" "$GAME_PACKAGE"
fi


if [ "$ANDROID_VER" -ge 13 ]; then
    cmd device_config override game android.os.adpf_use_async_render true
    cmd device_config override game android.os.adpf_hwui_gpu true
    cmd device_config override game android.os.adpf_skip_surface_flinger_sync true
    log "Android 13+ advanced game flags applied"
fi

log "LowTexYíH 6.2G Applied"