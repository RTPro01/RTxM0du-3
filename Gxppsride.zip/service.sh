echo "======================================"
echo "   Start Instalation Plugin GxPride"
echo "======================================"
echo "   Developer : @ReiiEja"
echo "   List Project :"
echo "     - NoxG     | GVR"
echo "     - NoxVex   | GVR"
echo "     - Doxxel    | GV2R"
echo "     - Osiris     | GV2R | Prelease Development"
echo "     - GxPride   | AXM"
echo "======================================"
echo

# Welcome To My Service GxPride
# Source Colection By Kazuyoo, AOSP And DroidCmdX
# Thanks to Kazuyoo for allowing me to take some of his source code.

# For this code, I think it's good enough because I don't really like the code that is in the service section because I think it's only for important scripts.

cmd power set-fixed-performance-mode-enabled true
cmd power set-adaptive-power-saver-enabled false
cmd power set-mode 0
settings put global power_check_max_cpu_1 105
settings put global power_check_max_cpu_2 105
settings put global power_check_max_cpu_3 80
settings put global power_check_max_cpu_4 80
setprop debug.hwui.target_power_time_percent 100
setprop debug.hwui.trace_gpu_resources false
setprop debug.egl.force_msaa false
setprop debug.hwui.use_hint_manager 1
setprop debug.hwui.disable_vsync true
setprop debug.hwui.disable_scissor_opt true
setprop debug.performance.tuning 1
setprop debug.composition.type dyn
setprop debug.hwui.renderer vulkan
setprop debug.renderengine.backend skiavkthreaded
setprop debug.cpurend.vsync false

# render engine source by @Dcx400
setprop debug.renderengine.skia_atrace_enabled false
setprop debug.renderengine.skia_tracing_enabled false
setprop debug.renderengine.skia_use_perfetto_track_events false

# ignore delivery group policy | Scritp taken from the module CMDLite-(251028) By AOSP
for a in $(cmd package dump android|grep Action:|cut -f2 -d\"|sort|uniq);do
  cmd activity set-ignore-delivery-group-policy "$a"
done

#https://t.me/dcx402/114
device_config put activity_manager low_swap_threshold_percent 0.02

#https://t.me/dcx402/173
device_config put textclassifier smart_select_animation_enabled false

#https://t.me/dcx4020/29 (Disable App Profiler)
device_config put activity_manager disable_app_profiler_pss_profiling true

# jank monitor disable
device_config put interaction_jank_monitor enabled false
device_config put interaction_jank_monitor sampling_interval 99999999999999
device_config put interaction_jank_monitor trace_threshold_frame_time_millis -1
device_config put interaction_jank_monitor trace_threshold_missed_frames -1
device_config put activity_manager disable_app_profiler_pss_profiling true

cmd settings put system air_motion_engine 0
cmd settings put system master_motion 0
cmd settings put system motion_engine 0
setprop debug.cluster_little-set_his_speed $(cat /sys/devices/system/cpu/cpu1/cpufreq/cpuinfo_min_freq)
setprop debug.cluster_big-set_his_speed $(cat /sys/devices/system/cpu/cpu1/cpufreq/cpuinfo_max_freq)
setprop debug.powehint.cluster_little-set_his_speed $(cat /sys/devices/system/cpu/cpu1/cpufreq/cpuinfo_min_freq)
setprop debug.powehint.cluster_big-set_his_speed $(cat /sys/devices/system/cpu/cpu1/cpufreq/cpuinfo_max_freq)
cmd activity clear-debug-app
cmd activity clear-exit-info

# Disable DropBox Source By DroidCmdX
for tag in system_server system_server/Subject data_app_wtf storage_trim SYSTEM_BOOT SYSTEM_AUDIT system_server_wtf SYSTEM_LAST_KMSG; do cmd dropbox add-low-priority $tag; done; cmd dropbox set-rate-limit 99999999999999; settings put global dropbox_age_seconds 0; settings put global dropbox_max_files 0
  for process in "${PROCESS[@]}";do cmd dropbox add-low-priority "$process";done
  
  # Source By Celestial-Game-Opt [ AxM, KSU, Other ] 2.3-WebUI Owner Kazuyoo
  cmd devicestoragemonitor force-not-low
  cmd display set-match-content-frame-rate-pref 1
  cmd display set-user-disabled-hdr-types 1 2 3 4
  settings put global settings_enable_monitor_phantom_procs false
  settings put global app_standby_enabled 0
  
# Logcat
for log in $(getprop|cut -f1 -d']'|cut -f2 -d'['|grep -E '^(log\.tag\.|persist\.log\.)');do setprop "$log" "-";done

setprop persist.log.tag ""

logcat -c
logcat --wrap