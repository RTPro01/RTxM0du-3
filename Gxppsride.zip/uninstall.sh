# =========================================== #

#!/system/bin/sh
# === RESTORE PERFORMANCE MODE DEFAULT ===

# Power settings (balik normal)
cmd power set-fixed-performance-mode-enabled false
cmd power set-adaptive-power-saver-enabled true
cmd power set-mode 1  # balanced

# Thermal restore
cmd thermalservice override-status reset

# Hapus konfigurasi power_check custom
settings delete global power_check_max_cpu_1
settings delete global power_check_max_cpu_2
settings delete global power_check_max_cpu_3
settings delete global power_check_max_cpu_4

# HWUI dan EGL default
setprop debug.hwui.target_power_time_percent 0
setprop debug.hwui.trace_gpu_resources true
setprop debug.egl.force_msaa true
setprop debug.hwui.use_hint_manager 0
setprop debug.hwui.disable_vsync false
setprop debug.hwui.disable_scissor_opt false

# Performance tuning disable
setprop debug.performance.tuning 0
setprop debug.composition.type gpu

# Renderer default (OpenGL)
setprop debug.hwui.renderer opengl
setprop debug.renderengine.backend skiagl

# Disable custom vsync tweak
setprop debug.cpurend.vsync true

# ZRAM aktif kembali
settings put global zram_enabled 1

# Jank monitor restore
device_config delete interaction_jank_monitor enabled
device_config delete interaction_jank_monitor sampling_interval
device_config delete interaction_jank_monitor trace_threshold_frame_time_millis
device_config delete interaction_jank_monitor trace_threshold_missed_frames
device_config delete activity_manager disable_app_profiler_pss_profiling

# Motion system restore
cmd settings delete system air_motion_engine
cmd settings delete system master_motion
cmd settings delete system motion_engine

# Restore CPU power hint
setprop debug.cluster_little-set_his_speed ""
setprop debug.cluster_big-set_his_speed ""
setprop debug.powehint.cluster_little-set_his_speed ""
setprop debug.powehint.cluster_big-set_his_speed ""

# Bersihkan debug flag
cmd activity clear-debug-app
cmd activity clear-exit-info

echo "✅ Sistem telah dikembalikan ke mode default (remove mode sukses)"