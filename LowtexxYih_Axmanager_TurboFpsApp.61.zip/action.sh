#!/system/bin/sh

# LOWTEXYíH Beta testing v6.1
# Wla kana ma isip na file no? tamang copy paste nalang? haha 
# Developer: LowTexYíH @yih855

log() {
  echo "[LowTexYíH Beta v6.1] $1"
}




while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

log "Boot completed. Starting optimization..."




FPS=$(settings get system peak_refresh_rate 2>/dev/null || settings get system user_refresh_rate 2>/dev/null || echo 120)
RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 1500000)
ANDROID_VER=$(getprop ro.build.version.release)

log "Detected FPS: $FPS | RAM: $RAM_KB KB | CPU Max: $CPU_MAX_FREQ | Android: $ANDROID_VER"




if [ "$RAM_KB" -ge 8000000 ] && [ "$CPU_MAX_FREQ" -ge 2600000 ]; then
  DOWNSCALE=0.53
  CLASS="HIGH-END"
elif [ "$RAM_KB" -ge 6000000 ]; then
  DOWNSCALE=0.5
  CLASS="UPPER-MID"
elif [ "$RAM_KB" -ge 4000000 ]; then
  DOWNSCALE=0.48
  CLASS="MID"
else
  DOWNSCALE=0.48
  CLASS="LOW-END"
fi
log "Device class: $CLASS | Auto-selected downscaleFactor=$DOWNSCALE"




log "Disabling system animations..."
settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5





log "Optimizing display & memory..."
cmd activity memory-factor set 0 2>/dev/null
settings put global settings_enable_monitor_phantom_procs false
settings put global fstrim_mandatory_interval 1




log "Enabling touch boost..."
settings put secure long_press_timeout 180
settings put secure multi_press_timeout 200





log "Reducing thermal limits & disabling idle..."
setprop debug.thermal.throttle.support no 2>/dev/null




log "Applying SurfaceFlinger & HWUI optimizations..."
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.graphite_renderengine true
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.fp16_client_target true
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.multithreaded_present true
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.enable_layer_command_batching true
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.enable_small_area_detection true
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.allow_n_vsyncs_in_targeter true


setprop debug.stagefright.ccodec 4
setprop debug.sf.early_phase_offset_ns 500000
setprop debug.sf.late_phase_offset_ns 1500000
setprop debug.sf.frame_rate_multiple_threshold 60
setprop debug.hwui.render_dirty_regions false




log "Applying AUTO downscale & performance mode to installed games..."
for pkg in $(cmd package list packages -3 | cut -f2 -d:); do
  device_config put game_overlay "$pkg" mode=2,downscaleFactor=$DOWNSCALE,fps=90
  cmd game mode performance "$pkg"
  log "Applied to: $pkg | scale=$DOWNSCALE"
done




log "Optimizing Google packages..."
for a in $(cmd package list packages google | cut -f2 -d: | grep -v ia.mo); do
    cmd appops reset "$a"
    cmd appops set "$a" FOREGROUND_SERVICE_SPECIAL_USE ignore
    cmd appops set "$a" INSTANT_APP_START_FOREGROUND ignore
    cmd appops set "$a" RUN_ANY_IN_BACKGROUND ignore
    cmd appops set "$a" RUN_IN_BACKGROUND ignore
    cmd package revoke --all-permissions "$a"
done

log "Restoring essential Google Play Services permissions..."
cmd package grant com.google.android.gms android.permission.READ_CONTACTS
cmd package grant com.google.android.gms android.permission.WRITE_CONTACTS




if [ "$ANDROID_VER" -ge 11 ]; then
  log "Applying Android 11+ game flags..."
  cmd device_config override game android.os.adpf_prefer_power_efficiency false 2>/dev/null
  cmd device_config override game android.os.adpf_hwui_gpu true 2>/dev/null
fi





log "LowTexYíH Beta v6.1 applied successfully"