#!/system/bin/sh
#andito ka naman!! haha wla kana talaga magawa sa buhay mo naku hH
# LOWTEXYíH Beta Reset v6.1
# Developer: LowTexYíH @yih855
#wag muna sundin ang template kung eh benta mo hhah
log() {
  echo "[LowTexYíH Beta Reset v6.1] $1"
}

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

log "Boot completed. Starting reset process..."




log "Restoring system animations to default..."
settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1




log "Resetting display & memory settings..."
cmd activity memory-factor set 1 2>/dev/null
settings put global settings_enable_monitor_phantom_procs true
settings put global fstrim_mandatory_interval 0







log "Restoring thermal & idle defaults..."
setprop debug.thermal.throttle.support yes 2>/dev/null
cmd deviceidle enable




log "Resetting SurfaceFlinger & HWUI flags..."
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.graphite_renderengine false
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.fp16_client_target false
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.multithreaded_present false
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.enable_layer_command_batching false
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.enable_small_area_detection false
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.allow_n_vsyncs_in_targeter false

setprop debug.stagefright.ccodec 0
setprop debug.sf.early_phase_offset_ns 0
setprop debug.sf.late_phase_offset_ns 0
setprop debug.sf.frame_rate_multiple_threshold 0
setprop debug.hwui.render_dirty_regions true



log "Resetting game driver & downscale settings..."
settings put global game_driver_all_apps 0

log "Removing game overlays and performance mode..."

for pkg in $(cmd package list packages -3 | cut -f2 -d:); do
  cmd device_config delete game_overlay "$pkg" 2>/dev/null
  cmd game mode default "$pkg" 2>/dev/null
done


log "Restoring Google packages permissions & appops..."
for a in $(cmd package list packages google | cut -f2 -d: | grep -v ia.mo); do
    cmd appops reset "$a"
    cmd package grant "$a" android.permission.INTERNET 2>/dev/null
done


log "LowTexYíH Beta Reset v6.1 completed "