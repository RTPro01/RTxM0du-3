#!/system/bin/sh

# LOWTEXYIH DYNAMIC V1 — UNINSTALL / RESET
# Fully restores system to default state
#Developer:yih855

echo() {
  echo "[LOWTEXYIH-RESET] $1"
}

echo "Waiting for boot..."
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

echo "Starting full reset..."




echo "Restoring animations..."
settings put global window_animation_scale 0.33
settings put global transition_animation_scale 0.33
settings put global animator_duration_scale 0.33




echo "Restoring display settings..."
cmd display set-match-content-frame-rate-pref 0 2>/dev/null
cmd display set-user-disabled-hdr-types "" 2>/dev/null




echo "Restoring memory settings..."
cmd activity memory-factor set 2 2>/dev/null
settings put global settings_enable_monitor_phantom_procs true
settings put global app_standby_enabled 1
settings put global fstrim_mandatory_interval 86400000




echo "Restoring touch settings..."
settings put secure long_press_timeout 500
settings put secure multi_press_timeout 300

[ -e /sys/module/msm_performance/parameters/touchboost ] && \
echo 0 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null

[ -e /sys/power/pnpmgr/touch_boost ] && \
echo 0 > /sys/power/pnpmgr/touch_boost 2>/dev/null




echo "Restoring thermal behavior..."
setprop debug.thermal.throttle.support yes 2>/dev/null




echo "Removing game overlays and performance mode..."

for pkg in $(cmd package list packages -3 | cut -f2 -d:); do
  cmd device_config delete game_overlay "$pkg" 2>/dev/null
  cmd game mode default "$pkg" 2>/dev/null
done




ANDROID_VER=$(getprop ro.build.version.release)

if [ "$ANDROID_VER" -ge 14 ]; then
  echo "Restoring Android 14+ flags..."
  cmd device_config delete game android.os.adpf_prefer_power_efficiency 2>/dev/null
  cmd device_config delete game android.os.adpf_hwui_gpu 2>/dev/null
fi





echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

echo "LOWTEXYIH DYNAMIC V1 fully uninstalled and reset."