#!/system/bin/sh

LOG="/sdcard/LowTexYiH_CLOUD_CORE_UNINSTALL.log"

timestamp() { date '+%Y-%m-%d %H:%M:%S'; }
line() { echo "----------------------------------------" | tee -a "$LOG"; }
section() { echo ""; line; echo "$1 [ + ]" | tee -a "$LOG"; line; }
success() { echo "[ $(timestamp) ] SUCCESS: $1" | tee -a "$LOG"; }
info() { echo "[ $(timestamp) ] INFO: $1" | tee -a "$LOG"; }

section "START LowTexYíH CLOUD CORE UNINSTALL / RESET SERVICE"

# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "RESET WINDOW ANIMATION SCALE"
settings delete global window_animation_scale
success "window_animation_scale deleted [ + ]"

section "RESET TRANSITION ANIMATION SCALE"
settings delete global transition_animation_scale
success "transition_animation_scale deleted [ + ]"

section "RESET ANIMATOR DURATION SCALE"
settings delete global animator_duration_scale
success "animator_duration_scale deleted [ + ]"

# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "RESET SF USE PHASE OFFSETS"
resetprop -p debug.sf.use_phase_offsets_as_durations
success "use_phase_offsets_as_durations resetprop [ + ]"

section "RESET SF LATCH UNSIGNALED"
resetprop -p debug.sf.latch_unsignaled
success "latch_unsignaled resetprop [ + ]"

section "RESET SF GL BACKPRESSURE"
resetprop -p debug.sf.enable_gl_backpressure
success "enable_gl_backpressure resetprop [ + ]"

section "RESET SF EARLY PHASE OFFSET"
resetprop -p debug.sf.early_phase_offset_ns
success "early_phase_offset_ns resetprop [ + ]"

section "RESET SF LATE PHASE OFFSET"
resetprop -p debug.sf.late_phase_offset_ns
success "late_phase_offset_ns resetprop [ + ]"

# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "RESET MEMORY & BACKGROUND FLAGS"
settings delete global settings_enable_monitor_phantom_procs
settings delete global app_standby_enabled
cmd activity memory-factor set 1 2>/dev/null
success "Memory & background flags deleted [ + ]"

# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "DISABLE TOUCH BOOST MODULE"
[ -e /sys/module/msm_performance/parameters/touchboost ] && \
echo 0 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null
[ -e /sys/power/pnpmgr/touch_boost ] && \
echo 0 > /sys/power/pnpmgr/touch_boost 2>/dev/null
success "Touch boost disabled [ + ]"

# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "RESET SURFACEFLINGER & HWUI FLAGS"
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.multithreaded_present false
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.enable_layer_command_batching false
cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.allow_n_vsyncs_in_targeter false
cmd device_config override core_graphics com.android.graphics.hwui.flags.clip_shader false
cmd device_config override core_graphics com.android.graphics.hwui.flags.draw_region true
success "SurfaceFlinger & HWUI flags reset [ + ]"

# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "RESET ADPF SETTINGS"
cmd device_config override game android.os.adpf_hwui_gpu false
cmd device_config override game android.os.adpf_measure_during_input_event_boost false
cmd device_config override game android.os.adpf_prefer_power_efficiency true
success "ADPF flags reset [ + ]"

# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "DISABLE GAME DRIVER FOR ALL APPS"
settings delete global game_driver_all_apps
success "Game driver deleted [ + ]"

section "REMOVE GAME OVERLAY FROM APPS"
GAMES=$(cmd package list packages -3 | cut -f2 -d:)
for app in $GAMES; do
  [ -z "$app" ] && continue
  if dumpsys game | grep -q "$app"; then
      info "Removing overlay from $app [ + ]"
      cmd game reset "$app"
  fi
done

# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "DELETE LOWTEX LOG FILES"
rm -f /sdcard/Lowtexyih_cloud_core.log.log
rm -f /sdcard/LowTexYiH_CLOUD_CORE_UNINSTALL.log
success "All LowTex logs deleted [ + ]"

# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "DELETE SCRIPT FILE"
SCRIPT_PATH=$(realpath "$0" 2>/dev/null || echo "$0")
rm -f "$SCRIPT_PATH"
success "Uninstall script removed itself [ + ]"

# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "FINAL STATUS"
success "LowTexYíH cloud core  uninstalled [ + ]"