#!/system/bin/sh
#@Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
LOG="/sdcard/Lowtexyih_cloud_core.log"

# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
timestamp() { date '+%Y-%m-%d %H:%M:%S'; }
line() { echo "----------------------------------------" | tee -a "$LOG"; }
section() {
    echo "" | tee -a "$LOG"
    line
    echo "$1 [ + ]" | tee -a "$LOG"
    line
}
success() { echo "[ $(timestamp) ] SUCCESS: $1" | tee -a "$LOG"; }
info()    { echo "[ $(timestamp) ] INFO: $1"    | tee -a "$LOG"; }

# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "START LowTexYíH CLOUD CORE GAME SERVICE"

# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "BOOT CHECK"
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done
sleep 6
success "Boot completed [ + ]"

# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "DEVICE PROFILING"
RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 1500000)
ANDROID_VER=$(getprop ro.build.version.release)
ANDROID_VER_INT=$(echo $ANDROID_VER | cut -d. -f1)
FPS=$(settings get system peak_refresh_rate 2>/dev/null || settings get system user_refresh_rate 2>/dev/null || echo 120)
FPS_INT=$(printf "%.0f" "$FPS")

#  NEW CODE *Device Class + Downscale + Fps # @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
if [ "$RAM_KB" -ge 8000000 ] && [ "$CPU_MAX_FREQ" -ge 2600000 ]; then
    DOWNSCALE="0.5"; CLASS="HIGH-END"; FPS_SET=120
elif [ "$RAM_KB" -ge 6000000 ]; then
    DOWNSCALE="0.48"; CLASS="UPPER-MID"; FPS_SET=120
elif [ "$RAM_KB" -ge 4000000 ]; then
    DOWNSCALE="0.45"; CLASS="MID"; FPS_SET=120
else
    DOWNSCALE="0.43"; CLASS="LOW-END"; FPS_SET=120
fi

info "FPS: $FPS | RAM: $RAM_KB | CPU: $CPU_MAX_FREQ | Android: $ANDROID_VER [ + ]"
success "Device class: $CLASS | downscaleFactor=$DOWNSCALE [ + ]"

# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "WINDOW ANIMATION SCALE"
settings put global window_animation_scale 0
success "window_animation_scale set to 0 [ + ]"

section "TRANSITION ANIMATION SCALE"
settings put global transition_animation_scale 0
success "transition_animation_scale set to 0 [ + ]"

section "ANIMATOR DURATION SCALE"
settings put global animator_duration_scale 0
success "animator_duration_scale set to 0 [ + ]"

# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "SF USE PHASE OFFSETS AS DURATIONS"
setprop debug.sf.use_phase_offsets_as_durations 1
success "use_phase_offsets_as_durations enabled [ + ]"

section "SF LATCH UNSIGNALED"
setprop debug.sf.latch_unsignaled 1
success "latch_unsignaled enabled [ + ]"

section "SF GL BACKPRESSURE"
setprop debug.sf.enable_gl_backpressure 1
success "enable_gl_backpressure enabled [ + ]"

section "SF EARLY PHASE OFFSET"
setprop debug.sf.early_phase_offset_ns 500000
success "early_phase_offset_ns applied [ + ]"

section "SF LATE PHASE OFFSET"
setprop debug.sf.late_phase_offset_ns 1500000
success "late_phase_offset_ns applied [ + ]"

section "MATCH CONTENT FRAME RATE"
cmd display set-match-content-frame-rate-pref 1 2>/dev/null
success "match_content_frame_rate enabled [ + ]"

section "DISABLE HDR TYPES"
cmd display set-user-disabled-hdr-types 1 2 3 4 2>/dev/null
success "HDR types disabled [ + ]"

# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "ACTIVITY MEMORY FACTOR"
cmd activity memory-factor set 0 2>/dev/null
success "memory-factor set to 0 [ + ]"

section "PHANTOM PROCESS MONITOR"
settings put global settings_enable_monitor_phantom_procs false
success "phantom process monitor disabled [ + ]"

section "APP STANDBY"
settings put global app_standby_enabled 0
success "app standby disabled [ + ]"

# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "LONG PRESS TIMEOUT"
settings put secure long_press_timeout 180
success "long_press_timeout optimized [ + ]"

section "MULTI PRESS TIMEOUT"
settings put secure multi_press_timeout 200
success "multi_press_timeout optimized [ + ]"

section "TOUCH BOOST MODULE"
[ -e /sys/module/msm_performance/parameters/touchboost ] && \
echo 1 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null
[ -e /sys/power/pnpmgr/touch_boost ] && \
echo 1 > /sys/power/pnpmgr/touch_boost 2>/dev/null
success "Touch boost applied [ + ]"

# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "SURFACEFLINGER MULTITHREADED PRESENT"
cmd device_config override core_graphics \
com.android.graphics.surfaceflinger.flags.multithreaded_present true
success "multithreaded_present enabled [ + ]"

section "SURFACEFLINGER LAYER COMMAND BATCHING"
cmd device_config override core_graphics \
com.android.graphics.surfaceflinger.flags.enable_layer_command_batching true
success "layer_command_batching enabled [ + ]"

section "SURFACEFLINGER VSYNC TARGETER"
cmd device_config override core_graphics \
com.android.graphics.surfaceflinger.flags.allow_n_vsyncs_in_targeter true
success "vsync targeter optimized [ + ]"

section "HWUI CLIP SHADER"
cmd device_config override core_graphics \
com.android.graphics.hwui.flags.clip_shader true
success "clip_shader enabled [ + ]"

section "HWUI DRAW REGION"
cmd device_config override core_graphics \
com.android.graphics.hwui.flags.draw_region false
success "draw_region disabled [ + ]"

# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "ADPF HWUI GPU"
cmd device_config override game android.os.adpf_hwui_gpu true
success "adpf_hwui_gpu enabled [ + ]"

section "ADPF INPUT EVENT BOOST"
cmd device_config override game android.os.adpf_measure_during_input_event_boost true
success "input event boost enabled [ + ]"

section "ADPF POWER EFFICIENCY"
cmd device_config override game android.os.adpf_prefer_power_efficiency false
success "power efficiency preference disabled [ + ]"


# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "GAME DRIVER FOR ALL APPS"
settings put global game_driver_all_apps 1
success "game driver enabled for all apps [ + ]"
# @Yihhhh855// https://t.me/+UrKw18bS1tNkZjZl
section "APPLY GAME OVERLAY TO INSTALLED APPS"
GAMES=$(cmd package list packages --user 0 | cut -f2 -d:)
for app in $GAMES; do
    [ -z "$app" ] && continue
    if dumpsys game | grep -q "$app"; then
        info "Applying overlay to $app [ + ]"
        if [ "$ANDROID_VER_INT" -ge 12 ]; then
            cmd game set --mode 2 --downscale $DOWNSCALE --fps $FPS_SET "$app"
            cmd game mode 2 "$app"
        fi
    fi
done



section "FINAL STATUS"
success "LowTexYíH cloud core applied successfully"