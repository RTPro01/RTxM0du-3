#!/system/bin/sh

ui_print() {
    echo "$1"
}


FPS=$(settings get system peak_refresh_rate 2>/dev/null || echo 120)
RAM_KB=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 1500000)
ANDROID_VER=$(getprop ro.build.version.release | cut -d. -f1)
VERSION="*⁸"

if [ "$RAM_KB" -ge 8000000 ] && [ "$CPU_MAX_FREQ" -ge 2600000 ]; then
  CLASS="HIGH-END"
elif [ "$RAM_KB" -ge 6000000 ]; then
  CLASS="UPPER-MID"
elif [ "$RAM_KB" -ge 4000000 ]; then
  CLASS="MID"
else
  CLASS="LOW-END"
fi


ui_print " "
ui_print "╔════════════════════════╗"
ui_print "         LowTexYíH CODM OPT V$VERSION "
ui_print "╚════════════════════════╝"
ui_print " "


ui_print "[■□□□□□□□□□] Loading Features..."
sleep 0.7
ui_print "Features included:"
ui_print "   - Dynamic Downscale (Auto Detect)"
ui_print "   - Auto FPS Adjustment"
ui_print "   - Game Overlay Optimization"
ui_print "   - Rendering Tweaks (OpenGL Boost)"
ui_print "   - Background and Doze Boost"
ui_print "   - Performance Mode Unlock"
sleep 0.8


ui_print "[■■□□□□□□□□] Loading Target Game..."
sleep 0.7
ui_print "Target Game:"
ui_print "   - Call of Duty Mobile (Garena)"
sleep 0.8


ui_print "[■■■□□□□□□□] Loading Smart Engine..."
sleep 0.7
ui_print "Smart Engine:"
ui_print "   Adjusts based on RAM and CPU"
ui_print "   Balances performance and graphics"
sleep 0.8


ui_print "[■■■■□□□□□□] Loading Graphics Mode..."
sleep 0.7
ui_print "Graphics Mode:"
ui_print "   OVERLAY optimization"
sleep 0.8


ui_print "[■■■■■□□□□□] Installing performance script..."
sleep 1


ui_print "[■■■■■■■■■■] Finalizing Settings..."
sleep 1.5


ui_print " "
ui_print " "
ui_print "*** Device info ***"
ui_print "CPU Max Frequency : ${CPU_MAX_FREQ} Hz"
ui_print "RAM               : $((RAM_KB / 1024)) MB"
ui_print "FPS Target        : ${FPS}"
ui_print "Device Class      : ${CLASS}"
ui_print "Android Version   : ${ANDROID_VER}"
ui_print "***************************"
ui_print " "