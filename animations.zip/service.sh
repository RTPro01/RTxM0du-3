#!/system/bin/sh

MODDIR=${0%/*}

# Clear screen (for better look in logs/terminal)
clear

echo "========================================"
echo "     ⚡ ANIMATION BOOST MODULE ⚡"
echo "========================================"
echo ""

# Device Info
echo "[📱] Device Info:"
echo "Model        : $(getprop ro.product.model)"
echo "Brand        : $(getprop ro.product.brand)"
echo "Android Ver  : $(getprop ro.build.version.release)"
echo ""

# Display Info
echo "[🖥️] Display Info:"
echo "Resolution   : $(wm size | cut -d' ' -f3)"
echo "Density      : $(wm density | cut -d' ' -f3)"
echo "Refresh Rate : $(dumpsys display | grep -i 'refresh rate' | head -n 1)"
echo ""

# Wait for boot
echo "[⏳] Waiting for system boot..."
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 2
done

sleep 3

# Apply tweaks
echo "[⚙️] Applying Animation Scale (0.5x)..."

settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

echo ""
echo "[✅] Status: SUCCESS"
echo "Animation Scale set to 0.5x"
echo ""

# Final Info
echo "[🚀] Performance Tip:"
echo "Lower animation = Faster UI & smoother feel"
echo ""

echo "========================================"
echo "        MODULE EXECUTION DONE"
echo "========================================"