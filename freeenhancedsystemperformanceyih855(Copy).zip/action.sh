#!/system/bin/sh

GAME="com.garena.game.codm"

log "Starting LowTexYíH  Enhanced"

sleep 5
log "[OK] Boot completed"




log "[STEP] Cleaning RAM..."
am kill-all
log "[OK] RAM cleaned"



log "[STEP] Applying SurfaceFlinger tweaks..."

setprop debug.sf.use_phase_offsets_as_durations 1
check_prop debug.sf.use_phase_offsets_as_durations 1

setprop debug.sf.early_app_phase_offset_ns 600000
check_prop debug.sf.early_app_phase_offset_ns 600000

setprop debug.sf.early_sf_phase_offset_ns 600000
check_prop debug.sf.early_sf_phase_offset_ns 600000

setprop debug.sf.late_app_phase_offset_ns 900000
check_prop debug.sf.late_app_phase_offset_ns 900000

setprop debug.sf.late_sf_phase_offset_ns 900000
check_prop debug.sf.late_sf_phase_offset_ns 900000

setprop debug.sf.max_frame_buffer_acquired_buffers 3
check_prop debug.sf.max_frame_buffer_acquired_buffers 3




log "[STEP] Applying RenderEngine tweaks..."

setprop debug.renderengine.backend skiaglthreaded
check_prop debug.renderengine.backend skiaglthreaded

setprop debug.renderengine.enable_async_cache 1
check_prop debug.renderengine.enable_async_cache 1

setprop debug.renderengine.frame_submission_limit 3
check_prop debug.renderengine.frame_submission_limit 3

settings put global angle_gl_driver_selection_pkgs $GAME
log "[OK] angle_gl_driver_selection_pkgs set"

settings put global angle_gl_driver_selection_values egl
log "[OK] angle_gl_driver_selection_values set"




log "[STEP] Applying memory tweaks..."

settings put global activity_manager_constants \
"max_cached_processes=28,service_restart_duration=7000,fgservice_min_shown_time=2500,content_provider_retain_time=15000"

settings put global background_process_limit 3

log "[OK] Memory tweaks applied"




log "[STEP] Optimizing background..."

settings put global alarm_manager_constants \
"min_interval=60000,allow_while_idle_short_time=5000,max_batched_delay=15000"

settings put global sync_max_retry_delay_in_seconds 3600
settings put global connectivity_metrics_buffer_size 2000
settings put global background_throttling_enable 1
settings put global background_throttling_limit 50

log "[OK] Background optimized"




log "[STEP] Boosting touch..."

settings put system pointer_speed 6
settings put global tap_timeout 80
settings put global long_press_timeout 300
settings put global multi_press_timeout 200

log "[OK] Input optimized"






log "LowTexYíH  Enhanced Applied Successfully"
log "Log saved to: $LOG"