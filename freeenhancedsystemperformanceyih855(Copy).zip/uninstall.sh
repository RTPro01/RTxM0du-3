#!/system/bin/sh

LOG="/sdcard/lowtexyih_uninstall.log"

log() {
    echo "$(date '+%H:%M:%S') $1" | tee -a "$LOG"
}

GAME="com.garena.game.codm"

log "Starting LowTexYíH Reset..."




log "[STEP] Resetting SurfaceFlinger..."

resetprop -p debug.sf.use_phase_offsets_as_durations
resetprop -p debug.sf.early_app_phase_offset_ns
resetprop -p debug.sf.early_sf_phase_offset_ns
resetprop -p debug.sf.late_app_phase_offset_ns
resetprop -p debug.sf.late_sf_phase_offset_ns
resetprop -p debug.sf.max_frame_buffer_acquired_buffers

log "[OK] SurfaceFlinger reset"




log "[STEP] Resetting RenderEngine..."

resetprop -p debug.renderengine.backend
resetprop -p debug.renderengine.enable_async_cache
resetprop -p debug.renderengine.frame_submission_limit

settings delete global angle_gl_driver_selection_pkgs
settings delete global angle_gl_driver_selection_values

log "[OK] RenderEngine reset"




log "[STEP] Resetting memory tweaks..."

settings delete global activity_manager_constants
settings delete global background_process_limit

log "[OK] Memory reset"




log "[STEP] Resetting background tweaks..."

settings delete global alarm_manager_constants
settings delete global sync_max_retry_delay_in_seconds
settings delete global connectivity_metrics_buffer_size
settings delete global background_throttling_enable
settings delete global background_throttling_limit

log "[OK] Background reset"




log "[STEP] Resetting input settings..."

settings delete system pointer_speed
settings delete global tap_timeout
settings delete global long_press_timeout
settings delete global multi_press_timeout

log "[OK] Input reset"


log "LowTexYíH Reset Complete"
log "Reboot recommended"