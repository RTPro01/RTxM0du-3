#!/bin/sh
echo "[ 𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻🔥 ] "
echo "▶ Developer : @nzd_official "
echo "▶ Version : 1.0 "
echo "▶ Status : No Root "
sleep 2
echo "
░█▀▀▀█ ░█──░█ ░█▀▀▀ ░█▀▀█
░█──░█ ─░█░█─ ░█▀▀▀ ░█▄▄▀
░█▄▄▄█ ──▀▄▀─ ░█▄▄▄ ░█─░█

░█▀▀█ ░█─── ░█▀▀▀█ ░█▀▀█ ░█─▄▀
░█─── ░█─── ░█──░█ ░█─── ░█▀▄─
░█▄▄█ ░█▄▄█ ░█▄▄▄█ ░█▄▄█ ░█─░█"
echo ""
sleep 2
echo "▎𝗗𝗲𝘃𝗶𝗰𝗲 𝗜𝗻𝗳𝗼📱 "
sleep 0.5
echo "▎DEVICE=$(getprop ro.product.model) "
sleep 1
echo "▎BRAND=$(getprop ro.product.system.brand) "
sleep 1
echo "▎MODEL=$(getprop ro.build.product) "
sleep 1
echo "▎KERNEL=$(uname -r) "
sleep 1
echo "▎GPU INFO=$(getprop ro.hardware.egl) "
sleep 1
echo "▎CPU INFO=$(getprop ro.hardware) "
sleep 1
echo "▎ ANDROID VERSION : $(getprop ro.build.version.release) "
sleep 2
echo ""
echo " ▶ PROCES.........  "
echo ""
sleep 2
echo " ▶ WAIT.....  "
echo ""
sleep 5
echo "[■□□□□□□□□□]  "
sleep 1
echo "[■■□□□□□□□□]  "
sleep 1
echo "[■■■□□□□□□□]  "
sleep 1
echo "[■■■■□□□□□□]  "
sleep 1
echo "[■■■■■□□□□□]  "
sleep 1
echo "[■■■■■■□□□□]  "
sleep 1
echo "[■■■■■■■□□□]  "
sleep 1
echo "[■■■■■■■■□□]  "
sleep 1
echo "[■■■■■■■■■□]  "
sleep 1
echo "[■■■■■■■■■■]  "
sleep 0.5
echo ""
sleep 1

{

# Reset Refresh Rates
settings delete system peak_refresh_rate
settings delete system user_refresh_rate
settings delete system min_refresh_rate
settings delete system max_refresh_rate
settings delete system thermal_limit_refresh_rate
settings delete system miui_refresh_rate
settings delete secure user_refresh_rate
settings delete secure miui_refresh_rate
settings delete system tran_refresh_mode
settings delete system tran_need_recovery_refresh_mode
settings delete system refresh_rate
settings delete system refresh_rate_policy
settings delete system preferred_refresh_rate
settings delete system max_render_frame_rate
settings delete system target_fps
settings delete global min_fps
settings delete global max_fps

# Reset Animation Scales
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0

# Restore Power and Thermal Defaults
cmd power set-adaptive-power-saver-enabled true
cmd power set-fixed-performance-mode-enabled false
cmd thermalservice override-status 1
cmd power set-mode 1

# Re-enable PowerKeeper if disabled
pm enable com.miui.powerkeeper

# Reset Performance Modes
settings delete system POWER_PERFORMANCE_MODE_OPEN
settings delete system high_performance_mode_on
settings delete secure speed_mode_enable
settings put global performance_profile 0
settings put global miui_performance_mode 0
settings put system power_save_mode 1

# Restore Idle & Battery Defaults
settings delete global device_idle_constants
settings put global low_power 1

# Disable GPU/Performance Overrides
settings delete global GPUTUNER_SWITCH
settings delete global FPSTUNER_SWITCH
settings delete global PERFORMANCE_BOOST_MODE

# Reset SurfaceFlinger & HWUI Props
resetprop --delete debug.sf.frame_rate
resetprop --delete debug.sf.frame_rate_lock
resetprop --delete debug.sf.frame_rate_policy
resetprop --delete debug.sf.swapinterval
resetprop --delete debug.hwui.renderer
resetprop --delete debug.hwui.render_type
resetprop --delete debug.hwui.render_engine_backend
resetprop --delete debug.hwui.force_gpu
resetprop --delete debug.hwui.use_vulkan
resetprop --delete debug.hwui.disable_vsync
resetprop --delete debug.hwui.profile
resetprop --delete debug.hwui.enable_msaa
resetprop --delete debug.hwui.force_antialiasing
resetprop --delete debug.hwui.use_hardware_acceleration
resetprop --delete debug.hwui.force_layer_cache_enabled
resetprop --delete debug.hwui.render_mode
resetprop --delete debug.hwui.refresh_rate
resetprop --delete debug.display.max_refresh_rate
resetprop --delete debug.display.min_refresh_rate
resetprop --delete debug.display.user_refresh_rate

# Restore Composition Type
setprop debug.composition.type c2d

# Re-enable default VSync & Rendering Behavior
setprop debug.hwui.disable_vsync false
setprop debug.hwui.enable_vsync true

# Reset Animation Props
setprop debug.ui.animation_scale 1.0
setprop debug.window.animation_scale 1.0
setprop debug.transition.animation_scale 1.0

}

echo ""
echo "▶ Module succesfully overclocked.... "
sleep 1
echo ""
cmd notification post -S bigtext -t ' 🚀 Performance Overclock ' 'Tag' 'DELETED!!' > /dev/null 2>&1
echo " SUBSCRIBE | LIKE 👍 | SHARE | COMMENT "
echo ""
echo " Done....... "
