#!/bin/sh
echo "[ 𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻 ] "
echo " -- Developer : @nzd_official "
echo " -- Version : 1.0 "
echo " -- Status : No Root "
sleep 2
echo "
░█▀▀▀█ ░█──░█ ░█▀▀▀ ░█▀▀█
░█──░█ ─░█░█─ ░█▀▀▀ ░█▄▄▀
░█▄▄▄█ ──▀▄▀─ ░█▄▄▄ ░█─░█

░█▀▀█ ░█─── ░█▀▀▀█ ░█▀▀█ ░█─▄▀
░█─── ░█─── ░█──░█ ░█─── ░█▀▄─
░█▄▄█ ░█▄▄█ ░█▄▄▄█ ░█▄▄█ ░█─░█"
echo ""
sleep 2
echo "▎𝗗𝗲𝘃𝗶𝗰𝗲 𝗜𝗻𝗳𝗼📱 "
sleep 0.5
echo "▎DEVICE=$(getprop ro.product.model) "
sleep 1
echo "▎BRAND=$(getprop ro.product.system.brand) "
sleep 1
echo "▎MODEL=$(getprop ro.build.product) "
sleep 1
echo "▎KERNEL=$(uname -r) "
sleep 1
echo "▎GPU INFO=$(getprop ro.hardware.egl) "
sleep 1
echo "▎CPU INFO=$(getprop ro.hardware) "
sleep 1
echo "▎ ANDROID VERSION : $(getprop ro.build.version.release) "
sleep 2
echo ""
echo " ▶ PROCES.........  "
echo ""
sleep 2
echo " ▶ WAIT.....  "
echo ""
sleep 5
echo "[■□□□□□□□□□]  "
sleep 1
echo "[■■□□□□□□□□]  "
sleep 1
echo "[■■■□□□□□□□]  "
sleep 1
echo "[■■■■□□□□□□]  "
sleep 1
echo "[■■■■■□□□□□]  "
sleep 1
echo "[■■■■■■□□□□]  "
sleep 1
echo "[■■■■■■■□□□]  "
sleep 1
echo "[■■■■■■■■□□]  "
sleep 1
echo "[■■■■■■■■■□]  "
sleep 1
echo "[■■■■■■■■■■]  "
sleep 0.5
echo ""
sleep 1

{

settings put system peak_refresh_rate 1
settings put system user_refresh_rate 1
settings put system min_refresh_rate 1
settings put system max_refresh_rate 1
settings put system thermal_limit_refresh_rate 0
settings put system miui_refresh_rate 1
settings put secure user_refresh_rate 1
settings put secure miui_refresh_rate 1
settings put system tran_refresh_mode 1
settings put system tran_need_recovery_refresh_mode 1
settings put system refresh_rate 120
settings put system refresh_rate_policy 1
settings put system preferred_refresh_rate 120
settings put system max_render_frame_rate 120
settings put system target_fps 120
settings put global min_fps 120
settings put global max_fps 120
settings put global transition_animation_scale 0.0
settings put global window_animation_scale 0.0
settings put global animator_duration_scale 0.0
setprop debug.sf.frame_rate_priority 1
setprop debug.sf.frame_rate 120
setprop debug.sf.frame_rate_lock 120
setprop debug.sf.frame_rate_logging_enabled true
setprop debug.sf.frame_rate_multiple_threshold 120
setprop debug.sf.frame_rate_override 120
setprop debug.sf.frame_rate_policy stable
setprop debug.display.peak_refresh_rate 120
setprop debug.display.min_refresh_rate 120
setprop debug.display.max_refresh_rate 120
setprop debug.display.user_refresh_rate 120
setprop debug.display.default_refresh_rate 120
setprop debug.display.refresh_rate_limit 0
setprop debug.hwui.peak_refresh_rate 120
setprop debug.hwui.min_refresh_rate 120
setprop debug.hwui.max_refresh_rate 120
setprop debug.hwui.user_refresh_rate 120
setprop debug.hwui.default_refresh_rate 120
setprop debug.hwui.refresh_rate_limit 0
setprop debug.hwui.disable_vsync true
setprop debug.sf.swapinterval 0
setprop debug.gr.swapinterval 0
setprop debug.egl.swapinterval 0
setprop debug.gl.swapinterval 0
setprop debug.cpurend.vsync false
setprop debug.gr.swapinterval 0
setprop debug.hwui.renderer skiagl
setprop debug.composition.type gpu
setprop debug.performance.tuning 1
setprop debug.sf.enable_hwc_vds 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.hw 0
setprop debug.egl.hw 0
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.disable_vr_flip true
setprop debug.hwui.use_cache false
setprop debug.hwui.layer_cache_size 0
setprop debug.gralloc.enable_ubwc false
setprop debug.egl.hw 0
setprop debug.sf.latch_to_present false
setprop debug.hwui.texture_cache_size 0
setprop debug.hwui.shader_cache_size 0
setprop debug.hwui.show_dirty_regions false
setprop debug.show_fps false
setprop debug.ui.animation_scale 0.0
setprop debug.window.animation_scale 0.0
setprop debug.transition.animation_scale 0.0
setprop debug.sf.gl3 false

# Disable adaptive power saving mode

cmd power set-adaptive-power-saver-enabled false

# Enable fixed performance mode

cmd power set-fixed-performance-mode-enabled true

# Disable thermal service

cmd thermalservice override-status 0

# Disable FPS limitations

pm disable-user com.miui.powerkeeper

# Disable low power mode

cmd power set-mode 0

# Enable performance mode (Xiaomi devices)

settings put system POWER_PERFORMANCE_MODE_OPEN 1

# Enable high performance

settings put system high_performance_mode_on 1

# Enable speed mode (Xiaomi devices)

settings put secure speed_mode_enable 1

# Performance focus

settings put system power_save_mode 0
settings put global miui_performance_mode 1
settings put global performance_profile 1

# Disable sleep mode

settings put global device_idle_constants off
settings put global low_power 0

# Boost Game and Graphic

settings put global GPUTUNER_SWITCH true
settings put global FPSTUNER_SWITCH true
settings put global PERFORMANCE_BOOST_MODE 1

# Best Performance

setprop debug.hwui.use_hardware_acceleration true
setprop debug.hwui.disable_layer_cache true
setprop debug.hwui.disable_scissor false
setprop debug.hwui.disable_scissor_opt false
setprop debug.hwui.render_compability true
setprop debug.hwui.show_non_rect_clip hide
setprop debug.hwui.forcegpu true
setprop debug.hwui.force.gpu true
setprop debug.hwui.force_gpu true
setprop debug.hwui.composition true
setprop debug.hwui.use_hardware_bitmaps true
setprop debug.hwui.use_render_effects false
setprop debug.hwui.render_buffer_cache_size 1048576
setprop debug.hwui.enable_shadow_filter false
setprop debug.hwui.use_mipmap true
setprop debug.hwui.use_text_aa true
setprop debug.hwui.drop_shadow_cache_size 1024
setprop debug.hwui.text_large_cache_height 2048
setprop debug.hwui.text_large_cache_width 2048
setprop debug.hwui.disable_vsync true
setprop debug.hwui.enable_vsync false
setprop debug.hwui.use_vulkan true
setprop debug.hwui.profile true
setprop debug.hwui.force_gpu true
setprop debug.hwui.profile.gpu true
setprop debug.hwui.render_thread true
setprop debug.hwui.use_hwc_textures true
setprop debug.hwui.use_buffer_age true
setprop debug.hwui.use_gpu_pixel_buffers true
setprop debug.hwui.use_hint_manager true
setprop debug.hwui.disable_draw_defer true
setprop debug.hwui.disable_draw_reorder true
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.show_dirty_regions false
setprop debug.hwui.disabledither false
setprop debug.hwui.overdraw false
setprop debug.hwui.force_dark false
setprop debug.hwui.skip_empty_damage false
setprop debug.hwui.enable_partial_updates false
setprop debug.hwui.renderer_override skiavk
setprop debug.hwui.rendering skiavk
setprop debug.hwui.renderer skiavk
setprop debug.hwui.render_engine_backend skiavk
setprop debug.hwui.rendering_type skiavk
setprop debug.hwui.composition_type gpu
setprop debug.hwui.render_type gpu
setprop debug.hwui.skia_atrace_enabled false
setprop debug.hwui.skia_tracing_enabled false
setprop debug.hwui.skia_use_perfetto_track_events false
setprop debug.hwui.render_all_layers true
setprop debug.hwui.use_cache false
setprop debug.hwui.texture_cache_size 16
setprop debug.hwui.layer_cache_size 16
setprop debug.hwui.resolution_scale 1
setprop debug.hwui.target_cpu_time_percent 100
setprop debug.hwui.target_gpu_time_percent 100
setprop debug.hwui.fps_divisor -1
setprop debug.hwui.force_refresh_rate 120
setprop debug.hwui.refresh_rate_forced 120
setprop debug.hwui.profile.maxframes 120
setprop debug.hwui.profile.minframes 120
setprop debug.hwui.profile.peakframes 120
setprop debug.hwui.frame_rate_multiple 120
setprop debug.hwui.max_frames 120
setprop debug.hwui.min_frames 120
setprop debug.hwui.peak_frames 120
setprop debug.hwui.detail_fps 120
setprop debug.hwui.fps 120
setprop debug.hwui.max_fps 120
setprop debug.hwui.min_fps 120
setprop debug.hwui.peak_fps 120
setprop debug.hwui.refresh_rate 120
setprop debug.hwui.fpslimit 0
setprop debug.hwui.fps_limit 0
setprop debug.hwul.refresh_rate 120

setprop debug.hwui.hardware_enabled true
setprop debug.hwui.render_mode hardware
setprop debug.hwui.use_gpu_acceleration true
setprop debug.hwui.gpu_acceleration_override true
setprop debug.hwui.use_hardware_overlays true
setprop debug.hwui.enable_gpu_rasterization true
setprop debug.hwui.enable_egl_extensions true
setprop debug.hwui.enable_egl_tracing false
setprop debug.hwui.force_layer_cache_enabled true
setprop debug.hwui.renderer_override skiagl
setprop debug.hwui.render_engine_backend vulkan
setprop debug.hwui.rendering_type dynamic
setprop debug.hwui.force_vulkan true
setprop debug.hwui.force_opengl_pipeline false
setprop debug.hwui.skia_gl_threaded true
setprop debug.hwui.skia_cache_size 1048576
setprop debug.hwui.skia_texture_atlas_size 8192
setprop debug.hwui.texture_cache_size 32
setprop debug.hwui.layer_cache_size 64
setprop debug.hwui.use_larger_textures true
setprop debug.hwui.text_large_cache_height 4096
setprop debug.hwui.text_large_cache_width 4096
setprop debug.hwui.text_small_cache_height 2048
setprop debug.hwui.text_small_cache_width 2048
setprop debug.hwui.drop_shadow_cache_size 2048
setprop debug.hwui.use_hardware_bitmaps_cache true
setprop debug.hwui.force_antialiasing true
setprop debug.hwui.enable_msaa true
setprop debug.hwui.msaa_sample_count 4
setprop debug.hwui.color_space sRGB
setprop debug.hwui.enable_hdr_support true
setprop debug.hwui.reduce_shader_complexity true
setprop debug.hwui.optimize_draw_calls true
setprop debug.hwui.enable_dithering true

}

echo ""
echo "▶ Performance successfully overclocked.... "
sleep 1
echo ""
cmd notification post -S bigtext -t ' 🚀 Performance Overclock ' 'Tag' 'ACTIVATED!!' > /dev/null 2>&1
echo " SUBSCRIBE | LIKE 👍 | SHARE | COMMENT "
echo ""
echo " Done....... "
echo " PLEASE DON'T REBOOT YOUR PHONE "
