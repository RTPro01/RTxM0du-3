sleep 1
echo ""
echo " 
█▀█ █▀█ █▀▀ █▄░█ █▀▀ █░░
█▄█ █▀▀ ██▄ █░▀█ █▄█ █▄▄ "
sleep 1
echo ""
echo " ************************************************************************ "
echo " Developer     :     RC Modz "
sleep 0.1
echo " Version       :     Stable NR "
sleep 0.1
echo " Tools         :     Brevent "
sleep 1
echo ""
echo " ************************************************************************ "
echo " CHECKING DEVICE INFORMATION "
sleep 1
echo ""
echo "CPU      : $(getprop ro.board.platform)"
echo "GPU      : $(getprop ro.hardware)"
echo "Android  : $(getprop ro.build.version.release)"
echo "Kernel   : $(uname -r)"
echo "Build    : $(getprop ro.build.display.id)"
echo "Root     : $(if [ $(id -u) -eq 0 ]; then echo 'Yes'; else echo 'No'; fi)"
echo "SELinux  : $(getenforce)"
sleep 3
echo ""
echo " ************************************************************************ "
echo " - Trimming up Partitions "
sleep 3
echo " - Deleting Cache and Trash "
sleep 5
echo " - Finalizing Props "
sleep 2
echo " - Module Flashed Successfully "
sleep 1
echo ""
echo " - RC Modz "

# --- Reverting OpenGL Lite and Rendering Settings to Default ---

(
    # Resetting shader-related properties
    setprop debug.rs.shader ""
    setprop debug.rs.shader.attributes ""
    setprop debug.rs.shader.uniforms ""
    setprop debug.rs.profile ""
    setprop debug.rs.script ""
    setprop debug.rs.visual ""
    setprop debug.rs.debug ""
    setprop debug.rs.precision ""
    setprop debug.rs.forcecompat ""
    setprop debug.rs.default-CPU-driver ""
    setprop debug.rs.default-GPU-driver ""
    setprop debug.rs.default-CPU-buffer ""

    # Resetting Shader Cache and Layer Optimization Settings
    setprop debug.sf.prime_shader_cache.solid_dimmed_layers ""
    setprop debug.sf.prime_shader_cache.image_dimmed_layers ""
    setprop debug.sf.prime_shader_cache.image_layers ""
    setprop debug.sf.prime_shader_cache.clipped_layers ""
    setprop debug.sf.prime_shader_cache.shadow_layers ""
    setprop debug.sf.prime_shader_cache.pip_image_layers ""
    setprop debug.sf.prime_shader_cache.transparent_image_dimmed_layers ""
    setprop debug.sf.prime_shader_cache.clipped_dimmed_image_layers ""
    setprop debug.sf.enable_layer_caching ""
    setprop debug.sf.layer_caching_active_layer_timeout_ms ""
    setprop debug.sf.prime_shader_cache.all_layers ""
    setprop debug.sf.prime_shader_cache.hole_punch ""
    setprop debug.sf.prime_shader_cache.solid_layers ""

    # Deleting global settings related to render thread and buffering
    settings delete global debug.hwui.disable_render_thread
    setprop debug.hwui.use_threaded_renderer ""
    setprop debug.hwui.disable_vsync ""
    setprop debug.hwui.vsync_override ""
    setprop debug.hwui.min_frames_rendered ""
    setprop debug.hwui.jank_avoidance ""
    setprop debug.sf.frame_rate_multiple_threshold ""
    setprop debug.sf.latch_unsignaled ""
    setprop debug.sf.enable_frame_rate_override ""
    setprop debug.sf.predict_hwc_composition_strategy ""
    setprop debug.hwui.disable_partial_updates ""
    setprop debug.sf.disable_client_composition_cache ""

    # Resetting buffer management properties
    settings delete global buffer_queue_max_buffer_count
    settings delete global surface_flinger.use_color_management

    # Resetting shadow rendering and cache settings
    setprop debug.hwui.shadow.renderer ""
    setprop debug.hwui.drop_shadow_cache_size ""
    setprop debug.hwui.texture_cache_size ""
    setprop debug.hwui.gradient_cache_size ""
    setprop debug.hwui.path_cache_size ""
    setprop debug.hwui.shape_cache_size ""
    setprop debug.hwui.layer_cache_size ""
    setprop debug.hwui.disable_scissor_opt ""

    # Resetting rendering pipeline settings
    setprop debug.hwui.use_hint_manager ""
    setprop debug.hwui.target_cpu_time_percent ""
    setprop debug.hwui.target_gpu_time_percent ""
    setprop debug.hwui.enable_f16 ""
    setprop debug.hwui.enable_partial_updates ""

    # Resetting FPS stabilization settings for UI rendering
    setprop debug.hwui.fps_divisor ""
    setprop debug.sf.disable_backpressure ""

    # Reverting Pipeline Rendering to default (non-OpenGL Lite)
    setprop debug.sf.pipeline ""

    # Resetting stability settings for rendering
    setprop debug.sf.auto_latch_unsignaled ""
    setprop debug.sf.disable_client_composition_cache ""
    setprop debug.sf.early.app.duration ""
    setprop debug.sf.early.sf.duration ""
    setprop debug.sf.earlyGl.app.duration ""
    setprop debug.sf.earlyGl.sf.duration ""
    setprop debug.sf.enable_advanced_sf_phase_offset ""
    setprop debug.sf.enable_gl_backpressure ""
    setprop debug.sf.enable_hwc_vds ""
    setprop debug.sf.hw ""
    setprop debug.sf.latch_unsignaled ""
    setprop debug.sf.late.app.duration ""
    setprop debug.sf.late.sf.duration ""
    setprop debug.sf.predict_hwc_composition_strategy ""
    setprop debug.sf.treat_170m_as_sRGB ""
    setprop debug.sf.use_phase_offsets_as_durations ""

    # Resetting EGL and GPU rendering settings
    setprop debug.egl.version ""
    setprop debug.gpu.renderer ""
    setprop debug.hwui.renderer ""
    setprop debug.hwui.use_threaded_renderer ""
    setprop debug.renderengine.backend ""
    setprop debug.hwui.shadow.renderer ""
    setprop debug.composition.type ""

    # Deleting Vulkan and GPU debug layers settings
    settings delete global debug.hwui.use_vulkan
    settings delete global gpu_debug_layers_on
    settings delete global enable_gpu_renderer
    settings delete global use_egl_mode
    settings delete global debug_hwui_renderer opengl
    settings delete global gpu_debug_layers_on
    settings delete global enable_opengl_lite
    settings delete global debug_enable_scissor_optimization
    settings delete global buffer_size
    settings delete global hwui_disable_vsync

    # Resetting additional OpenGL settings and debug options
    setprop debug.rs.visual ""
    setprop debug.hwui.renderer ""
    setprop debug.rs.shader ""
    setprop debug.hw.vsync ""
    setprop debug.generate-debug-info ""
    setprop debug.egl.traceGpuCompletion ""
    setprop debug.sf.use_frame_rate_priority ""

    # Deleting global texture and frame rate settings
    settings delete global hwui.renderer
    settings delete system surface_flinger_use_frame_rate_api
    setprop debug.hwui.disable_zrle ""
    setprop debug.hwui.vsync_override ""
    settings delete global hwui.texture_cache_flushrate
    settings delete global texture_atlas_cache_override
    settings delete global texture_atlas_cache_entry_override
    settings delete global texture_atlas_map_pool_override
) > /dev/null 2>&1

# --- End of Reversion Process ---