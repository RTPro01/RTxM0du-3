#!/system/bin/sh
#===============================================================
# revert.sh - Standalone Revert Script (NON-ROOT)
# Usage: sh revert.sh
#===============================================================

echo "[*] Reverting Android settings to defaults..."

    settings put global window_animation_scale 1
    settings put global transition_animation_scale 1
    settings put global animator_duration_scale 1
    settings put global app_standby_enabled 1
    settings put global adaptive_battery_management_enabled 1
    settings put global enable_gpu_debug_layers 0
    settings put global show_hw_screen_updates 0
    settings put global show_hw_layers_updates 0
    settings put global debug_view_attributes 0
    settings put global force_gpu_rendering 0

    settings put secure long_press_timeout 400
    settings put secure multi_press_timeout 300

    settings put system pointer_speed 0
    settings put system haptic_feedback_enabled 1
    settings put system sound_effects_enabled 1
    settings put system lockscreen_sounds_enabled 1
    settings put system min_refresh_rate 60
    settings put system peak_refresh_rate 120

    echo "[✓] Default values applied!"
    
echo ""
